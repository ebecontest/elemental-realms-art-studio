import { useEffect, useState } from 'react';
import { Bot, Send, Settings2, X, Loader2, Sparkles } from 'lucide-react';

type Message = { role: 'user' | 'assistant'; text: string };
const STORAGE_KEY = 'er-gemini-backend-url-v1';

export function GeminiAssistant() {
  const [open, setOpen] = useState(false);
  const [backendUrl, setBackendUrl] = useState(() => localStorage.getItem(STORAGE_KEY) || '');
  const [editingUrl, setEditingUrl] = useState(false);
  const [draftUrl, setDraftUrl] = useState(backendUrl);
  const [prompt, setPrompt] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', text: 'Hi! I’m your Gemini assistant for ELEMENTAL REALMS. I can help design characters, monsters, items, pixel-art palettes and animation plans. What shall we create?' },
  ]);

  useEffect(() => { setDraftUrl(backendUrl); }, [backendUrl]);

  const saveUrl = () => {
    const clean = draftUrl.trim().replace(/\/+$/, '');
    localStorage.setItem(STORAGE_KEY, clean);
    setBackendUrl(clean);
    setEditingUrl(false);
    setError('');
  };

  const send = async () => {
    const text = prompt.trim();
    if (!text || busy) return;
    if (!backendUrl) { setError('Set your backend URL first using the settings button.'); return; }
    const next = [...messages, { role: 'user' as const, text }];
    setMessages(next);
    setPrompt('');
    setBusy(true);
    setError('');
    try {
      const response = await fetch(`${backendUrl}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: text, history: next.slice(-13, -1).map(m => ({ role: m.role, text: m.text })) }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Request failed (${response.status})`);
      setMessages(old => [...old, { role: 'assistant', text: data.text || 'Gemini returned an empty response.' }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not reach Gemini backend.');
    } finally { setBusy(false); }
  };

  return <>
    <button onClick={() => setOpen(true)} className="fixed bottom-4 right-4 z-[80] flex items-center gap-2 rounded-full bg-sky-500 px-4 py-3 text-sm font-bold text-slate-950 shadow-xl">
      <Sparkles size={17}/> Gemini AI
    </button>
    {open && <div className="fixed inset-0 z-[90] flex items-end justify-end bg-black/50 p-2 sm:items-center sm:p-5">
      <section className="flex h-[min(720px,92vh)] w-full max-w-lg flex-col overflow-hidden rounded-2xl border border-[#334155] bg-[#0B1220] shadow-2xl">
        <header className="flex items-center gap-2 border-b border-[#263248] p-3">
          <span className="rounded-lg bg-sky-500/15 p-2 text-sky-300"><Bot size={20}/></span>
          <div className="min-w-0 flex-1"><div className="text-sm font-bold text-white">Gemini AI Assistant</div><div className="text-[10px] text-slate-400">ELEMENTAL REALMS Art Studio</div></div>
          <button onClick={() => {setDraftUrl(backendUrl);setEditingUrl(v=>!v);}} aria-label="Backend settings" className="rounded-lg p-2 text-slate-300 hover:bg-white/10"><Settings2 size={18}/></button>
          <button onClick={() => setOpen(false)} aria-label="Close assistant" className="rounded-lg p-2 text-slate-300 hover:bg-white/10"><X size={18}/></button>
        </header>
        {editingUrl && <div className="border-b border-[#263248] bg-[#111827] p-3">
          <label className="mb-1 block text-[10px] text-slate-400">Backend URL (Render service URL)</label>
          <input value={draftUrl} onChange={e=>setDraftUrl(e.target.value)} placeholder="https://your-service.onrender.com" className="w-full rounded-lg border border-[#334155] bg-[#080D16] p-2 text-xs text-white"/>
          <div className="mt-2 flex justify-end gap-2"><button onClick={()=>setEditingUrl(false)} className="rounded-lg px-3 py-2 text-xs text-slate-300">Cancel</button><button onClick={saveUrl} className="rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950">Save URL</button></div>
        </div>}
        <div className="flex-1 space-y-3 overflow-y-auto p-3">
          {messages.map((m,i)=><div key={i} className={`max-w-[90%] whitespace-pre-wrap rounded-xl p-3 text-xs leading-relaxed ${m.role==='user'?'ml-auto bg-sky-500 text-slate-950':'bg-[#172235] text-slate-100'}`}>{m.text}</div>)}
          {busy && <div className="flex items-center gap-2 text-xs text-slate-400"><Loader2 size={14} className="animate-spin"/> Gemini is thinking…</div>}
          {error && <div className="rounded-lg border border-rose-500/30 bg-rose-500/10 p-2 text-xs text-rose-200">{error}</div>}
        </div>
        <form onSubmit={e=>{e.preventDefault();void send();}} className="flex items-end gap-2 border-t border-[#263248] p-3">
          <textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={2} placeholder="Describe a Fire Element monster…" className="max-h-28 min-h-11 flex-1 resize-y rounded-xl border border-[#334155] bg-[#080D16] p-3 text-xs text-white outline-none focus:border-sky-500"/>
          <button disabled={busy || !prompt.trim()} aria-label="Send message" className="rounded-xl bg-sky-500 p-3 text-slate-950 disabled:opacity-40"><Send size={17}/></button>
        </form>
        <div className="px-3 pb-2 text-center text-[9px] text-slate-500">API key stays on your backend. Never paste it into this website.</div>
      </section>
    </div>}
  </>;
}

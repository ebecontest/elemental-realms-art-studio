import { useEffect, useMemo, useRef, useState } from 'react';
import { Scissors, Download, FileCode2 } from 'lucide-react';

export function SpriteSheetSlicer() {
  const [url, setUrl] = useState('');
  const [image, setImage] = useState<HTMLImageElement | null>(null);
  const [frameWidth, setFrameWidth] = useState(32);
  const [frameHeight, setFrameHeight] = useState(32);
  const [gap, setGap] = useState(0);
  const [selected, setSelected] = useState<number[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => () => { if (url) URL.revokeObjectURL(url); }, [url]);
  const columns = image ? Math.max(0, Math.floor((image.naturalWidth + gap) / (frameWidth + gap))) : 0;
  const rows = image ? Math.max(0, Math.floor((image.naturalHeight + gap) / (frameHeight + gap))) : 0;
  const count = columns * rows;
  const indices = useMemo(() => selected.length ? selected : Array.from({length: count}, (_,i)=>i), [selected,count]);
  const load = (file?: File) => {
    if (!file) return;
    const nextUrl = URL.createObjectURL(file);
    const nextImage = new Image();
    nextImage.onload = () => { setUrl(old=>{if(old)URL.revokeObjectURL(old);return nextUrl;}); setImage(nextImage); setSelected([]); };
    nextImage.onerror = () => { URL.revokeObjectURL(nextUrl); window.alert('Unable to read this sprite sheet.'); };
    nextImage.src = nextUrl;
  };
  const exportFrames = () => {
    if (!image || !indices.length) return;
    const canvas = document.createElement('canvas'); canvas.width=frameWidth*indices.length; canvas.height=frameHeight;
    const ctx=canvas.getContext('2d'); if(!ctx)return;
    ctx.imageSmoothingEnabled=false;
    indices.forEach((i,n)=>ctx.drawImage(image!, (i%columns)*(frameWidth+gap), Math.floor(i/columns)*(frameHeight+gap), frameWidth, frameHeight, n*frameWidth, 0, frameWidth, frameHeight));
    const a=document.createElement('a');a.download='elemental-realms-sliced-frames.png';a.href=canvas.toDataURL('image/png');a.click();
  };
  const exportMetadata = () => {
    if(!image)return;
    const payload={format:'elemental-realms-sliced-atlas',version:1,sourceWidth:image.naturalWidth,sourceHeight:image.naturalHeight,frameWidth,frameHeight,gap,columns,rows,frames:indices.map(i=>({index:i,x:(i%columns)*(frameWidth+gap),y:Math.floor(i/columns)*(frameHeight+gap),width:frameWidth,height:frameHeight}))};
    const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download='elemental-realms-sliced-atlas.json';a.click();URL.revokeObjectURL(u);
  };
  return <section className="mt-4 rounded-xl border border-[#263248] bg-[#0B0D14] p-3">
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div><div className="flex items-center gap-2 text-sm font-bold text-white"><Scissors size={15}/> Sprite Sheet Slicer</div><p className="mt-1 text-[10px] text-slate-400">Import an atlas, define cell size and extract frames.</p></div>
    <label className="cursor-pointer rounded-lg border border-sky-500/50 px-3 py-2 text-xs text-sky-300">Import sheet<input ref={inputRef} className="hidden" type="file" accept="image/png,image/webp,image/jpeg" onChange={e=>{load(e.target.files?.[0]);e.currentTarget.value='';}}/></label></div>
    {image ? <>
      <div className="grid grid-cols-3 gap-2">
        <label className="text-[10px] text-slate-400">Frame W<input type="number" min="1" max="1024" value={frameWidth} onChange={e=>{setFrameWidth(Math.max(1,Math.min(1024,Number(e.target.value)||1)));setSelected([]);}} className="mt-1 w-full rounded border border-[#263248] bg-[#111827] p-2 text-xs text-white"/></label>
        <label className="text-[10px] text-slate-400">Frame H<input type="number" min="1" max="1024" value={frameHeight} onChange={e=>{setFrameHeight(Math.max(1,Math.min(1024,Number(e.target.value)||1)));setSelected([]);}} className="mt-1 w-full rounded border border-[#263248] bg-[#111827] p-2 text-xs text-white"/></label>
        <label className="text-[10px] text-slate-400">Gap<input type="number" min="0" max="128" value={gap} onChange={e=>{setGap(Math.max(0,Math.min(128,Number(e.target.value)||0)));setSelected([]);}} className="mt-1 w-full rounded border border-[#263248] bg-[#111827] p-2 text-xs text-white"/></label>
      </div>
      <p className="my-2 text-[10px] text-slate-400">{image.naturalWidth} × {image.naturalHeight}px · {columns} columns × {rows} rows · {count} frames</p>
      <div className="grid max-h-64 grid-cols-4 gap-2 overflow-auto rounded-lg border border-[#263248] p-2 sm:grid-cols-6">
        {Array.from({length:count},(_,i)=><button key={i} onClick={()=>setSelected(old=>old.includes(i)?old.filter(v=>v!==i):[...old,i])} className={`rounded border p-1 ${selected.includes(i)?'border-sky-400 bg-sky-500/10':'border-[#263248]'}`}><span className="block text-[9px] text-slate-500">{i+1}</span><span className="bg-alpha-checker flex aspect-square items-center justify-center overflow-hidden"><canvas ref={node=>{if(!node)return;node.width=frameWidth;node.height=frameHeight;const c=node.getContext('2d');if(c)c.drawImage(image,(i%columns)*(frameWidth+gap),Math.floor(i/columns)*(frameHeight+gap),frameWidth,frameHeight,0,0,frameWidth,frameHeight);}} className="max-h-full max-w-full" style={{imageRendering:'pixelated'}}/></span></button>)}
      </div>
      <div className="mt-2 flex flex-wrap gap-2"><button onClick={()=>setSelected([])} className="rounded border border-[#263248] px-2 py-2 text-[10px] text-slate-300">Select all / clear selection</button><button onClick={exportFrames} className="flex items-center gap-1 rounded bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950"><Download size={13}/> Export frames PNG</button><button onClick={exportMetadata} className="flex items-center gap-1 rounded border border-amber-500/50 px-3 py-2 text-xs text-amber-300"><FileCode2 size={13}/> Atlas JSON</button></div>
    </> : <div className="rounded-lg border border-dashed border-[#3B4A62] p-5 text-center text-xs text-slate-500">Import a sprite sheet PNG to slice it into individual frames.</div>}
  </section>;
}

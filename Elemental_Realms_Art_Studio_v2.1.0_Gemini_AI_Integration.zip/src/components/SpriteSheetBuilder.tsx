import { SpriteSheetSlicer } from './SpriteSheetSlicer';
import { useEffect, useState } from 'react';
import { Download, FileCode2, Images } from 'lucide-react';

type Frame = { name: string; url: string; image: HTMLImageElement };

export function SpriteSheetBuilder() {
  const [frames, setFrames] = useState<Frame[]>([]);
  const [columns, setColumns] = useState(4);
  const [gap, setGap] = useState(0);
  const [cellWidth, setCellWidth] = useState(32);
  const [cellHeight, setCellHeight] = useState(32);
  const rows = Math.max(1, Math.ceil(frames.length / columns));
  const sheetWidth = columns * cellWidth + Math.max(0, columns - 1) * gap;
  const sheetHeight = rows * cellHeight + Math.max(0, rows - 1) * gap;

  useEffect(() => () => frames.forEach((frame) => URL.revokeObjectURL(frame.url)), [frames]);

  const addFiles = (files: FileList | null) => {
    if (!files) return;
    const next = Array.from(files).filter((file) => file.type.startsWith('image/')).slice(0, 64 - frames.length);
    Promise.all(next.map((file) => new Promise<Frame>((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const image = new Image();
      image.onload = () => resolve({ name: file.name, url, image });
      image.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Invalid image')); };
      image.src = url;
    }))).then((loaded) => {
      if (!loaded.length) return;
      setFrames((old) => [...old, ...loaded]);
      setCellWidth(Math.max(1, loaded[0].image.naturalWidth));
      setCellHeight(Math.max(1, loaded[0].image.naturalHeight));
    }).catch(() => window.alert('Some images could not be loaded.'));
  };

  const makeSheet = () => {
    const canvas = document.createElement('canvas');
    canvas.width = sheetWidth; canvas.height = sheetHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.imageSmoothingEnabled = false;
    frames.forEach((frame, index) => {
      const x = (index % columns) * (cellWidth + gap);
      const y = Math.floor(index / columns) * (cellHeight + gap);
      ctx.drawImage(frame.image, x, y, cellWidth, cellHeight);
    });
    return canvas;
  };
  const exportPng = () => {
    const canvas = makeSheet(); if (!canvas) return;
    const link = document.createElement('a'); link.download = 'elemental-realms-sprite-sheet.png';
    link.href = canvas.toDataURL('image/png'); link.click();
  };
  const exportJson = () => {
    const payload = { format: 'elemental-realms-sprite-sheet', version: 1, image: 'elemental-realms-sprite-sheet.png',
      frameWidth: cellWidth, frameHeight: cellHeight, columns, rows, gap, frameCount: frames.length,
      frames: frames.map((frame, index) => ({ name: frame.name, index, x: (index % columns) * (cellWidth + gap),
        y: Math.floor(index / columns) * (cellHeight + gap), width: cellWidth, height: cellHeight })) };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = 'elemental-realms-sprite-sheet.json'; link.click(); URL.revokeObjectURL(url);
  };

  return <><section className="mt-5 rounded-xl border border-[#263248] bg-[#111827] p-3 sm:p-4">
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
      <div><div className="flex items-center gap-2 text-sm font-bold text-white"><Images size={16}/> Sprite Sheet Builder</div>
      <p className="mt-1 text-[10px] text-slate-400">Combine up to 64 image frames into one PNG atlas with matching JSON coordinates.</p></div>
      <label className="cursor-pointer rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950">Add frame images<input className="hidden" type="file" accept="image/*" multiple onChange={(e) => { addFiles(e.target.files); e.currentTarget.value=''; }}/></label>
    </div>
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
      <label className="text-[10px] text-slate-400">Columns<input type="number" min="1" max="16" value={columns} onChange={(e)=>setColumns(Math.max(1,Math.min(16,Number(e.target.value)||1)))} className="mt-1 w-full rounded border border-[#263248] bg-[#0B0D14] p-2 text-xs text-white"/></label>
      <label className="text-[10px] text-slate-400">Frame width<input type="number" min="1" max="512" value={cellWidth} onChange={(e)=>setCellWidth(Math.max(1,Math.min(512,Number(e.target.value)||1)))} className="mt-1 w-full rounded border border-[#263248] bg-[#0B0D14] p-2 text-xs text-white"/></label>
      <label className="text-[10px] text-slate-400">Frame height<input type="number" min="1" max="512" value={cellHeight} onChange={(e)=>setCellHeight(Math.max(1,Math.min(512,Number(e.target.value)||1)))} className="mt-1 w-full rounded border border-[#263248] bg-[#0B0D14] p-2 text-xs text-white"/></label>
      <label className="text-[10px] text-slate-400">Gap<input type="number" min="0" max="32" value={gap} onChange={(e)=>setGap(Math.max(0,Math.min(32,Number(e.target.value)||0)))} className="mt-1 w-full rounded border border-[#263248] bg-[#0B0D14] p-2 text-xs text-white"/></label>
    </div>
    {frames.length > 0 ? <>
      <div className="my-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-400"><span>{frames.length} frames · {sheetWidth} × {sheetHeight}px · {rows} rows</span><button onClick={()=>setFrames([])} className="text-rose-300">Clear frames</button></div>
      <div className="bg-alpha-checker max-h-64 overflow-auto rounded-lg border border-[#263248] p-3"><div className="grid w-max gap-1" style={{gridTemplateColumns:`repeat(${Math.min(columns, frames.length)}, minmax(0, 1fr))`}}>
        {frames.map((frame,index)=><div key={`${frame.name}-${index}`} className="relative flex h-20 w-20 items-center justify-center border border-slate-500/30 bg-black/10"><img src={frame.url} alt={frame.name} className="max-h-full max-w-full object-contain" style={{imageRendering:'pixelated'}}/><button onClick={()=>setFrames((old)=>old.filter((_,i)=>i!==index))} className="absolute right-0 top-0 bg-black/80 px-1 text-xs text-white">×</button></div>)}
      </div></div>
      <div className="mt-3 flex flex-wrap gap-2"><button onClick={exportPng} className="flex items-center gap-2 rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950"><Download size={14}/> Export PNG</button><button onClick={exportJson} className="flex items-center gap-2 rounded-lg border border-amber-500/50 px-3 py-2 text-xs text-amber-300"><FileCode2 size={14}/> Export JSON</button></div>
    </> : <div className="rounded-lg border border-dashed border-[#3B4A62] p-5 text-center text-xs text-slate-500">Add PNG frames to start building your sprite sheet.</div>}
  </section><SpriteSheetSlicer /></>;
}

# ELEMENTAL REALMS Art Studio v2.1.0 — Gemini AI Integration

## What's new
- Gemini AI Assistant panel in the studio.
- Configurable backend URL saved in this browser.
- Dedicated Express backend in `/backend`; Gemini API key is read only from the backend environment.
- Health endpoint: `/health`; chat endpoint: `/api/chat`.
- Creative system guidance for the seven ELEMENTAL REALMS elements.

## Important security
Never put `GEMINI_API_KEY` in frontend code, Vite variables, GitHub Pages, or a committed `.env` file. Set it as a secret environment variable on the backend host. If a key was ever pasted into chat, committed to Git, or exposed in a browser, revoke it and create a new one.

## Deploy frontend
Upload this release ZIP to the root of the GitHub repository as usual. GitHub Actions builds the Vite frontend and deploys GitHub Pages.

## Deploy Gemini backend on Render
1. Push/extract the repository source (including the `backend` folder) to GitHub.
2. In Render, create a new **Web Service** from this repository.
3. Set Root Directory to `backend`, Build Command `npm install`, Start Command `npm start`.
4. Add environment variable `GEMINI_API_KEY` with your private key. Add `ALLOWED_ORIGIN=https://ebecontest.github.io` and `GEMINI_MODEL=gemini-2.5-flash`.
5. Deploy. Open `https://YOUR-SERVICE.onrender.com/health` and confirm `ok: true`.
6. In the studio, open Gemini AI > settings and paste only the Render service URL (not the API key).

The API key is never sent to the browser. The backend currently includes basic input size limits; before public multi-user use, add authentication, rate limiting and usage controls.

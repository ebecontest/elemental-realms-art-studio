# ELEMENTAL REALMS Art Studio — v2.0.0 Sprite Production Studio

Browser-based artwork and sprite production studio for ELEMENTAL REALMS.

## v2.0.0 changes
- Added Sprite Sheet Slicer: import a PNG/WebP/JPEG atlas, define frame width, height and gap, inspect frame previews, select frames, and export extracted frame strips as PNG.
- Added atlas metadata JSON export with source dimensions and per-frame coordinates.
- Existing Sprite Sheet Builder, Pixel Animation Editor, Onion Skin, frame Undo/Redo, Copy/Paste, per-frame timing, loop playback, animation JSON import/export and PNG exports remain available.

## Run locally
```bash
npm ci
npm run dev
```

## Build
```bash
npm ci
npm run build
```

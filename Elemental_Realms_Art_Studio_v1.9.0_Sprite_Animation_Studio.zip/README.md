# ELEMENTAL REALMS Art Studio — v1.9.0 Sprite Animation Studio

Browser-based artwork and sprite studio for ELEMENTAL REALMS.

## v1.9.0 changes
- Per-frame duration control (40–2000 ms), saved and exported in animation JSON.
- Loop playback toggle; playback respects each frame's individual duration.
- Preview background choices: transparent checker, dark, light and forest green.
- Import previously exported ELEMENTAL REALMS animation JSON files.
- Retained Onion Skin, adjustable ghost opacity, frame Undo/Redo, Copy/Paste, sprite-sheet PNG and JSON export.
- New frames use the selected default FPS to set their initial duration.

## Run locally
```bash
npm ci
npm run dev
```

## Build
```bash
npm ci
npm run build
```

import { useCallback, useEffect, useRef, useState, type PointerEvent, type ReactNode } from 'react';
import {
  Brush, Eraser, PaintBucket, Pipette, Grid3X3, Undo2, Redo2,
  Download, FileCode2, Trash2, Plus, Minus, Palette, Info,
} from 'lucide-react';

type Tool = 'pencil' | 'eraser' | 'fill' | 'picker';
type Snapshot = { pixels: string[]; width: number; height: number };

const TRANSPARENT = '';
const STARTER_COLORS = [
  '#111827', '#334155', '#64748B', '#CBD5E1', '#FFFFFF',
  '#7F1D1D', '#EF4444', '#F97316', '#F59E0B', '#FDE047',
  '#14532D', '#22C55E', '#86EFAC', '#164E63', '#06B6D4',
  '#1E3A8A', '#3B82F6', '#93C5FD', '#581C87', '#A855F7',
  '#DB2777', '#F9A8D4', '#92400E', '#D6A56D',
];

function makeBlank(width: number, height: number) {
  return Array(width * height).fill(TRANSPARENT) as string[];
}

function loadPixelWorkspace(): Snapshot {
  try {
    const raw = localStorage.getItem('elemental-realms-pixel-editor-v1');
    if (raw) {
      const saved = JSON.parse(raw);
      if (Number.isInteger(saved.width) && Number.isInteger(saved.height) && saved.width >= 8 && saved.width <= 128 && saved.height >= 8 && saved.height <= 128 && Array.isArray(saved.pixels) && saved.pixels.length === saved.width * saved.height) {
        return { width: saved.width, height: saved.height, pixels: saved.pixels.map((v: unknown) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v : '') };
      }
    }
  } catch { /* Start with a blank canvas if browser storage is unavailable. */ }
  return { width: 32, height: 32, pixels: makeBlank(32, 32) };
}

export function PixelEditor() {
  const [initialWorkspace] = useState(loadPixelWorkspace);
  const [width, setWidth] = useState(initialWorkspace.width);
  const [height, setHeight] = useState(initialWorkspace.height);
  const [pixels, setPixels] = useState<string[]>(initialWorkspace.pixels);
  const [tool, setTool] = useState<Tool>('pencil');
  const [color, setColor] = useState('#38BDF8');
  const [showGrid, setShowGrid] = useState(true);
  const [zoom, setZoom] = useState(12);
  const [history, setHistory] = useState<Snapshot[]>([]);
  const [future, setFuture] = useState<Snapshot[]>([]);
  const [drawing, setDrawing] = useState(false);
  const [lastPoint, setLastPoint] = useState<number | null>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const snapshot = useCallback((): Snapshot => ({ pixels: [...pixels], width, height }), [pixels, width, height]);
  const remember = useCallback(() => {
    setHistory((items) => [...items.slice(-39), snapshot()]);
    setFuture([]);
  }, [snapshot]);

  const drawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const scale = Math.max(1, Math.min(24, zoom));
    canvas.width = width * scale;
    canvas.height = height * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = false;
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const value = pixels[y * width + x];
        if (value) {
          ctx.fillStyle = value;
          ctx.fillRect(x * scale, y * scale, scale, scale);
        }
      }
    }
    if (showGrid && scale >= 5) {
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(100,116,139,0.35)';
      ctx.lineWidth = 1;
      for (let x = 0; x <= width; x++) { ctx.moveTo(x * scale + .5, 0); ctx.lineTo(x * scale + .5, height * scale); }
      for (let y = 0; y <= height; y++) { ctx.moveTo(0, y * scale + .5); ctx.lineTo(width * scale, y * scale + .5); }
      ctx.stroke();
    }
  }, [pixels, width, height, zoom, showGrid]);

  useEffect(() => { drawCanvas(); }, [drawCanvas]);

  useEffect(() => {
    try { localStorage.setItem('elemental-realms-pixel-editor-v1', JSON.stringify({ width, height, pixels })); }
    catch { /* Keep editing even if storage is full; users can export PNG/JSON. */ }
  }, [width, height, pixels]);

  const pointFromEvent = (event: PointerEvent<HTMLCanvasElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = Math.max(0, Math.min(width - 1, Math.floor((event.clientX - rect.left) / rect.width * width)));
    const y = Math.max(0, Math.min(height - 1, Math.floor((event.clientY - rect.top) / rect.height * height)));
    return y * width + x;
  };

  const applyAt = (index: number) => {
    if (index < 0 || index >= width * height) return;
    if (tool === 'picker') {
      if (pixels[index]) setColor(pixels[index]);
      setTool('pencil');
      return;
    }
    if (tool === 'fill') {
      const target = pixels[index];
      if (target === color) return;
      const next = [...pixels];
      const stack = [index];
      const seen = new Set<number>();
      while (stack.length) {
        const current = stack.pop()!;
        if (seen.has(current) || next[current] !== target) continue;
        seen.add(current);
        next[current] = color;
        const x = current % width;
        const y = Math.floor(current / width);
        if (x > 0) stack.push(current - 1);
        if (x < width - 1) stack.push(current + 1);
        if (y > 0) stack.push(current - width);
        if (y < height - 1) stack.push(current + width);
      }
      setPixels(next);
      return;
    }
    const value = tool === 'eraser' ? TRANSPARENT : color;
    setPixels((prev) => {
      if (prev[index] === value) return prev;
      const next = [...prev];
      next[index] = value;
      return next;
    });
  };

  const onPointerDown = (event: PointerEvent<HTMLCanvasElement>) => {
    event.preventDefault();
    const index = pointFromEvent(event);
    remember();
    if (tool === 'fill' || tool === 'picker') { applyAt(index); return; }
    setDrawing(true);
    setLastPoint(index);
    applyAt(index);
    event.currentTarget.setPointerCapture(event.pointerId);
  };

  const onPointerMove = (event: PointerEvent<HTMLCanvasElement>) => {
    if (!drawing) return;
    const index = pointFromEvent(event);
    if (index === lastPoint) return;
    applyAt(index);
    setLastPoint(index);
  };

  const onPointerUp = () => { setDrawing(false); setLastPoint(null); };

  const resizeCanvas = (nextWidth: number, nextHeight: number) => {
    remember();
    const next = makeBlank(nextWidth, nextHeight);
    const copyWidth = Math.min(width, nextWidth);
    const copyHeight = Math.min(height, nextHeight);
    for (let y = 0; y < copyHeight; y++) {
      for (let x = 0; x < copyWidth; x++) next[y * nextWidth + x] = pixels[y * width + x];
    }
    setWidth(nextWidth); setHeight(nextHeight); setPixels(next);
  };

  const undo = () => {
    if (!history.length) return;
    setFuture((items) => [...items, snapshot()]);
    const previous = history[history.length - 1];
    setHistory((items) => items.slice(0, -1));
    setPixels(previous.pixels); setWidth(previous.width); setHeight(previous.height);
  };
  const redo = () => {
    if (!future.length) return;
    setHistory((items) => [...items, snapshot()]);
    const next = future[future.length - 1];
    setFuture((items) => items.slice(0, -1));
    setPixels(next.pixels); setWidth(next.width); setHeight(next.height);
  };

  const exportPng = () => {
    const out = document.createElement('canvas');
    out.width = width; out.height = height;
    const ctx = out.getContext('2d');
    if (!ctx) return;
    pixels.forEach((value, index) => {
      if (!value) return;
      ctx.fillStyle = value;
      ctx.fillRect(index % width, Math.floor(index / width), 1, 1);
    });
    const link = document.createElement('a');
    link.download = `er_pixel_art_${width}x${height}.png`;
    link.href = out.toDataURL('image/png');
    link.click();
  };

  const exportJson = () => {
    const payload = {
      format: 'elemental-realms-pixel-art', version: 1,
      width, height, colorMode: 'RGBA', transparent: true,
      pixels: pixels.map((value) => value || null),
      palette: Array.from(new Set(pixels.filter(Boolean))),
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url; link.download = `er_pixel_art_${width}x${height}.json`; link.click();
    URL.revokeObjectURL(url);
  };

  const importPng = (file?: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      const nextWidth = Math.min(128, Math.max(1, image.naturalWidth));
      const nextHeight = Math.min(128, Math.max(1, image.naturalHeight));
      const temp = document.createElement('canvas'); temp.width = nextWidth; temp.height = nextHeight;
      const ctx = temp.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(image, 0, 0, nextWidth, nextHeight);
      const data = ctx.getImageData(0, 0, nextWidth, nextHeight).data;
      const next: string[] = [];
      for (let i = 0; i < data.length; i += 4) {
        next.push(data[i + 3] < 16 ? '' : `#${[data[i], data[i + 1], data[i + 2]].map((v) => v.toString(16).padStart(2, '0')).join('')}`);
      }
      remember(); setWidth(nextWidth); setHeight(nextHeight); setPixels(next); URL.revokeObjectURL(url);
    };
    image.onerror = () => URL.revokeObjectURL(url);
    image.src = url;
  };

  const toolButton = (id: Tool, label: string, icon: ReactNode) => (
    <button key={id} onClick={() => setTool(id)} title={label} className={`flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold border ${tool === id ? 'bg-sky-500/15 border-sky-400/60 text-sky-300' : 'bg-[#111827] border-[#263248] text-slate-300 hover:border-slate-500'}`}>
      {icon}<span>{label}</span>
    </button>
  );

  return (
    <div className="pixel-editor-root flex-1 min-h-0 overflow-auto bg-[#0B0D14] p-3 sm:p-5">
      <div className="mx-auto max-w-6xl space-y-4">
        <div className="pixel-editor-heading flex flex-wrap items-center justify-between gap-3">
          <div><div className="text-sm font-bold tracking-wide text-white">PIXEL ART EDITOR <span className="ml-2 rounded bg-sky-400/15 px-2 py-0.5 text-[10px] text-sky-300">BETA</span></div><p className="mt-1 text-xs text-slate-400">Draw game sprites directly in your browser. Transparent PNG + editable pixel JSON.</p></div>
          <div className="pixel-editor-actions flex flex-wrap gap-2">
            <button onClick={undo} disabled={!history.length} className="rounded-lg border border-[#263248] p-2 text-slate-300 disabled:opacity-30" title="Undo"><Undo2 size={16}/></button>
            <button onClick={redo} disabled={!future.length} className="rounded-lg border border-[#263248] p-2 text-slate-300 disabled:opacity-30" title="Redo"><Redo2 size={16}/></button>
            <button onClick={() => { if (window.confirm('Clear the whole canvas?')) { remember(); setPixels(makeBlank(width, height)); } }} className="flex items-center gap-2 rounded-lg border border-rose-900/70 px-3 py-2 text-xs text-rose-300"><Trash2 size={14}/> Clear</button>
            <button onClick={exportPng} className="flex items-center gap-2 rounded-lg bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950"><Download size={14}/> PNG</button>
            <button onClick={exportJson} className="flex items-center gap-2 rounded-lg border border-amber-500/50 px-3 py-2 text-xs font-semibold text-amber-300"><FileCode2 size={14}/> JSON</button>
          </div>
        </div>

        <div className="pixel-editor-layout grid gap-4 lg:grid-cols-[250px_minmax(0,1fr)]">
          <aside className="pixel-editor-tools space-y-4 rounded-xl border border-[#263248] bg-[#111827] p-3">
            <section><div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">Tools</div><div className="grid grid-cols-2 gap-2">
              {toolButton('pencil', 'Pencil', <Brush size={15}/>)}
              {toolButton('eraser', 'Eraser', <Eraser size={15}/>)}
              {toolButton('fill', 'Bucket', <PaintBucket size={15}/>)}
              {toolButton('picker', 'Picker', <Pipette size={15}/>)}
            </div></section>
            <section><div className="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-slate-400"><Palette size={13}/> Color</div><div className="flex items-center gap-2"><input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-10 w-12 cursor-pointer rounded border-0 bg-transparent"/><input value={color.toUpperCase()} onChange={(e) => /^#[0-9A-Fa-f]{6}$/.test(e.target.value) && setColor(e.target.value)} className="min-w-0 flex-1 rounded-lg border border-[#263248] bg-[#0B0D14] px-2 py-2 font-mono text-xs text-white"/></div><div className="mt-3 grid grid-cols-6 gap-1.5">{STARTER_COLORS.map((swatch) => <button key={swatch} onClick={() => setColor(swatch)} title={swatch} className={`aspect-square rounded-md border ${color.toLowerCase() === swatch.toLowerCase() ? 'border-white ring-2 ring-sky-400' : 'border-white/10'}`} style={{backgroundColor:swatch}}/>)}</div></section>
            <section><div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">Canvas size</div><div className="grid grid-cols-2 gap-2">{[16,32,48,64,96,128].map((size) => <button key={size} onClick={() => resizeCanvas(size,size)} className={`rounded-lg border px-2 py-2 text-xs ${width===size&&height===size?'border-sky-400 bg-sky-500/10 text-sky-300':'border-[#263248] text-slate-300'}`}>{size} × {size}</button>)}</div><div className="mt-2 flex items-center gap-2 text-[11px] text-slate-500"><span>Custom:</span><button onClick={() => resizeCanvas(Math.max(8,width-8),height)} className="rounded border border-[#263248] p-1"><Minus size={12}/></button><span>{width} × {height}</span><button onClick={() => resizeCanvas(Math.min(128,width+8),height)} className="rounded border border-[#263248] p-1"><Plus size={12}/></button></div></section>
            <section><div className="mb-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">View</div><label className="flex items-center justify-between py-1 text-xs text-slate-300"><span className="flex items-center gap-2"><Grid3X3 size={14}/> Pixel grid</span><input type="checkbox" checked={showGrid} onChange={(e)=>setShowGrid(e.target.checked)}/></label><div className="mt-2 flex items-center justify-between text-xs text-slate-300"><span>Zoom</span><span>{zoom}×</span></div><input type="range" min="4" max="24" value={zoom} onChange={(e)=>setZoom(Number(e.target.value))} className="w-full accent-sky-400"/></section>
            <label className="block cursor-pointer rounded-lg border border-dashed border-[#3B4A62] p-3 text-center text-xs text-slate-300 hover:border-sky-400">Import PNG / JPG<input type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e)=>{importPng(e.target.files?.[0]);e.currentTarget.value='';}}/></label>
          </aside>

          <section className="pixel-editor-canvas-panel flex min-h-[440px] flex-col rounded-xl border border-[#263248] bg-[#111827] p-3 sm:p-5">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><div className="text-xs font-semibold text-slate-300">Canvas <span className="ml-2 font-mono text-sky-300">{width} × {height}px</span></div><div className="text-[10px] text-slate-500">Active tool: {tool}</div></div>
            <div className="pixel-editor-canvas-stage bg-alpha-checker flex flex-1 items-center justify-center overflow-auto rounded-lg border border-[#263248] p-4 sm:p-6">
              <canvas ref={canvasRef} onPointerDown={onPointerDown} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} className="max-h-full max-w-full touch-none cursor-crosshair shadow-[0_12px_45px_rgba(0,0,0,.45)]" style={{width:`min(${width*zoom}px, 100%)`, height:'auto', aspectRatio:`${width}/${height}`, imageRendering:'pixelated', touchAction:'none'}} />
            </div>
            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[10px] text-slate-500"><span className="flex items-center gap-1"><Info size={12}/> Transparent pixels are preserved in PNG export.</span><span>{pixels.filter(Boolean).length} painted pixels</span></div>
          </section>
        </div>
      </div>
    </div>
  );
}

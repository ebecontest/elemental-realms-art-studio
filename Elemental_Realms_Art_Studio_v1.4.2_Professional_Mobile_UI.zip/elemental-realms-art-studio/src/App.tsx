import { useEffect, useMemo, useState } from 'react';
import {
  AnimationId,
  AtlasSettings,
  CharacterCustomization,
  FrameData,
} from './types/sprite';
import { ANIMATION_CONFIGS, buildDefaultFrames } from './data/presets';
import {
  downloadCanvasAsPng,
  downloadJsonString,
  generateSpriteSheetAndJson,
  generateImportedImageAsset,
} from './engine/atlasGenerator';
import { TopToolbar } from './components/TopToolbar';
import { LeftDeck } from './components/LeftDeck';
import { CenterViewport } from './components/CenterViewport';
import { BottomTimeline } from './components/BottomTimeline';
import { RightInspector } from './components/RightInspector';
import { PixelEditor } from './components/PixelEditor';

const DEFAULT_CUSTOMIZATION: CharacterCustomization = {
  paletteId: 'solaris-archon',
  propType: 'none',
  browGemType: 'sapphire-diamond',
  auraStyle: 'mana-motes',
  renderStyle: 'pixel-art-64',
  flipX: false,
  outlineThickness: 1.0,
  glowIntensity: 1.0,
  topPlumeScale: 1.0,
  backRibbonScale: 1.0,
  customUploadedImage: null,
  useUploadedImageAsBase: false,
};

const DEFAULT_ATLAS_SETTINGS: AtlasSettings = {
  projectName: 'er_fire_character',
  format: 'phaser-hash',
  scope: 'all-animations',
  layoutMode: 'rows-by-animation',
  frameSize: 256,
  padding: 4,
  extrude: false,
  powerOfTwo: false,
  maxColumns: 8,
  transparentBackground: true,
  bgColor: '#000000',
};

async function loadProjectImage(dataUrl: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Could not restore the imported artwork image.'));
    image.src = dataUrl;
  });
}

export function App() {
  const [framesByAnim, setFramesByAnim] = useState<Record<AnimationId, FrameData[]>>(() =>
    buildDefaultFrames()
  );
  const [activeAnimId, setActiveAnimId] = useState<AnimationId>('idle');
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [fpsByAnim, setFpsByAnim] = useState<Record<AnimationId, number>>({
    idle: 10,
    move: 12,
    cast: 12,
    attack: 14,
    hit: 12,
    defeat: 10,
  });
  const [loopModeByAnim, setLoopModeByAnim] = useState<
    Record<AnimationId, 'loop' | 'ping-pong' | 'once'>
  >({
    idle: 'loop',
    move: 'loop',
    cast: 'loop',
    attack: 'loop',
    hit: 'loop',
    defeat: 'loop',
  });
  const [pingPongDir, setPingPongDir] = useState<1 | -1>(1);
  const [onionSkin, setOnionSkin] = useState<boolean>(false);

  const [customization, setCustomization] = useState<CharacterCustomization>(
    DEFAULT_CUSTOMIZATION
  );
  const [settings, setSettings] = useState<AtlasSettings>(DEFAULT_ATLAS_SETTINGS);
  const [exportSuccessMessage, setExportSuccessMessage] = useState<string | null>(null);
  const [projectMessage, setProjectMessage] = useState<string | null>(null);
  const [projectReady, setProjectReady] = useState(false);
  const [editorMode, setEditorMode] = useState(false);

  const activeFrames = framesByAnim[activeAnimId] || [];
  const safeFrameIndex = Math.min(activeFrameIndex, Math.max(0, activeFrames.length - 1));
  const currentFrame = activeFrames[safeFrameIndex];
  const currentFps = fpsByAnim[activeAnimId] || 10;
  const currentLoopMode = loopModeByAnim[activeAnimId] || 'loop';

  // Restore the last lightweight browser workspace once on startup.
  useEffect(() => {
    let cancelled = false;
    const restore = async () => {
      try {
        const raw = localStorage.getItem('elemental-realms-art-studio-project-v1');
        if (raw) {
          const data = JSON.parse(raw);
          if (data?.schemaVersion === 1 && data.framesByAnim && data.settings) {
            let uploadedImage: HTMLImageElement | null = null;
            if (typeof data.customization?.uploadedImageDataUrl === 'string') {
              uploadedImage = await loadProjectImage(data.customization.uploadedImageDataUrl);
            }
            if (!cancelled) {
              setFramesByAnim(data.framesByAnim);
              setActiveAnimId(data.activeAnimId || 'idle');
              setActiveFrameIndex(data.activeFrameIndex || 0);
              setFpsByAnim(data.fpsByAnim || { idle: 10, move: 12, cast: 12, attack: 14, hit: 12, defeat: 10 });
              setLoopModeByAnim(data.loopModeByAnim || { idle: 'loop', move: 'loop', cast: 'loop', attack: 'loop', hit: 'loop', defeat: 'loop' });
              setCustomization({ ...DEFAULT_CUSTOMIZATION, ...data.customization, customUploadedImage: uploadedImage });
              setSettings({ ...DEFAULT_ATLAS_SETTINGS, ...data.settings });
              setProjectMessage('Restored your last browser project');
            }
          }
        }
      } catch (error) {
        console.warn('Could not restore the last studio project:', error);
      } finally {
        if (!cancelled) setProjectReady(true);
      }
    };
    restore();
    return () => { cancelled = true; };
  }, []);

  // Keep a recovery copy in this browser. The downloadable project file is the portable backup.
  useEffect(() => {
    if (!projectReady) return;
    try {
      const imageSrc = customization.customUploadedImage?.src || null;
      const payload = {
        schemaVersion: 1,
        framesByAnim, activeAnimId, activeFrameIndex, fpsByAnim, loopModeByAnim,
        customization: { ...customization, customUploadedImage: undefined, uploadedImageDataUrl: imageSrc },
        settings,
      };
      localStorage.setItem('elemental-realms-art-studio-project-v1', JSON.stringify(payload));
    } catch (error) {
      console.warn('Browser auto-save is full; use Save Project to download a backup.', error);
      setProjectMessage('Browser storage is full — download a project backup');
    }
  }, [projectReady, framesByAnim, activeAnimId, fpsByAnim, loopModeByAnim, customization, settings]);

  // Playback timer
  useEffect(() => {
    if (!isPlaying || activeFrames.length <= 1) return;

    const intervalMs = Math.max(24, Math.round(1000 / currentFps));
    const timer = setInterval(() => {
      setActiveFrameIndex((prev) => {
        const len = activeFrames.length;
        if (currentLoopMode === 'loop') {
          return (prev + 1) % len;
        }
        if (currentLoopMode === 'ping-pong') {
          const next = prev + pingPongDir;
          if (next >= len - 1) {
            setPingPongDir(-1);
            return len - 1;
          }
          if (next <= 0) {
            setPingPongDir(1);
            return 0;
          }
          return next;
        }
        // 'once'
        if (prev + 1 >= len) {
          return 0;
        }
        return prev + 1;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isPlaying, activeFrames.length, currentFps, currentLoopMode, pingPongDir]);

  // Generate packed .PNG sprite sheet & .JSON texture atlas in real time
  const atlasResult = useMemo(() => {
    return generateSpriteSheetAndJson(
      framesByAnim,
      activeAnimId,
      customization,
      settings
    );
  }, [framesByAnim, activeAnimId, customization, settings]);

  const importedAsset = useMemo(() => {
    if (!customization.useUploadedImageAsBase || !customization.customUploadedImage) return null;
    return generateImportedImageAsset(customization.customUploadedImage, settings, customization);
  }, [customization, settings]);

  const handleSelectAnim = (id: AnimationId) => {
    setActiveAnimId(id);
    setActiveFrameIndex(0);
    setPingPongDir(1);
  };

  const handleUpdateCustomization = (partial: Partial<CharacterCustomization>) => {
    setCustomization((prev) => ({ ...prev, ...partial }));
  };

  const handleUpdateSettings = (partial: Partial<AtlasSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const handleUpdateCurrentFrame = (partial: Partial<FrameData>) => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (!list[safeFrameIndex]) return prev;
      list[safeFrameIndex] = { ...list[safeFrameIndex], ...partial };
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleApplyPivotToAllFrames = (pivot: { x: number; y: number }) => {
    setFramesByAnim((prev) => {
      const list = (prev[activeAnimId] || []).map((f) => ({
        ...f,
        pivot: { ...pivot },
      }));
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleAddFrame = () => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (list.length >= 16) return prev;
      const animCfg = ANIMATION_CONFIGS.find((a) => a.id === activeAnimId)!;
      const newIdx = list.length;
      const template = list[list.length - 1] || list[0];
      list.push({
        ...template,
        index: newIdx,
        frameNumber: newIdx + 1,
        name: `wisp_mage_${animCfg.label}_${String(newIdx).padStart(2, '0')}`,
      });
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleRemoveFrame = () => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (list.length <= 2) return prev;
      list.pop();
      return { ...prev, [activeAnimId]: list };
    });
    setActiveFrameIndex((prev) => Math.max(0, prev - 1));
  };

  const buildProjectPayload = () => ({
    app: 'ELEMENTAL REALMS Art Studio',
    schemaVersion: 1,
    savedAt: new Date().toISOString(),
    framesByAnim,
    activeAnimId,
    activeFrameIndex: safeFrameIndex,
    fpsByAnim,
    loopModeByAnim,
    customization: {
      ...customization,
      customUploadedImage: undefined,
      uploadedImageDataUrl: customization.customUploadedImage?.src || null,
    },
    settings,
  });

  const handleSaveProject = () => {
    const payload = buildProjectPayload();
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${settings.projectName || 'elemental-realms-project'}.erproject.json`;
    link.click();
    URL.revokeObjectURL(url);
    setProjectMessage('Project backup downloaded');
  };

  const handleOpenProject = async (file: File) => {
    try {
      const data = JSON.parse(await file.text());
      if (data?.app !== 'ELEMENTAL REALMS Art Studio' || data?.schemaVersion !== 1 || !data.framesByAnim || !data.settings) {
        throw new Error('This is not a supported Art Studio project file.');
      }
      let uploadedImage: HTMLImageElement | null = null;
      if (typeof data.customization?.uploadedImageDataUrl === 'string' && data.customization.uploadedImageDataUrl) {
        uploadedImage = await loadProjectImage(data.customization.uploadedImageDataUrl);
      }
      setFramesByAnim(data.framesByAnim);
      setActiveAnimId(data.activeAnimId || 'idle');
      setActiveFrameIndex(data.activeFrameIndex || 0);
      setFpsByAnim(data.fpsByAnim || { idle: 10, move: 12, cast: 12, attack: 14, hit: 12, defeat: 10 });
      setLoopModeByAnim(data.loopModeByAnim || { idle: 'loop', move: 'loop', cast: 'loop', attack: 'loop', hit: 'loop', defeat: 'loop' });
      setCustomization({ ...DEFAULT_CUSTOMIZATION, ...data.customization, customUploadedImage: uploadedImage });
      setSettings({ ...DEFAULT_ATLAS_SETTINGS, ...data.settings });
      setIsPlaying(false);
      setProjectMessage(`Opened ${file.name}`);
    } catch (error) {
      setProjectMessage(error instanceof Error ? error.message : 'Could not open project file');
    }
  };

  const handleNewProject = () => {
    if (!window.confirm('Start a new project? Download a backup first if you want to keep this work.')) return;
    setFramesByAnim(buildDefaultFrames());
    setActiveAnimId('idle');
    setActiveFrameIndex(0);
    setFpsByAnim({ idle: 10, move: 12, cast: 12, attack: 14, hit: 12, defeat: 10 });
    setLoopModeByAnim({ idle: 'loop', move: 'loop', cast: 'loop', attack: 'loop', hit: 'loop', defeat: 'loop' });
    setCustomization(DEFAULT_CUSTOMIZATION);
    setSettings(DEFAULT_ATLAS_SETTINGS);
    setIsPlaying(true);
    setProjectMessage('New project created');
  };

  const showToast = (msg: string) => {
    setExportSuccessMessage(msg);
    setTimeout(() => setExportSuccessMessage(null), 2200);
  };

  const handleDownloadPng = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadCanvasAsPng(imageAsset?.canvas || atlasResult.canvas, `${settings.projectName}.png`);
    showToast('Saved .PNG!');
  };

  const handleDownloadJson = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadJsonString(imageAsset?.jsonString || atlasResult.jsonString, `${settings.projectName}.json`);
    showToast('Saved .JSON!');
  };

  const handleDownloadBundle = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadCanvasAsPng(imageAsset?.canvas || atlasResult.canvas, `${settings.projectName}.png`);
    setTimeout(() => {
      downloadJsonString(imageAsset?.jsonString || atlasResult.jsonString, `${settings.projectName}.json`);
    }, 180);
    showToast('Exported .PNG + .JSON!');
  };

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-[#0B0D14] text-[#F1F5F9]">
      {/* Top Studio Header Toolbar (56px) */}
      <TopToolbar
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        customization={customization}
        onUpdateCustomization={handleUpdateCustomization}
        onDownloadPng={handleDownloadPng}
        onDownloadJson={handleDownloadJson}
        onDownloadBundle={handleDownloadBundle}
        sheetDimensions={{
          width: atlasResult?.width || 0,
          height: atlasResult?.height || 0,
        }}
        totalPackedFrames={atlasResult?.packedFrames.length || 0}
        exportSuccessMessage={exportSuccessMessage}
        projectMessage={projectMessage}
        onSaveProject={handleSaveProject}
        onOpenProject={handleOpenProject}
        onNewProject={handleNewProject}
        editorMode={editorMode}
        onToggleEditorMode={() => setEditorMode((value) => !value)}
      />

      {/* Main Studio Workspace */}
      {editorMode ? <PixelEditor /> : <div className="workspace flex-1 flex overflow-hidden min-h-0">
        {/* Left Deck: Animation Clips, Style & Rig, Packing Settings (280px) */}
        <LeftDeck
          activeAnimId={activeAnimId}
          onSelectAnim={handleSelectAnim}
          framesByAnim={framesByAnim}
          customization={customization}
          onUpdateCustomization={handleUpdateCustomization}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onResetCharacter={() => setCustomization(DEFAULT_CUSTOMIZATION)}
        />

        {/* Center Interactive Viewport + Bottom Scrubber Timeline */}
        <div className="center-workspace flex-1 flex flex-col min-w-0 overflow-hidden">
          <CenterViewport
            activeAnimId={activeAnimId}
            activeFrameIndex={safeFrameIndex}
            onSelectFrame={(animId, fIdx) => {
              setActiveAnimId(animId);
              setActiveFrameIndex(fIdx);
            }}
            framesByAnim={framesByAnim}
            onUpdateCurrentFrame={handleUpdateCurrentFrame}
            customization={customization}
            settings={settings}
            atlasResult={atlasResult}
            importedAsset={importedAsset}
            onionSkin={onionSkin}
            onToggleOnionSkin={() => setOnionSkin((o) => !o)}
          />

          <BottomTimeline
            activeAnimId={activeAnimId}
            frames={activeFrames}
            activeFrameIndex={safeFrameIndex}
            onSelectFrameIndex={(idx) => {
              setIsPlaying(false);
              setActiveFrameIndex(idx);
            }}
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying((p) => !p)}
            fps={currentFps}
            onChangeFps={(fps) =>
              setFpsByAnim((prev) => ({ ...prev, [activeAnimId]: fps }))
            }
            loopMode={currentLoopMode}
            onChangeLoopMode={(mode) =>
              setLoopModeByAnim((prev) => ({ ...prev, [activeAnimId]: mode }))
            }
            customization={customization}
            onAddFrame={handleAddFrame}
            onRemoveFrame={handleRemoveFrame}
            onUpdateFrameDuration={(durationMs) =>
              handleUpdateCurrentFrame({ durationMs })
            }
          />
        </div>

        {/* Right Inspector & Live .JSON Atlas Code Drawer (340px) */}
        <RightInspector
          activeAnimId={activeAnimId}
          activeFrameIndex={safeFrameIndex}
          currentFrame={currentFrame}
          onUpdateCurrentFrame={handleUpdateCurrentFrame}
          onApplyPivotToAllFrames={handleApplyPivotToAllFrames}
          settings={settings}
          atlasResult={atlasResult}
          jsonString={importedAsset?.jsonString || atlasResult?.jsonString || ''}
          isImportedAsset={Boolean(importedAsset)}
          onDownloadJson={handleDownloadJson}
        />
      </div>}
    </div>
  );
}

export default App;

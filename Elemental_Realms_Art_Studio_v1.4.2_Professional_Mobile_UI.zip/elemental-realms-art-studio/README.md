# ELEMENTAL REALMS Art Studio — v1.4.1 Mobile UI Polish

Browser-based artwork and sprite studio for ELEMENTAL REALMS.

## v1.4.1 changes
- Refined dark studio styling, spacing, borders, focus states and scroll behavior.
- Mobile-first toolbar with horizontally scrollable actions.
- Mobile workspace prioritizes the preview/canvas and stacks inspector panels cleanly.
- Pixel editor controls and canvas adapt to narrow Android screens and touch input.
- Tablet widths use a more compact inspector layout.

## Run locally

```bash
npm ci
npm run dev
```

## Build

```bash
npm ci
npm run build
```

## Exports
PNG artwork and JSON metadata remain supported. Project backup and browser autosave remain available.

# ELEMENTAL REALMS Art Studio — v1.8.0 Animation Tools Pro

Browser-based artwork and sprite studio for ELEMENTAL REALMS.

## v1.8.0 changes
- Added frame-level Undo and Redo with a 40-step history.
- Undo/Redo covers drawing strokes and frame structure edits (add, duplicate, delete, reorder and resize).
- Added Copy and Paste frame tools for reusable animation poses.
- Retained Onion Skin, adjustable ghost opacity, playback, sprite-sheet PNG export and animation JSON export.
- Animation workspace autosaves in the browser.

## Run locally
```bash
npm ci
npm run dev
```

## Build
```bash
npm ci
npm run build
```

import React, { useRef } from 'react';
import {
  Sparkles,
  Download,
  FileCode2,
  Image as ImageIcon,
  Upload,
  Layers,
  Check,
  Save,
  FolderOpen,
  FilePlus2,
  Grid3X3,
} from 'lucide-react';
import {
  AtlasFormat,
  AtlasSettings,
  CharacterCustomization,
  RenderStyle,
} from '../types/sprite';

interface TopToolbarProps {
  settings: AtlasSettings;
  onUpdateSettings: (partial: Partial<AtlasSettings>) => void;
  customization: CharacterCustomization;
  onUpdateCustomization: (partial: Partial<CharacterCustomization>) => void;
  onDownloadPng: () => void;
  onDownloadJson: () => void;
  onDownloadBundle: () => void;
  sheetDimensions: { width: number; height: number };
  totalPackedFrames: number;
  exportSuccessMessage: string | null;
  projectMessage: string | null;
  onSaveProject: () => void;
  onOpenProject: (file: File) => void;
  onNewProject: () => void;
  editorMode: boolean;
  onToggleEditorMode: () => void;
}

export const TopToolbar: React.FC<TopToolbarProps> = ({
  settings,
  onUpdateSettings,
  customization,
  onUpdateCustomization,
  onDownloadPng,
  onDownloadJson,
  onDownloadBundle,
  sheetDimensions,
  totalPackedFrames,
  exportSuccessMessage,
  projectMessage,
  onSaveProject,
  onOpenProject,
  onNewProject,
  editorMode,
  onToggleEditorMode,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const projectInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        onUpdateCustomization({
          customUploadedImage: img,
          useUploadedImageAsBase: true,
        });
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  return (
    <header className="studio-toolbar h-14 bg-[#121622] border-b border-[#232A3E] px-3.5 flex items-center justify-between select-none shrink-0 z-20">
      {/* Left Brand + Editable Asset Filename */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#38BDF8] via-[#2563EB] to-[#F59E0B] p-[1px] shadow-[0_0_16px_rgba(56,189,248,0.3)]">
            <div className="w-full h-full bg-[#0B0D14] rounded-[7px] flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-[#38BDF8]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-display font-bold text-sm tracking-tight text-[#F1F5F9]">
                ELEMENTAL REALMS
              </span>
              <span className="text-[10px] font-mono-code uppercase px-1.5 py-0.5 rounded bg-[#38BDF8]/15 text-[#38BDF8] border border-[#38BDF8]/30 font-semibold">
                PNG + JSON
              </span>
            </div>
            <p className="text-[10px] text-[#64748B] leading-none mt-0.5">
              Game Artwork &amp; Sprite Studio
            </p>
          </div>
        </div>

        <div className="h-6 w-[1px] bg-[#232A3E] mx-1 hidden sm:block" />

        {/* Asset Base Filename Input */}
        <div className="hidden md:flex items-center bg-[#0B0D14] border border-[#232A3E] focus-within:border-[#38BDF8] rounded-md px-2.5 py-1 gap-1.5">
          <span className="text-[11px] text-[#64748B] font-mono-code">asset:</span>
          <input
            type="text"
            value={settings.projectName}
            onChange={(e) =>
              onUpdateSettings({
                projectName: e.target.value.replace(/[^a-zA-Z0-9_-]/g, '_'),
              })
            }
            className="bg-transparent text-xs font-mono-code text-[#F1F5F9] focus:outline-none w-36"
            placeholder="er_fire_character"
            title="Base filename for exported .png and .json files"
          />
          <span className="text-[10px] font-mono-code text-[#64748B]">.png/.json</span>
        </div>

        {/* Dimensions & Frame Badge */}
        <div className="hidden xl:flex items-center gap-2 bg-[#1A2030]/70 border border-[#232A3E] rounded-md px-2.5 py-1 text-[11px] font-mono-code text-[#94A3B8]">
          <span className="text-[#38BDF8] font-medium">
            {sheetDimensions.width}×{sheetDimensions.height}px
          </span>
          <span className="text-[#64748B]">•</span>
          <span>{totalPackedFrames} frames</span>
        </div>
      </div>

      {/* Center-Right Quick Pipeline Controls */}
      <div className="flex items-center gap-2">
        {/* Project workspace: portable save/open plus browser recovery */}
        <input
          ref={projectInputRef}
          type="file"
          accept=".json,.erproject.json,application/json"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onOpenProject(file);
            e.currentTarget.value = '';
          }}
          className="hidden"
        />
        <button onClick={onToggleEditorMode} className={`flex items-center gap-1.5 rounded-md border px-2.5 py-1.5 text-xs font-semibold transition-colors ${editorMode ? 'border-sky-400/60 bg-sky-500/15 text-sky-300' : 'border-[#334155] bg-[#0B0D14] text-slate-300 hover:border-sky-400/50'}`} title="Switch between Sprite Rig and Pixel Art Editor">
          <Grid3X3 className="h-3.5 w-3.5" /><span className="hidden sm:inline">{editorMode ? 'Sprite Rig' : 'Pixel Editor'}</span>
        </button>
        <div className="flex items-center gap-1 border border-[#334155] rounded-md p-0.5 bg-[#0B0D14]" title={projectMessage || 'Project workspace'}>
          <button onClick={onNewProject} className="p-1.5 rounded text-[#94A3B8] hover:text-white hover:bg-[#1A2030]" title="New project"><FilePlus2 className="w-4 h-4" /></button>
          <button onClick={() => projectInputRef.current?.click()} className="p-1.5 rounded text-[#94A3B8] hover:text-white hover:bg-[#1A2030]" title="Open project"><FolderOpen className="w-4 h-4" /></button>
          <button onClick={onSaveProject} className="flex items-center gap-1 px-2 py-1 rounded bg-[#123047] text-[#7DD3FC] hover:bg-[#16415e] text-[11px] font-semibold" title="Download project backup"><Save className="w-3.5 h-3.5" /><span className="hidden sm:inline">Project</span></button>
        </div>

        {/* Render Style Selector */}
        <div className="hidden lg:flex items-center bg-[#0B0D14] border border-[#232A3E] rounded-md p-0.5">
          {(
            [
              { id: 'hand-painted-hd', label: 'HD Painted' },
              { id: 'pixel-art-64', label: 'Pixel 64px' },
              { id: 'pixel-art-32', label: 'Retro 32px' },
            ] as { id: RenderStyle; label: string }[]
          ).map((mode) => (
            <button
              key={mode.id}
              onClick={() => onUpdateCustomization({ renderStyle: mode.id })}
              className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors cursor-pointer ${
                customization.renderStyle === mode.id
                  ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/40 shadow-sm'
                  : 'text-[#94A3B8] hover:text-[#F1F5F9]'
              }`}
            >
              {mode.label}
            </button>
          ))}
        </div>

        {/* Custom PNG Reference Import */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/png,image/jpeg,image/webp"
          onChange={handleFileUpload}
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium border transition-colors cursor-pointer ${
            customization.useUploadedImageAsBase
              ? 'bg-[#F59E0B]/15 border-[#F59E0B]/50 text-[#F59E0B]'
              : 'bg-[#1A2030] border-[#232A3E] text-[#94A3B8] hover:text-[#F1F5F9] hover:border-[#38BDF8]/40'
          }`}
          title="Import a character or artwork reference (PNG, JPG or WebP)"
        >
          <Upload className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">
            {customization.useUploadedImageAsBase ? 'Artwork Loaded' : 'Import Artwork'}
          </span>
        </button>

        {customization.useUploadedImageAsBase && (
          <button
            onClick={() => onUpdateCustomization({ useUploadedImageAsBase: false })}
            className="px-2 py-1.5 rounded-md text-[11px] bg-[#0B0D14] border border-[#232A3E] text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
            title="Switch back to Layered Procedural Wisp Mage Rig"
          >
            Use Rig
          </button>
        )}

        {/* JSON Engine Schema Dropdown */}
        <div className="flex items-center bg-[#0B0D14] border border-[#232A3E] rounded-md px-2 py-1">
          <Layers className="w-3.5 h-3.5 text-[#F59E0B] mr-1.5 shrink-0" />
          <select
            value={settings.format}
            onChange={(e) =>
              onUpdateSettings({ format: e.target.value as AtlasFormat })
            }
            className="bg-[#0B0D14] text-xs font-mono-code text-[#F1F5F9] focus:outline-none cursor-pointer"
            title="Target Game Engine JSON Atlas Schema"
          >
            <option value="phaser-hash">Phaser 3 / PixiJS (Hash .json)</option>
            <option value="texturepacker-array">TexturePacker (Array .json)</option>
            <option value="aseprite">Aseprite (Tags + Slices .json)</option>
            <option value="unity-engine">Unity / Godot Engine (.json)</option>
          </select>
        </div>

        <div className="h-6 w-[1px] bg-[#232A3E] mx-0.5" />

        {/* Export .PNG Button */}
        <button
          onClick={onDownloadPng}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#1A2030] hover:bg-[#232C42] border border-[#232A3E] hover:border-[#38BDF8]/50 text-xs font-semibold text-[#F1F5F9] transition-all cursor-pointer"
          title="Download transparent .PNG Sprite Sheet"
        >
          <ImageIcon className="w-3.5 h-3.5 text-[#38BDF8]" />
          <span>.PNG</span>
        </button>

        {/* Export .JSON Button */}
        <button
          onClick={onDownloadJson}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-[#1A2030] hover:bg-[#232C42] border border-[#232A3E] hover:border-[#F59E0B]/50 text-xs font-semibold text-[#F1F5F9] transition-all cursor-pointer"
          title="Download .JSON Texture Atlas metadata"
        >
          <FileCode2 className="w-3.5 h-3.5 text-[#F59E0B]" />
          <span>.JSON</span>
        </button>

        {/* Primary CTA: Export Both (.PNG + .JSON) */}
        <button
          onClick={onDownloadBundle}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-md bg-gradient-to-r from-[#0284C7] via-[#38BDF8] to-[#0EA5E9] hover:brightness-110 text-[#0B0D14] font-display font-bold text-xs shadow-[0_0_20px_rgba(56,189,248,0.35)] transition-all cursor-pointer"
        >
          {exportSuccessMessage ? (
            <>
              <Check className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>{exportSuccessMessage}</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 stroke-[2.5]" />
              <span>Export .PNG + .JSON</span>
            </>
          )}
        </button>
      </div>
    </header>
  );
};

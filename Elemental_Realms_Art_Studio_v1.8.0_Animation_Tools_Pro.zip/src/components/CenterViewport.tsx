import React, { useEffect, useRef, useState } from 'react';
import {
  ZoomIn,
  ZoomOut,
  Crosshair,
  Shield,
  Sword,
  Sparkles,
  Layers,
  Gamepad2,
  Grid,
  Eye,
  Download,
} from 'lucide-react';
import {
  AnimationId,
  AtlasSettings,
  CharacterCustomization,
  FrameData,
  GeneratedAtlasResult,
} from '../types/sprite';
import { renderWispFrame } from '../engine/wispRenderer';
import { downloadCanvasAsPng, generateImportedImageAsset } from '../engine/atlasGenerator';

interface CenterViewportProps {
  activeAnimId: AnimationId;
  activeFrameIndex: number;
  onSelectFrame: (animId: AnimationId, frameIndex: number) => void;
  framesByAnim: Record<AnimationId, FrameData[]>;
  onUpdateCurrentFrame: (partial: Partial<FrameData>) => void;
  customization: CharacterCustomization;
  settings: AtlasSettings;
  atlasResult: GeneratedAtlasResult | null;
  onionSkin: boolean;
  importedAsset: { canvas: HTMLCanvasElement; jsonString: string } | null;
  onToggleOnionSkin: () => void;
}

type ViewportTab = 'sprite-stage' | 'atlas-sheet' | 'playable-test';
type StageBg = 'dark-checker' | 'pitch-black' | 'astral-night' | 'light-checker';
type DragTarget = 'none' | 'pivot' | 'cast-socket';

interface SandboxProjectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
}

interface TargetCrystal {
  id: number;
  x: number;
  y: number;
  hp: number;
  maxHp: number;
  hitTimer: number;
}

export const CenterViewport: React.FC<CenterViewportProps> = ({
  activeAnimId,
  activeFrameIndex,
  onSelectFrame,
  framesByAnim,
  onUpdateCurrentFrame,
  customization,
  settings,
  atlasResult,
  onionSkin,
  importedAsset,
  onToggleOnionSkin,
}) => {
  const [viewTab, setViewTab] = useState<ViewportTab>('sprite-stage');
  const [stageBg, setStageBg] = useState<StageBg>('dark-checker');
  const [zoom, setZoom] = useState<number>(1.35);
  const [showHurtbox, setShowHurtbox] = useState<boolean>(true);
  const [showHitbox, setShowHitbox] = useState<boolean>(true);
  const [showPivot, setShowPivot] = useState<boolean>(true);
  const [showCastSocket, setShowCastSocket] = useState<boolean>(true);
  const [showAtlasGrid, setShowAtlasGrid] = useState<boolean>(true);
  const [dragTarget, setDragTarget] = useState<DragTarget>('none');
  const [hoveredPackedIndex, setHoveredPackedIndex] = useState<number | null>(null);

  const stageCanvasRef = useRef<HTMLCanvasElement>(null);
  const sheetPreviewCanvasRef = useRef<HTMLCanvasElement>(null);
  const sandboxCanvasRef = useRef<HTMLCanvasElement>(null);

  const activeFrames = framesByAnim[activeAnimId] || [];
  const currentFrame = activeFrames[activeFrameIndex] || activeFrames[0];

  // 1. Render Single Sprite Stage Canvas
  useEffect(() => {
    if (viewTab !== 'sprite-stage') return;
    const canvas = stageCanvasRef.current;
    if (!canvas) return;
    if (customization.useUploadedImageAsBase && customization.customUploadedImage) {
      const asset = importedAsset || generateImportedImageAsset(customization.customUploadedImage, settings, customization);
      canvas.width = 320;
      canvas.height = 320;
      const imageCtx = canvas.getContext('2d');
      if (imageCtx) {
        imageCtx.clearRect(0, 0, 320, 320);
        imageCtx.imageSmoothingEnabled = false;
        imageCtx.drawImage(asset.canvas, 0, 0, 320, 320);
      }
      return;
    }
    if (!currentFrame) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const displaySize = 320;
    canvas.width = displaySize;
    canvas.height = displaySize;
    ctx.clearRect(0, 0, displaySize, displaySize);

    // Onion skinning: render previous and next frames at low opacity
    if (onionSkin && activeFrames.length > 1) {
      const prevIdx = (activeFrameIndex - 1 + activeFrames.length) % activeFrames.length;
      const nextIdx = (activeFrameIndex + 1) % activeFrames.length;

      renderWispFrame(
        ctx,
        activeAnimId,
        prevIdx,
        activeFrames.length,
        customization,
        displaySize,
        undefined,
        { alphaOverride: 0.22 }
      );
      renderWispFrame(
        ctx,
        activeAnimId,
        nextIdx,
        activeFrames.length,
        customization,
        displaySize,
        undefined,
        { alphaOverride: 0.14 }
      );
    }

    // Main active frame + debug overlays
    renderWispFrame(
      ctx,
      activeAnimId,
      activeFrameIndex,
      activeFrames.length,
      customization,
      displaySize,
      currentFrame,
      {
        showHurtbox,
        showHitbox,
        showPivot,
        showCastSocket,
      }
    );
  }, [
    viewTab,
    activeAnimId,
    activeFrameIndex,
    activeFrames,
    currentFrame,
    customization,
    onionSkin,
    showHurtbox,
    showHitbox,
    showPivot,
    showCastSocket,
    importedAsset,
    settings,
  ]);

  // 2. Render Full Sprite Sheet Atlas View
  useEffect(() => {
    if (viewTab !== 'atlas-sheet') return;
    if (customization.useUploadedImageAsBase && importedAsset) {
      const canvas = sheetPreviewCanvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      canvas.width = importedAsset.canvas.width;
      canvas.height = importedAsset.canvas.height;
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(importedAsset.canvas, 0, 0);
      return;
    }
    if (!atlasResult) return;
    const canvas = sheetPreviewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = atlasResult.width;
    canvas.height = atlasResult.height;
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw packed sprite sheet
    ctx.drawImage(atlasResult.canvas, 0, 0);

    // Draw slice bounding boxes & frame labels if enabled
    if (showAtlasGrid) {
      atlasResult.packedFrames.forEach((pf, idx) => {
        const isCurrent =
          pf.animationId === activeAnimId && pf.frameIndex === activeFrameIndex;
        const isHovered = hoveredPackedIndex === idx;

        ctx.save();
        ctx.strokeStyle = isCurrent
          ? '#F59E0B'
          : isHovered
          ? '#38BDF8'
          : 'rgba(56, 189, 248, 0.35)';
        ctx.lineWidth = isCurrent || isHovered ? 2.5 : 1;
        if (!isCurrent && !isHovered) {
          ctx.setLineDash([4, 4]);
        }
        ctx.strokeRect(pf.x + 0.5, pf.y + 0.5, pf.w - 1, pf.h - 1);

        // Top-left index badge
        ctx.fillStyle = isCurrent
          ? 'rgba(245, 158, 11, 0.92)'
          : 'rgba(11, 13, 20, 0.78)';
        ctx.fillRect(pf.x + 2, pf.y + 2, 42, 16);
        ctx.fillStyle = isCurrent ? '#0B0D14' : '#94A3B8';
        ctx.font = '600 10px "JetBrains Mono", monospace';
        ctx.fillText(`#${String(idx).padStart(2, '0')}`, pf.x + 6, pf.y + 13);
        ctx.restore();
      });
    }
  }, [
    viewTab,
    atlasResult,
    importedAsset,
    customization.useUploadedImageAsBase,
    showAtlasGrid,
    activeAnimId,
    activeFrameIndex,
    hoveredPackedIndex,
  ]);

  // 3. Interactive Playable Sandbox Loop
  useEffect(() => {
    if (viewTab !== 'playable-test') return;
    const canvas = sandboxCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const keys: Record<string, boolean> = {};
    let playerX = 240;
    let playerY = 230;
    let facingLeft = false;
    let state: AnimationId = 'idle';
    let stateTimer = 0;
    let animTick = 0;
    const projectiles: SandboxProjectile[] = [];
    const crystals: TargetCrystal[] = [
      { id: 1, x: 520, y: 220, hp: 100, maxHp: 100, hitTimer: 0 },
      { id: 2, x: 640, y: 165, hp: 100, maxHp: 100, hitTimer: 0 },
      { id: 3, x: 110, y: 205, hp: 100, maxHp: 100, hitTimer: 0 },
    ];

    const triggerAction = (action: 'cast' | 'attack' | 'hit') => {
      state = action;
      stateTimer = action === 'hit' ? 24 : 32;
      animTick = 0;
      if (action === 'cast') {
        const dir = facingLeft ? -1 : 1;
        projectiles.push({
          x: playerX + dir * 42,
          y: playerY - 12,
          vx: dir * 7.5,
          vy: 0,
          life: 90,
        });
      }
      if (action === 'attack') {
        const dir = facingLeft ? -1 : 1;
        const slashX = playerX + dir * 65;
        crystals.forEach((c) => {
          if (Math.hypot(c.x - slashX, c.y - playerY) < 75) {
            c.hp = Math.max(10, c.hp - 35);
            c.hitTimer = 12;
          }
        });
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)
      ) {
        e.preventDefault();
      }
      keys[e.code] = true;
      if (e.code === 'Space') triggerAction('cast');
      if (e.code === 'KeyE') triggerAction('attack');
      if (e.code === 'KeyH') triggerAction('hit');
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.code] = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);

    let rafId = 0;
    const loop = () => {
      animTick++;

      // Movement
      let moving = false;
      if (stateTimer <= 0) {
        if (keys['KeyA'] || keys['ArrowLeft']) {
          playerX = Math.max(60, playerX - 3.6);
          facingLeft = true;
          moving = true;
        }
        if (keys['KeyD'] || keys['ArrowRight']) {
          playerX = Math.min(700, playerX + 3.6);
          facingLeft = false;
          moving = true;
        }
        if (keys['KeyW'] || keys['ArrowUp']) {
          playerY = Math.max(95, playerY - 3.0);
          moving = true;
        }
        if (keys['KeyS'] || keys['ArrowDown']) {
          playerY = Math.min(320, playerY + 3.0);
          moving = true;
        }
        state = moving ? 'move' : 'idle';
      } else {
        stateTimer--;
      }

      // Render arena background
      ctx.fillStyle = '#090C15';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle floor grid
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.08)';
      ctx.lineWidth = 1;
      for (let gx = 0; gx < canvas.width; gx += 40) {
        ctx.beginPath();
        ctx.moveTo(gx, 0);
        ctx.lineTo(gx, canvas.height);
        ctx.stroke();
      }
      for (let gy = 0; gy < canvas.height; gy += 40) {
        ctx.beginPath();
        ctx.moveTo(0, gy);
        ctx.lineTo(canvas.width, gy);
        ctx.stroke();
      }

      // Draw Target Arcane Crystals
      for (const c of crystals) {
        if (c.hitTimer > 0) c.hitTimer--;
        if (c.hp < c.maxHp && animTick % 90 === 0) c.hp = Math.min(c.maxHp, c.hp + 15);

        ctx.save();
        ctx.translate(c.x, c.y + Math.sin(animTick * 0.06 + c.id) * 5);
        ctx.fillStyle = c.hitTimer > 0 ? '#FFFFFF' : '#0284C7';
        ctx.strokeStyle = '#38BDF8';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(0, -28);
        ctx.lineTo(18, 0);
        ctx.lineTo(0, 28);
        ctx.lineTo(-18, 0);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        // HP bar
        ctx.fillStyle = '#1E293B';
        ctx.fillRect(-20, -40, 40, 5);
        ctx.fillStyle = '#10B981';
        ctx.fillRect(-20, -40, (40 * c.hp) / c.maxHp, 5);
        ctx.restore();
      }

      // Update & Draw Projectiles
      for (let i = projectiles.length - 1; i >= 0; i--) {
        const p = projectiles[i];
        p.x += p.vx;
        p.y += p.vy;
        p.life--;

        // Check collision with crystals
        for (const c of crystals) {
          if (Math.hypot(c.x - p.x, c.y - p.y) < 28) {
            c.hp = Math.max(10, c.hp - 25);
            c.hitTimer = 10;
            p.life = 0;
          }
        }

        if (p.life <= 0) {
          projectiles.splice(i, 1);
          continue;
        }

        const grad = ctx.createRadialGradient(p.x, p.y, 2, p.x, p.y, 16);
        grad.addColorStop(0, '#FFFFFF');
        grad.addColorStop(0.4, '#38BDF8');
        grad.addColorStop(1, 'rgba(56, 189, 248, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(p.x, p.y, 16, 0, Math.PI * 2);
        ctx.fill();
      }

      // Draw Wisp Mage Player
      const stateFrames = framesByAnim[state] || framesByAnim.idle;
      const frameIdx = Math.floor(animTick / 5) % stateFrames.length;
      const spriteSize = 150;
      const off = document.createElement('canvas');
      off.width = spriteSize;
      off.height = spriteSize;
      const offCtx = off.getContext('2d');
      if (offCtx) {
        renderWispFrame(
          offCtx,
          state,
          frameIdx,
          stateFrames.length,
          { ...customization, flipX: facingLeft },
          spriteSize,
          stateFrames[frameIdx],
          { showHurtbox, showHitbox, showPivot, showCastSocket }
        );
        ctx.drawImage(off, playerX - spriteSize / 2, playerY - spriteSize * 0.65);
      }

      rafId = requestAnimationFrame(loop);
    };

    rafId = requestAnimationFrame(loop);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [
    viewTab,
    framesByAnim,
    customization,
    showHurtbox,
    showHitbox,
    showPivot,
    showCastSocket,
  ]);

  // Interactive Canvas Click / Drag to reposition Pivot or Cast Socket
  const handleStageMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!currentFrame || !stageCanvasRef.current) return;
    const rect = stageCanvasRef.current.getBoundingClientRect();
    const normX = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const normY = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

    // Check distance to pivot vs castSocket
    const distPivot = Math.hypot(
      normX - currentFrame.pivot.x,
      normY - currentFrame.pivot.y
    );
    const distSocket = Math.hypot(
      normX - currentFrame.castSocket.x / 256,
      normY - currentFrame.castSocket.y / 256
    );

    if (distSocket < 0.08 && showCastSocket) {
      setDragTarget('cast-socket');
      onUpdateCurrentFrame({
        castSocket: {
          x: Math.round(normX * 256),
          y: Math.round(normY * 256),
        },
      });
    } else if (distPivot < 0.12 && showPivot) {
      setDragTarget('pivot');
      onUpdateCurrentFrame({
        pivot: {
          x: Number(normX.toFixed(3)),
          y: Number(normY.toFixed(3)),
        },
      });
    }
  };

  const handleStageMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (dragTarget === 'none' || !stageCanvasRef.current) return;
    const rect = stageCanvasRef.current.getBoundingClientRect();
    const normX = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
    const normY = Math.max(0, Math.min(1, (e.clientY - rect.top) / rect.height));

    if (dragTarget === 'pivot') {
      onUpdateCurrentFrame({
        pivot: {
          x: Number(normX.toFixed(3)),
          y: Number(normY.toFixed(3)),
        },
      });
    } else if (dragTarget === 'cast-socket') {
      onUpdateCurrentFrame({
        castSocket: {
          x: Math.round(normX * 256),
          y: Math.round(normY * 256),
        },
      });
    }
  };

  const handleStageMouseUp = () => {
    setDragTarget('none');
  };

  const handleDownloadSingleFrame = () => {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = settings.frameSize;
    tempCanvas.height = settings.frameSize;
    const ctx = tempCanvas.getContext('2d');
    if (ctx) {
      renderWispFrame(
        ctx,
        activeAnimId,
        activeFrameIndex,
        activeFrames.length,
        customization,
        settings.frameSize
      );
      downloadCanvasAsPng(
        tempCanvas,
        currentFrame?.name || `wisp_mage_${activeAnimId}_${activeFrameIndex}`
      );
    }
  };

  const getStageBgClass = () => {
    switch (stageBg) {
      case 'pitch-black':
        return 'bg-[#000000]';
      case 'astral-night':
        return 'bg-gradient-to-b from-[#070B19] via-[#0F172A] to-[#1E1B4B]';
      case 'light-checker':
        return 'bg-alpha-checker-light';
      default:
        return 'bg-alpha-checker';
    }
  };

  return (
    <main className="flex-1 flex flex-col bg-[#0B0D14] overflow-hidden select-none relative">
      {/* Viewport Mode Sub-Toolbar */}
      <div className="viewport-subtoolbar bg-[#121622]/95 border-b border-[#232A3E] px-3 py-2 flex items-center justify-between gap-3 shrink-0 z-10">
        {/* Workspace view switcher: compact segmented control */}
        <div className="viewport-view-switcher grid grid-cols-3 min-w-0 flex-1 max-w-[620px] items-stretch gap-1 bg-[#0B0D14] p-1 rounded-xl border border-[#232A3E]">
          <button
            onClick={() => setViewTab('sprite-stage')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              viewTab === 'sprite-stage'
                ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="viewport-tab-label"><span className="hidden sm:inline">Animated Sprite Stage</span><span className="sm:hidden">Sprite Stage</span></span>
          </button>

          <button
            onClick={() => setViewTab('atlas-sheet')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              viewTab === 'atlas-sheet'
                ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Grid className="w-3.5 h-3.5" />
            <span className="viewport-tab-label"><span className="hidden sm:inline">Full .PNG Atlas Sheet</span><span className="sm:hidden">PNG Atlas</span></span>
          </button>

          <button
            onClick={() => setViewTab('playable-test')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded text-xs font-medium transition-colors cursor-pointer ${
              viewTab === 'playable-test'
                ? 'bg-[#1A2030] text-[#F59E0B] border border-[#F59E0B]/30'
                : 'text-[#94A3B8] hover:text-[#F1F5F9]'
            }`}
          >
            <Gamepad2 className="w-3.5 h-3.5" />
            <span className="viewport-tab-label"><span className="hidden sm:inline">In-Game Sandbox Test</span><span className="sm:hidden">Sandbox</span></span>
          </button>
        </div>

        {/* Right: Overlay Gizmo Toggles & Background */}
        <div className="viewport-stage-actions flex items-center gap-1.5 min-w-0">
          {viewTab === 'sprite-stage' && (
            <>
              <button
                onClick={onToggleOnionSkin}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                  onionSkin
                    ? 'bg-[#38BDF8]/15 border-[#38BDF8]/50 text-[#38BDF8]'
                    : 'bg-[#0B0D14] border-[#232A3E] text-[#64748B] hover:text-[#94A3B8]'
                }`}
                title="Toggle Onion Skin (Previous & Next Frame Ghosts)"
              >
                <Layers className="w-3 h-3" />
                <span className="hidden xl:inline">Onion</span>
              </button>

              <button
                onClick={() => setShowHurtbox(!showHurtbox)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                  showHurtbox
                    ? 'bg-[#10B981]/15 border-[#10B981]/50 text-[#10B981]'
                    : 'bg-[#0B0D14] border-[#232A3E] text-[#64748B] hover:text-[#94A3B8]'
                }`}
                title="Toggle Hurtbox Collider (Green)"
              >
                <Shield className="w-3 h-3" />
                <span className="hidden xl:inline">Hurtbox</span>
              </button>

              <button
                onClick={() => setShowHitbox(!showHitbox)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                  showHitbox
                    ? 'bg-[#F43F5E]/15 border-[#F43F5E]/50 text-[#F43F5E]'
                    : 'bg-[#0B0D14] border-[#232A3E] text-[#64748B] hover:text-[#94A3B8]'
                }`}
                title="Toggle Attack/Spell Hitbox (Coral)"
              >
                <Sword className="w-3 h-3" />
                <span className="hidden xl:inline">Hitbox</span>
              </button>

              <button
                onClick={() => setShowPivot(!showPivot)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                  showPivot
                    ? 'bg-[#F59E0B]/15 border-[#F59E0B]/50 text-[#F59E0B]'
                    : 'bg-[#0B0D14] border-[#232A3E] text-[#64748B] hover:text-[#94A3B8]'
                }`}
                title="Toggle Origin Pivot Crosshair (Gold - Drag on canvas)"
              >
                <Crosshair className="w-3 h-3" />
                <span className="hidden xl:inline">Pivot</span>
              </button>

              <button
                onClick={() => setShowCastSocket(!showCastSocket)}
                className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                  showCastSocket
                    ? 'bg-[#38BDF8]/15 border-[#38BDF8]/50 text-[#38BDF8]'
                    : 'bg-[#0B0D14] border-[#232A3E] text-[#64748B] hover:text-[#94A3B8]'
                }`}
                title="Toggle Projectile Spawn Socket (Cyan Diamond - Drag on canvas)"
              >
                <Sparkles className="w-3 h-3" />
                <span className="hidden xl:inline">Socket</span>
              </button>
            </>
          )}

          {viewTab === 'atlas-sheet' && (
            <button
              onClick={() => setShowAtlasGrid(!showAtlasGrid)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-mono-code border transition-colors cursor-pointer ${
                showAtlasGrid
                  ? 'bg-[#38BDF8]/15 border-[#38BDF8]/50 text-[#38BDF8]'
                  : 'bg-[#0B0D14] border-[#232A3E] text-[#94A3B8]'
              }`}
            >
              <Grid className="w-3 h-3" />
              <span>Show JSON Slice Bounds</span>
            </button>
          )}

          <div className="h-4 w-[1px] bg-[#232A3E] mx-0.5" />

          {/* Background Selector */}
          <select
            value={stageBg}
            onChange={(e) => setStageBg(e.target.value as StageBg)}
            className="bg-[#0B0D14] border border-[#232A3E] rounded px-2 py-1 text-[11px] text-[#94A3B8] focus:outline-none cursor-pointer"
            title="Canvas Backdrop Style"
          >
            <option value="dark-checker">Dark Alpha Grid</option>
            <option value="pitch-black">Pitch Black (Reference)</option>
            <option value="astral-night">Astral Sanctum Sky</option>
            <option value="light-checker">Light Alpha Grid</option>
          </select>

          {/* Zoom Controls */}
          {viewTab !== 'playable-test' && (
            <div className="flex items-center bg-[#0B0D14] border border-[#232A3E] rounded px-1">
              <button
                onClick={() => setZoom((z) => Math.max(0.5, Number((z - 0.2).toFixed(2))))}
                className="p-1 text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-3.5 h-3.5" />
              </button>
              <span className="text-[11px] font-mono-code text-[#F1F5F9] px-1.5 min-w-[44px] text-center">
                {Math.round(zoom * 100)}%
              </span>
              <button
                onClick={() => setZoom((z) => Math.min(2.5, Number((z + 0.2).toFixed(2))))}
                className="p-1 text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Main Canvas Stage Area */}
      <div
        className={`flex-1 overflow-auto flex items-center justify-center p-6 relative ${getStageBgClass()}`}
      >
        {viewTab === 'sprite-stage' && (
          <div className="relative flex flex-col items-center">
            {/* Sprite Frame Bounding Box Container */}
            <div
              className="relative rounded-xl border border-[#38BDF8]/40 shadow-[0_0_50px_rgba(0,0,0,0.65)] transition-transform duration-75"
              style={{
                width: `${Math.round(300 * zoom)}px`,
                height: `${Math.round(300 * zoom)}px`,
              }}
            >
              {/* Corner technical ticks */}
              <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-[#38BDF8] pointer-events-none" />
              <div className="absolute -top-1 -right-1 w-3 h-3 border-t-2 border-r-2 border-[#38BDF8] pointer-events-none" />
              <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-[#38BDF8] pointer-events-none" />
              <div className="absolute -bottom-1 -right-1 w-3 h-3 border-b-2 border-r-2 border-[#38BDF8] pointer-events-none" />

              <canvas
                ref={stageCanvasRef}
                onMouseDown={handleStageMouseDown}
                onMouseMove={handleStageMouseMove}
                onMouseUp={handleStageMouseUp}
                onMouseLeave={handleStageMouseUp}
                className="w-full h-full cursor-crosshair"
              />

              {/* Frame Coordinate HUD Tag */}
              <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5 bg-[#0B0D14]/85 backdrop-blur-md border border-[#232A3E] rounded px-2 py-0.5 pointer-events-none">
                <span className="w-1.5 h-1.5 rounded-full bg-[#38BDF8]" />
                <span className="font-mono-code text-[11px] text-[#F1F5F9]">
                  {currentFrame?.name}.png
                </span>
                <span className="font-mono-code text-[10px] text-[#64748B]">
                  ({settings.frameSize}×{settings.frameSize})
                </span>
              </div>

              {/* Single Frame Export Button */}
              <button
                onClick={handleDownloadSingleFrame}
                className="absolute bottom-2.5 right-2.5 flex items-center gap-1.5 bg-[#121622]/90 hover:bg-[#1A2030] border border-[#232A3E] hover:border-[#38BDF8] rounded px-2.5 py-1 text-[11px] font-medium text-[#F1F5F9] shadow-lg transition-colors cursor-pointer"
                title="Download this single frame as a standalone transparent .PNG"
              >
                <Download className="w-3 h-3 text-[#38BDF8]" />
                <span>Frame .PNG</span>
              </button>
            </div>

            {/* Interactive Gizmo Legend */}
            <div className="mt-3 flex flex-wrap items-center justify-center gap-3 bg-[#121622]/90 backdrop-blur-md border border-[#232A3E] rounded-full px-4 py-1 text-[11px] text-[#94A3B8]">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#F59E0B]" />
                <span>
                  Drag <strong className="text-[#F1F5F9]">Pivot</strong> ({currentFrame?.pivot.x},{' '}
                  {currentFrame?.pivot.y})
                </span>
              </span>
              <span className="text-[#232A3E]">|</span>
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rotate-45 bg-[#38BDF8]" />
                <span>
                  Drag <strong className="text-[#F1F5F9]">Cast Socket</strong> (x:
                  {currentFrame?.castSocket.x}, y:{currentFrame?.castSocket.y})
                </span>
              </span>
            </div>
          </div>
        )}

        {viewTab === 'atlas-sheet' && atlasResult && (
          <div className="flex flex-col items-center max-w-full max-h-full overflow-auto p-4">
            <div className="mb-2 flex items-center gap-3 bg-[#121622]/90 border border-[#232A3E] rounded-full px-3.5 py-1 text-xs font-mono-code text-[#94A3B8]">
              <span className="text-[#38BDF8] font-semibold">
                {settings.projectName}.png
              </span>
              <span>•</span>
              <span>
                {atlasResult.width}×{atlasResult.height}px
              </span>
              <span>•</span>
              <span>{atlasResult.packedFrames.length} packed slices</span>
              <span className="text-[#64748B]">
                (Click any cell to inspect frame)
              </span>
            </div>

            <div className="relative border border-[#38BDF8]/40 rounded-lg shadow-2xl overflow-auto max-w-full">
              <canvas
                ref={sheetPreviewCanvasRef}
                onClick={(e) => {
                  if (!sheetPreviewCanvasRef.current) return;
                  const rect = sheetPreviewCanvasRef.current.getBoundingClientRect();
                  const clickX =
                    ((e.clientX - rect.left) / rect.width) * atlasResult.width;
                  const clickY =
                    ((e.clientY - rect.top) / rect.height) * atlasResult.height;
                  const hit = atlasResult.packedFrames.find(
                    (pf) =>
                      clickX >= pf.x &&
                      clickX <= pf.x + pf.w &&
                      clickY >= pf.y &&
                      clickY <= pf.y + pf.h
                  );
                  if (hit) {
                    onSelectFrame(hit.animationId, hit.frameIndex);
                  }
                }}
                onMouseMove={(e) => {
                  if (!sheetPreviewCanvasRef.current) return;
                  const rect = sheetPreviewCanvasRef.current.getBoundingClientRect();
                  const mx =
                    ((e.clientX - rect.left) / rect.width) * atlasResult.width;
                  const my =
                    ((e.clientY - rect.top) / rect.height) * atlasResult.height;
                  const hitIdx = atlasResult.packedFrames.findIndex(
                    (pf) =>
                      mx >= pf.x &&
                      mx <= pf.x + pf.w &&
                      my >= pf.y &&
                      my <= pf.y + pf.h
                  );
                  setHoveredPackedIndex(hitIdx === -1 ? null : hitIdx);
                }}
                onMouseLeave={() => setHoveredPackedIndex(null)}
                style={{
                  width: `${Math.round(
                    Math.min(820, atlasResult.width * 0.45) * zoom
                  )}px`,
                  height: 'auto',
                }}
                className="cursor-pointer block"
              />
            </div>
          </div>
        )}

        {viewTab === 'playable-test' && (
          <div className="flex flex-col items-center gap-3">
            <div className="relative rounded-xl border border-[#232A3E] overflow-hidden shadow-2xl">
              <canvas
                ref={sandboxCanvasRef}
                width={760}
                height={380}
                className="block bg-[#090C15]"
              />
              <div className="absolute top-3 left-3 bg-[#121622]/90 backdrop-blur-md border border-[#232A3E] rounded-lg px-3 py-2 text-xs space-y-1">
                <div className="font-display font-bold text-[#38BDF8] flex items-center gap-1.5">
                  <Gamepad2 className="w-3.5 h-3.5" />
                  <span>Live Engine Sandbox Verification</span>
                </div>
                <div className="text-[11px] font-mono-code text-[#94A3B8] flex flex-wrap gap-x-3 gap-y-1">
                  <span>
                    <strong className="text-[#F1F5F9]">WASD / Arrows:</strong> Float Glide
                  </span>
                  <span>
                    <strong className="text-[#38BDF8]">SPACE:</strong> Cast Astral Bolt
                  </span>
                  <span>
                    <strong className="text-[#F59E0B]">E:</strong> Spirit Slash
                  </span>
                  <span>
                    <strong className="text-[#F43F5E]">H:</strong> Test Hit Recoil
                  </span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
};

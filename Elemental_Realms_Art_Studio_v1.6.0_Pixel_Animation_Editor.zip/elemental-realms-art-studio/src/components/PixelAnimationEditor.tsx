import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { Play, Pause, Plus, Copy, Trash2, Download, FileCode2, ChevronLeft, ChevronRight } from 'lucide-react';

type AnimationFrame = { id: string; pixels: string[] };

const blankPixels = (size: number) => Array(size * size).fill('') as string[];
const makeFrame = (size: number): AnimationFrame => ({ id: `frame-${Date.now()}-${Math.random().toString(36).slice(2,7)}`, pixels: blankPixels(size) });

function loadAnimation(size: number): AnimationFrame[] {
  try {
    const data = JSON.parse(localStorage.getItem('er-pixel-animation-v1') || '{}');
    if (data.size === size && Array.isArray(data.frames) && data.frames.length) {
      return data.frames.slice(0, 48).map((f: any) => ({
        id: typeof f.id === 'string' ? f.id : `frame-${Math.random()}`,
        pixels: Array.isArray(f.pixels) && f.pixels.length === size * size
          ? f.pixels.map((v: unknown) => typeof v === 'string' && /^#[0-9a-f]{6}$/i.test(v) ? v : '')
          : blankPixels(size),
      }));
    }
  } catch { /* Start a new animation if saved data is invalid. */ }
  return [makeFrame(size)];
}

export function PixelAnimationEditor() {
  const [size, setSize] = useState(32);
  const [frames, setFrames] = useState<AnimationFrame[]>(() => loadAnimation(32));
  const [active, setActive] = useState(0);
  const [color, setColor] = useState('#38BDF8');
  const [eraser, setEraser] = useState(false);
  const [fps, setFps] = useState(8);
  const [playing, setPlaying] = useState(false);
  const [showGrid, setShowGrid] = useState(true);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawingRef = useRef(false);
  const current = frames[Math.min(active, frames.length - 1)];

  useEffect(() => {
    try { localStorage.setItem('er-pixel-animation-v1', JSON.stringify({ size, frames })); } catch { /* Export remains available. */ }
  }, [size, frames]);

  useEffect(() => {
    if (!playing) return;
    const timer = window.setInterval(() => setActive((i) => (i + 1) % frames.length), 1000 / fps);
    return () => window.clearInterval(timer);
  }, [playing, fps, frames.length]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !current) return;
    const scale = 12;
    canvas.width = size * scale; canvas.height = size * scale;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.imageSmoothingEnabled = false;
    current.pixels.forEach((value, index) => {
      if (!value) return;
      ctx.fillStyle = value;
      ctx.fillRect((index % size) * scale, Math.floor(index / size) * scale, scale, scale);
    });
    if (showGrid) {
      ctx.beginPath(); ctx.strokeStyle = 'rgba(100,116,139,.32)'; ctx.lineWidth = 1;
      for (let i = 0; i <= size; i++) {
        ctx.moveTo(i * scale + .5, 0); ctx.lineTo(i * scale + .5, size * scale);
        ctx.moveTo(0, i * scale + .5); ctx.lineTo(size * scale, i * scale + .5);
      }
      ctx.stroke();
    }
  }, [current, size, showGrid]);

  const paintAt = (event: PointerEvent<HTMLCanvasElement>) => {
    if (playing) return;
    const rect = event.currentTarget.getBoundingClientRect();
    const x = Math.floor(((event.clientX - rect.left) / rect.width) * size);
    const y = Math.floor(((event.clientY - rect.top) / rect.height) * size);
    if (x < 0 || y < 0 || x >= size || y >= size) return;
    const index = y * size + x;
    setFrames((items) => items.map((frame, i) => {
      if (i !== active || frame.pixels[index] === (eraser ? '' : color)) return frame;
      const pixels = [...frame.pixels]; pixels[index] = eraser ? '' : color;
      return { ...frame, pixels };
    }));
  };

  const addFrame = () => {
    if (frames.length >= 48) return;
    setFrames((items) => [...items, makeFrame(size)]);
    setActive(frames.length);
    setPlaying(false);
  };
  const duplicateFrame = () => {
    if (frames.length >= 48 || !current) return;
    const clone = { id: `frame-${Date.now()}`, pixels: [...current.pixels] };
    setFrames((items) => [...items.slice(0, active + 1), clone, ...items.slice(active + 1)]);
    setActive(active + 1); setPlaying(false);
  };
  const deleteFrame = () => {
    if (frames.length <= 1) return;
    setFrames((items) => items.filter((_, i) => i !== active));
    setActive(Math.max(0, active - 1)); setPlaying(false);
  };
  const moveFrame = (direction: -1 | 1) => {
    const target = active + direction;
    if (target < 0 || target >= frames.length) return;
    setFrames((items) => { const next = [...items]; [next[active], next[target]] = [next[target], next[active]]; return next; });
    setActive(target);
  };
  const resize = (nextSize: number) => {
    setSize(nextSize);
    setFrames((items) => items.map((frame) => {
      const next = blankPixels(nextSize);
      const copy = Math.min(size, nextSize);
      for (let y = 0; y < copy; y++) for (let x = 0; x < copy; x++) next[y * nextSize + x] = frame.pixels[y * size + x] || '';
      return { ...frame, pixels: next };
    }));
  };
  const exportSheet = () => {
    const columns = Math.min(8, frames.length);
    const rows = Math.ceil(frames.length / columns);
    const canvas = document.createElement('canvas');
    canvas.width = columns * size; canvas.height = rows * size;
    const ctx = canvas.getContext('2d'); if (!ctx) return;
    frames.forEach((frame, i) => frame.pixels.forEach((value, p) => {
      if (!value) return;
      ctx.fillStyle = value;
      ctx.fillRect((i % columns) * size + (p % size), Math.floor(i / columns) * size + Math.floor(p / size), 1, 1);
    }));
    const link = document.createElement('a'); link.download = 'er-animation-sheet.png'; link.href = canvas.toDataURL('image/png'); link.click();
  };
  const exportJson = () => {
    const columns = Math.min(8, frames.length);
    const payload = { format: 'elemental-realms-pixel-animation', version: 1, width: size, height: size, fps, loop: true, columns,
      rows: Math.ceil(frames.length / columns), frames: frames.map((frame, index) => ({
        index, x: (index % columns) * size, y: Math.floor(index / columns) * size, durationMs: Math.round(1000 / fps),
        pixels: frame.pixels.map((v) => v || null),
      })) };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = 'er-animation.json'; link.click(); URL.revokeObjectURL(url);
  };

  return <section className="mt-5 rounded-xl border border-[#263248] bg-[#111827] p-3 sm:p-4">
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
      <div><div className="text-sm font-bold text-white">Pixel Animation Editor</div><p className="mt-1 text-[10px] text-slate-400">Draw and animate frame-by-frame · up to 48 frames</p></div>
      <div className="flex items-center gap-2"><label className="text-[10px] text-slate-400">Canvas</label><select value={size} onChange={(e)=>resize(Number(e.target.value))} className="rounded border border-[#263248] bg-[#0B0D14] p-2 text-xs text-white"><option value={16}>16×16</option><option value={32}>32×32</option><option value={48}>48×48</option><option value={64}>64×64</option></select></div>
    </div>
    <div className="grid gap-3 lg:grid-cols-[minmax(0,1fr)_220px]">
      <div className="flex min-h-[300px] items-center justify-center rounded-lg border border-[#263248] bg-alpha-checker p-3">
        <canvas ref={canvasRef} onPointerDown={(e)=>{e.preventDefault();drawingRef.current=true;e.currentTarget.setPointerCapture(e.pointerId);paintAt(e);}} onPointerMove={(e)=>{if(drawingRef.current)paintAt(e);}} onPointerUp={()=>{drawingRef.current=false;}} onPointerCancel={()=>{drawingRef.current=false;}} className="max-h-full max-w-full touch-none shadow-lg" style={{width:`min(100%, ${size*12}px)`,height:'auto',aspectRatio:'1',imageRendering:'pixelated',touchAction:'none'}} />
      </div>
      <aside className="space-y-3 rounded-lg border border-[#263248] bg-[#0B0D14] p-3">
        <div className="flex items-center justify-between"><span className="text-xs font-semibold text-slate-200">Drawing tools</span><button onClick={()=>setEraser(!eraser)} className={`rounded px-2 py-1 text-[10px] ${eraser?'bg-rose-500 text-white':'border border-[#263248] text-slate-300'}`}>{eraser?'Eraser':'Pencil'}</button></div>
        <input type="color" value={color} onChange={(e)=>setColor(e.target.value)} className="h-10 w-full rounded bg-transparent"/>
        <label className="flex items-center justify-between text-[10px] text-slate-400">Pixel grid<input type="checkbox" checked={showGrid} onChange={(e)=>setShowGrid(e.target.checked)}/></label>
        <div><div className="mb-1 flex justify-between text-[10px] text-slate-400"><span>Playback speed</span><b>{fps} FPS</b></div><input className="w-full accent-sky-400" type="range" min="1" max="24" value={fps} onChange={(e)=>setFps(Number(e.target.value))}/></div>
        <div className="grid grid-cols-2 gap-2">
          <button onClick={()=>{setPlaying(!playing);}} className="flex items-center justify-center gap-1 rounded bg-sky-500 px-2 py-2 text-xs font-bold text-slate-950">{playing?<Pause size={14}/>:<Play size={14}/>} {playing?'Pause':'Play'}</button>
          <button onClick={()=>setActive(0)} className="rounded border border-[#263248] px-2 py-2 text-xs text-slate-200">First frame</button>
        </div>
      </aside>
    </div>
    <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
      <div className="text-[10px] text-slate-400">Frame {active + 1} / {frames.length}</div>
      <div className="flex flex-wrap gap-1">
        <button title="Move left" disabled={active===0} onClick={()=>moveFrame(-1)} className="rounded border border-[#263248] p-2 text-slate-300 disabled:opacity-30"><ChevronLeft size={14}/></button>
        <button title="Move right" disabled={active===frames.length-1} onClick={()=>moveFrame(1)} className="rounded border border-[#263248] p-2 text-slate-300 disabled:opacity-30"><ChevronRight size={14}/></button>
        <button onClick={addFrame} disabled={frames.length>=48} className="flex items-center gap-1 rounded border border-sky-500/50 px-2 py-2 text-xs text-sky-300 disabled:opacity-30"><Plus size={13}/> Add</button>
        <button onClick={duplicateFrame} disabled={frames.length>=48} className="flex items-center gap-1 rounded border border-[#263248] px-2 py-2 text-xs text-slate-200 disabled:opacity-30"><Copy size={13}/> Duplicate</button>
        <button onClick={deleteFrame} disabled={frames.length<=1} className="rounded border border-rose-900/70 p-2 text-rose-300 disabled:opacity-30"><Trash2 size={14}/></button>
      </div>
    </div>
    <div className="mt-2 flex gap-2 overflow-x-auto pb-2">
      {frames.map((frame,index)=><button key={frame.id} onClick={()=>{setActive(index);setPlaying(false);}} className={`min-w-[68px] rounded-lg border p-1 ${active===index?'border-sky-400 bg-sky-500/10':'border-[#263248]'}`}>
        <span className="mb-1 block text-[9px] text-slate-400">{index+1}</span><span className="bg-alpha-checker flex aspect-square items-center justify-center"><canvas ref={(node)=>{if(!node)return;node.width=size;node.height=size;const ctx=node.getContext('2d');if(!ctx)return;frame.pixels.forEach((v,p)=>{if(v){ctx.fillStyle=v;ctx.fillRect(p%size,Math.floor(p/size),1,1);}});}} className="h-12 w-12" style={{imageRendering:'pixelated'}}/></span>
      </button>)}
    </div>
    <div className="mt-2 flex flex-wrap gap-2"><button onClick={exportSheet} className="flex items-center gap-1 rounded bg-sky-500 px-3 py-2 text-xs font-bold text-slate-950"><Download size={13}/> Export sprite sheet PNG</button><button onClick={exportJson} className="flex items-center gap-1 rounded border border-amber-500/50 px-3 py-2 text-xs text-amber-300"><FileCode2 size={13}/> Export animation JSON</button></div>
  </section>;
}

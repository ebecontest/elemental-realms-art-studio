import React, { useState } from 'react';
import {
  FileCode2,
  Sliders,
  Copy,
  Check,
  Download,
  Terminal,
  Crosshair,
  Shield,
  Sword,
} from 'lucide-react';
import {
  AnimationId,
  AtlasSettings,
  FrameData,
  GeneratedAtlasResult,
} from '../types/sprite';

interface RightInspectorProps {
  activeAnimId: AnimationId;
  activeFrameIndex: number;
  currentFrame: FrameData | undefined;
  onUpdateCurrentFrame: (partial: Partial<FrameData>) => void;
  onApplyPivotToAllFrames: (pivot: { x: number; y: number }) => void;
  settings: AtlasSettings;
  atlasResult: GeneratedAtlasResult | null;
  jsonString?: string;
  isImportedAsset?: boolean;
  onDownloadJson: () => void;
}

export const RightInspector: React.FC<RightInspectorProps> = ({
  activeAnimId,
  activeFrameIndex,
  currentFrame,
  onUpdateCurrentFrame,
  onApplyPivotToAllFrames,
  settings,
  atlasResult,
  jsonString,
  isImportedAsset = false,
  onDownloadJson,
}) => {
  const [activeTab, setActiveTab] = useState<'json' | 'inspector'>('json');
  const [copiedJson, setCopiedJson] = useState(false);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  const packedFrame = atlasResult?.packedFrames.find(
    (pf) =>
      pf.animationId === activeAnimId && pf.frameIndex === activeFrameIndex
  );

  const handleCopyJson = () => {
    const source = jsonString || atlasResult?.jsonString;
    if (!source) return;
    navigator.clipboard.writeText(source);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 1800);
  };

  const getEngineCodeSnippet = (): string => {
    const base = settings.projectName || 'wisp_mage_atlas';
    if (settings.format === 'phaser-hash') {
      return `// Phaser 3 Scene Loader & Animation Setup
preload() {
  this.load.atlas('${base}', '${base}.png', '${base}.json');
}
create() {
  this.anims.create({
    key: 'idle',
    frames: this.anims.generateFrameNames('${base}', {
      prefix: 'wisp_mage_idle_', suffix: '.png', zeroPad: 2, start: 0, end: 7
    }),
    frameRate: 10,
    repeat: -1
  });
  const wisp = this.add.sprite(400, 300, '${base}').play('idle');
}`;
    }
    if (settings.format === 'texturepacker-array') {
      return `// PixiJS v8 Assets Loader
import { Assets, AnimatedSprite } from 'pixi.js';

const sheet = await Assets.load('${base}.json');
const wisp = new AnimatedSprite(sheet.animations['idle']);
wisp.animationSpeed = 0.18;
wisp.play();
app.stage.addChild(wisp);`;
    }
    if (settings.format === 'aseprite') {
      return `// Phaser 3 Aseprite Tag Importer
preload() {
  this.load.aseprite('${base}', '${base}.png', '${base}.json');
}
create() {
  this.anims.createFromAseprite('${base}');
  this.add.sprite(400, 300, '${base}').play({ key: 'idle', repeat: -1 });
}`;
    }
    return `// Unity / Godot Custom JSON Atlas Parser
// Load ${base}.png + ${base}.json into your SpriteRenderer
const atlas = JSON.parse(FileAccess.get_file_as_string("res://${base}.json"));`;
  };

  const handleCopySnippet = () => {
    navigator.clipboard.writeText(getEngineCodeSnippet());
    setCopiedSnippet(true);
    setTimeout(() => setCopiedSnippet(false), 1800);
  };

  const activeJson = jsonString || atlasResult?.jsonString || '';
  const jsonKb = activeJson ? (new Blob([activeJson]).size / 1024).toFixed(1) : '0.0';

  return (
    <aside className="right-inspector w-[340px] bg-[#121622] border-l border-[#232A3E] flex flex-col shrink-0 select-none h-full overflow-hidden">
      {/* Top Tab Switcher */}
      <div className="grid grid-cols-2 border-b border-[#232A3E] bg-[#0B0D14]/60 p-1 gap-1">
        <button
          onClick={() => setActiveTab('json')}
          className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
            activeTab === 'json'
              ? 'bg-[#1A2030] text-[#F59E0B] border border-[#F59E0B]/30 shadow-sm'
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          <FileCode2 className="w-3.5 h-3.5" />
          <span>{isImportedAsset ? 'Artwork .JSON' : 'Live .JSON Atlas'}</span>
        </button>
        <button
          onClick={() => setActiveTab('inspector')}
          className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
            activeTab === 'inspector'
              ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30 shadow-sm'
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Frame &amp; Hitboxes</span>
        </button>
      </div>

      {/* Tab Body */}
      {activeTab === 'json' ? (
        <div className="flex-1 flex flex-col overflow-hidden p-3 gap-3">
          {/* JSON Header Action Bar */}
          <div className="flex items-center justify-between bg-[#0B0D14] border border-[#232A3E] rounded-lg px-2.5 py-2">
            <div>
              <div className="font-mono-code text-xs font-semibold text-[#F1F5F9] flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#10B981]" />
                <span>{settings.projectName}.json</span>
              </div>
              <span className="text-[10px] font-mono-code text-[#64748B]">
                {jsonKb} KB • {isImportedAsset ? '1 static artwork' : `${atlasResult?.packedFrames.length || 0} frame slices`}
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                onClick={handleCopyJson}
                className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A2030] hover:bg-[#232A3E] border border-[#232A3E] text-[11px] font-medium text-[#F1F5F9] transition-colors cursor-pointer"
                title="Copy full .JSON Texture Atlas to clipboard"
              >
                {copiedJson ? (
                  <>
                    <Check className="w-3 h-3 text-[#10B981]" />
                    <span className="text-[#10B981]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-[#38BDF8]" />
                    <span>Copy</span>
                  </>
                )}
              </button>

              <button
                onClick={onDownloadJson}
                className="p-1.5 rounded bg-[#F59E0B]/15 hover:bg-[#F59E0B]/25 border border-[#F59E0B]/40 text-[#F59E0B] transition-colors cursor-pointer"
                title="Download .JSON file"
              >
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Active Frame Slice Highlight Pill */}
          {packedFrame && (
            <div className="bg-[#1A2030]/60 border border-[#38BDF8]/30 rounded-lg p-2.5 space-y-1">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-[#38BDF8] font-mono-code font-semibold">
                  {packedFrame.frameKey}
                </span>
                <span className="text-[10px] font-mono-code text-[#94A3B8]">
                  Active Slice
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1 pt-1 font-mono-code text-[11px]">
                <div className="bg-[#0B0D14] rounded px-1.5 py-1 border border-[#232A3E]">
                  <span className="text-[#64748B] text-[9px] block">X</span>
                  <span className="text-[#F1F5F9]">{packedFrame.x}</span>
                </div>
                <div className="bg-[#0B0D14] rounded px-1.5 py-1 border border-[#232A3E]">
                  <span className="text-[#64748B] text-[9px] block">Y</span>
                  <span className="text-[#F1F5F9]">{packedFrame.y}</span>
                </div>
                <div className="bg-[#0B0D14] rounded px-1.5 py-1 border border-[#232A3E]">
                  <span className="text-[#64748B] text-[9px] block">W</span>
                  <span className="text-[#38BDF8]">{packedFrame.w}</span>
                </div>
                <div className="bg-[#0B0D14] rounded px-1.5 py-1 border border-[#232A3E]">
                  <span className="text-[#64748B] text-[9px] block">H</span>
                  <span className="text-[#38BDF8]">{packedFrame.h}</span>
                </div>
              </div>
            </div>
          )}

          {/* Live JSON Code Viewer */}
          <div className="flex-1 bg-[#0B0D14] border border-[#232A3E] rounded-lg overflow-hidden flex flex-col">
            <div className="px-2.5 py-1.5 border-b border-[#232A3E] bg-[#121622] flex items-center justify-between text-[10px] font-mono-code text-[#64748B]">
              <span>SCHEMA: {isImportedAsset ? 'ELEMENTAL-REALMS-ASSET-V1' : settings.format.toUpperCase()}</span>
              <span>UTF-8 • LIVE SYNC</span>
            </div>
            <pre className="flex-1 overflow-auto p-3 font-mono-code text-[11px] leading-[1.55] text-[#CBD5E1] selection:bg-[#38BDF8]/30">
              {activeJson || '// Import artwork or generate an asset to see JSON.'}
            </pre>
          </div>

          {/* Quick Engine Loader Code Snippet */}
          <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg overflow-hidden shrink-0">
            <div className="px-2.5 py-1.5 border-b border-[#232A3E] bg-[#1A2030]/60 flex items-center justify-between">
              <span className="text-[11px] font-semibold text-[#94A3B8] flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Engine Integration Snippet</span>
              </span>
              <button
                onClick={handleCopySnippet}
                className="text-[10px] font-mono-code text-[#38BDF8] hover:underline flex items-center gap-1 cursor-pointer"
              >
                {copiedSnippet ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
            <pre className="p-2.5 font-mono-code text-[10px] leading-relaxed text-[#94A3B8] overflow-x-auto max-h-28">
              {getEngineCodeSnippet()}
            </pre>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto p-3 space-y-4">
          {currentFrame && (
            <>
              {/* Origin Pivot Editor */}
              <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F59E0B] flex items-center gap-1.5">
                    <Crosshair className="w-3.5 h-3.5" />
                    <span>Origin Pivot (Anchor)</span>
                  </span>
                  <button
                    onClick={() => onApplyPivotToAllFrames(currentFrame.pivot)}
                    className="text-[10px] font-mono-code text-[#38BDF8] hover:underline cursor-pointer"
                    title="Copy this pivot anchor to all frames in this animation"
                  >
                    Apply to Clip
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="text-[10px] font-mono-code text-[#64748B] block mb-1">
                      PIVOT X (0..1)
                    </label>
                    <input
                      type="number"
                      step="0.02"
                      min="0"
                      max="1"
                      value={currentFrame.pivot.x}
                      onChange={(e) =>
                        onUpdateCurrentFrame({
                          pivot: {
                            ...currentFrame.pivot,
                            x: parseFloat(e.target.value) || 0.5,
                          },
                        })
                      }
                      className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1 font-mono-code text-xs text-[#F1F5F9]"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono-code text-[#64748B] block mb-1">
                      PIVOT Y (0..1)
                    </label>
                    <input
                      type="number"
                      step="0.02"
                      min="0"
                      max="1"
                      value={currentFrame.pivot.y}
                      onChange={(e) =>
                        onUpdateCurrentFrame({
                          pivot: {
                            ...currentFrame.pivot,
                            y: parseFloat(e.target.value) || 0.78,
                          },
                        })
                      }
                      className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1 font-mono-code text-xs text-[#F1F5F9]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-1 pt-1">
                  {[
                    { label: 'Bottom Feet', x: 0.5, y: 0.85 },
                    { label: 'Center Mass', x: 0.5, y: 0.5 },
                    { label: 'Top Left', x: 0.0, y: 0.0 },
                  ].map((preset) => (
                    <button
                      key={preset.label}
                      onClick={() =>
                        onUpdateCurrentFrame({
                          pivot: { x: preset.x, y: preset.y },
                        })
                      }
                      className="py-1 px-1.5 rounded bg-[#121622] hover:bg-[#1A2030] border border-[#232A3E] text-[10px] text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Hurtbox Collider Editor */}
              <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-3 space-y-2.5">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#10B981] flex items-center gap-1.5">
                  <Shield className="w-3.5 h-3.5" />
                  <span>Body Hurtbox Bounds</span>
                </span>

                <div className="grid grid-cols-2 gap-2">
                  {(
                    [
                      { key: 'x', label: 'X Offset' },
                      { key: 'y', label: 'Y Offset' },
                      { key: 'w', label: 'Width' },
                      { key: 'h', label: 'Height' },
                    ] as const
                  ).map((field) => (
                    <div key={field.key}>
                      <label className="text-[10px] font-mono-code text-[#64748B] block mb-1">
                        {field.label}
                      </label>
                      <input
                        type="number"
                        value={currentFrame.hurtbox[field.key]}
                        onChange={(e) =>
                          onUpdateCurrentFrame({
                            hurtbox: {
                              ...currentFrame.hurtbox,
                              [field.key]: parseInt(e.target.value, 10) || 0,
                            },
                          })
                        }
                        className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1 font-mono-code text-xs text-[#F1F5F9]"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Active Attack / Spell Hitbox Editor */}
              <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-3 space-y-2.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#F43F5E] flex items-center gap-1.5">
                    <Sword className="w-3.5 h-3.5" />
                    <span>Attack / Spell Hitbox</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={Boolean(currentFrame.hitbox)}
                    onChange={(e) =>
                      onUpdateCurrentFrame({
                        hitbox: e.target.checked
                          ? { x: 142, y: 74, w: 96, h: 104 }
                          : null,
                      })
                    }
                    className="accent-[#F43F5E] w-4 h-4 cursor-pointer"
                  />
                </div>

                {currentFrame.hitbox ? (
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        { key: 'x', label: 'Hitbox X' },
                        { key: 'y', label: 'Hitbox Y' },
                        { key: 'w', label: 'Width' },
                        { key: 'h', label: 'Height' },
                      ] as const
                    ).map((field) => (
                      <div key={field.key}>
                        <label className="text-[10px] font-mono-code text-[#64748B] block mb-1">
                          {field.label}
                        </label>
                        <input
                          type="number"
                          value={currentFrame.hitbox![field.key]}
                          onChange={(e) =>
                            onUpdateCurrentFrame({
                              hitbox: {
                                ...currentFrame.hitbox!,
                                [field.key]: parseInt(e.target.value, 10) || 0,
                              },
                            })
                          }
                          className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1 font-mono-code text-xs text-[#F1F5F9]"
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-[#64748B]">
                    No active damage hitbox on this frame. Check the box above to attach a
                    combat collider slice to the exported JSON.
                  </p>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </aside>
  );
};

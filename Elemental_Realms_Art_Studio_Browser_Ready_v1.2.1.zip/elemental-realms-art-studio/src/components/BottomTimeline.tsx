import React, { useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Repeat,
  Plus,
  Trash2,
  Clock,
} from 'lucide-react';
import {
  AnimationId,
  CharacterCustomization,
  FrameData,
} from '../types/sprite';
import { ANIMATION_CONFIGS } from '../data/presets';
import { renderWispFrame } from '../engine/wispRenderer';

interface BottomTimelineProps {
  activeAnimId: AnimationId;
  frames: FrameData[];
  activeFrameIndex: number;
  onSelectFrameIndex: (index: number) => void;
  isPlaying: boolean;
  onTogglePlay: () => void;
  fps: number;
  onChangeFps: (fps: number) => void;
  loopMode: 'loop' | 'ping-pong' | 'once';
  onChangeLoopMode: (mode: 'loop' | 'ping-pong' | 'once') => void;
  customization: CharacterCustomization;
  onAddFrame: () => void;
  onRemoveFrame: () => void;
  onUpdateFrameDuration: (durationMs: number) => void;
}

const FrameThumbnail: React.FC<{
  animId: AnimationId;
  frameIndex: number;
  totalFrames: number;
  customization: CharacterCustomization;
}> = ({ animId, frameIndex, totalFrames, customization }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, 64, 64);
    renderWispFrame(ctx, animId, frameIndex, totalFrames, customization, 64);
  }, [animId, frameIndex, totalFrames, customization]);

  return <canvas ref={canvasRef} width={64} height={64} className="w-14 h-14 block" />;
};

export const BottomTimeline: React.FC<BottomTimelineProps> = ({
  activeAnimId,
  frames,
  activeFrameIndex,
  onSelectFrameIndex,
  isPlaying,
  onTogglePlay,
  fps,
  onChangeFps,
  loopMode,
  onChangeLoopMode,
  customization,
  onAddFrame,
  onRemoveFrame,
  onUpdateFrameDuration,
}) => {
  const animCfg = ANIMATION_CONFIGS.find((a) => a.id === activeAnimId);
  const currentFrame = frames[activeFrameIndex] || frames[0];

  return (
    <section className="h-[164px] bg-[#121622] border-t border-[#232A3E] flex flex-col shrink-0 select-none">
      {/* Timeline Control Header Bar */}
      <div className="h-9 border-b border-[#232A3E] px-3 flex items-center justify-between bg-[#0B0D14]/60">
        {/* Left: Playback Transport */}
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-[#121622] border border-[#232A3E] rounded-md p-0.5">
            <button
              onClick={() =>
                onSelectFrameIndex(
                  (activeFrameIndex - 1 + frames.length) % frames.length
                )
              }
              className="p-1 text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
              title="Previous Frame"
            >
              <SkipBack className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={onTogglePlay}
              className={`px-2.5 py-1 rounded flex items-center gap-1 text-xs font-semibold transition-colors cursor-pointer ${
                isPlaying
                  ? 'bg-[#F59E0B] text-[#0B0D14]'
                  : 'bg-[#38BDF8] text-[#0B0D14]'
              }`}
              title={isPlaying ? 'Pause Playback' : 'Play Animation'}
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3 h-3 fill-current" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 fill-current" />
                  <span>Play</span>
                </>
              )}
            </button>
            <button
              onClick={() =>
                onSelectFrameIndex((activeFrameIndex + 1) % frames.length)
              }
              className="p-1 text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
              title="Next Frame"
            >
              <SkipForward className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Loop Mode Switcher */}
          <button
            onClick={() => {
              const order: Array<'loop' | 'ping-pong' | 'once'> = [
                'loop',
                'ping-pong',
                'once',
              ];
              const next = order[(order.indexOf(loopMode) + 1) % order.length];
              onChangeLoopMode(next);
            }}
            className="flex items-center gap-1.5 px-2 py-1 rounded bg-[#121622] border border-[#232A3E] hover:border-[#38BDF8]/40 text-[11px] font-mono-code text-[#94A3B8] hover:text-[#F1F5F9] cursor-pointer"
            title="Cycle Loop Direction (Forward Loop / Ping-Pong / Once)"
          >
            <Repeat className="w-3 h-3 text-[#38BDF8]" />
            <span className="uppercase">{loopMode}</span>
          </button>

          {/* FPS Slider */}
          <div className="flex items-center gap-2 bg-[#121622] border border-[#232A3E] rounded px-2.5 py-1">
            <span className="text-[11px] text-[#94A3B8]">Speed:</span>
            <input
              type="range"
              min="2"
              max="24"
              value={fps}
              onChange={(e) => onChangeFps(parseInt(e.target.value, 10))}
              className="w-20 accent-[#38BDF8] cursor-pointer"
            />
            <span className="font-mono-code text-[11px] text-[#38BDF8] font-semibold min-w-[40px]">
              {fps} FPS
            </span>
          </div>
        </div>

        {/* Center: Active Animation Clip Status */}
        <div className="hidden md:flex items-center gap-2 text-xs">
          <span className="text-[#64748B] font-mono-code">CLIP:</span>
          <span className="font-mono-code font-semibold text-[#F1F5F9] bg-[#1A2030] px-2 py-0.5 rounded border border-[#232A3E]">
            {animCfg?.label}
          </span>
          <span className="font-mono-code text-[11px] text-[#94A3B8]">
            Frame {activeFrameIndex + 1} of {frames.length}
          </span>
        </div>

        {/* Right: Frame Duration & Add/Delete Frame */}
        <div className="flex items-center gap-2">
          {currentFrame && (
            <div className="flex items-center gap-1.5 bg-[#121622] border border-[#232A3E] rounded px-2 py-0.5">
              <Clock className="w-3 h-3 text-[#F59E0B]" />
              <span className="text-[10px] text-[#94A3B8]">Duration:</span>
              <input
                type="number"
                min={16}
                max={1000}
                step={10}
                value={currentFrame.durationMs}
                onChange={(e) =>
                  onUpdateFrameDuration(
                    Math.max(16, parseInt(e.target.value, 10) || 80)
                  )
                }
                className="w-12 bg-transparent font-mono-code text-[11px] text-[#F1F5F9] focus:outline-none text-right"
              />
              <span className="text-[10px] font-mono-code text-[#64748B]">ms</span>
            </div>
          )}

          <button
            onClick={onAddFrame}
            disabled={frames.length >= 16}
            className="flex items-center gap-1 px-2 py-1 rounded bg-[#1A2030] hover:bg-[#232A3E] disabled:opacity-40 border border-[#232A3E] text-[11px] font-medium text-[#F1F5F9] cursor-pointer"
            title="Append Frame to Clip"
          >
            <Plus className="w-3 h-3 text-[#38BDF8]" />
            <span>Add Frame</span>
          </button>

          <button
            onClick={onRemoveFrame}
            disabled={frames.length <= 2}
            className="p-1 rounded bg-[#1A2030] hover:bg-[#F43F5E]/20 disabled:opacity-40 border border-[#232A3E] hover:border-[#F43F5E]/40 text-[#94A3B8] hover:text-[#F43F5E] cursor-pointer"
            title="Remove Last Frame"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Horizontal Frame Strip */}
      <div className="flex-1 overflow-x-auto px-3 py-2 flex items-center gap-2.5">
        {frames.map((frame, idx) => {
          const isSelected = idx === activeFrameIndex;
          return (
            <button
              key={frame.name + idx}
              onClick={() => onSelectFrameIndex(idx)}
              className={`group relative flex flex-col items-center p-1.5 rounded-lg border transition-all shrink-0 cursor-pointer ${
                isSelected
                  ? 'bg-[#1A2030] border-[#38BDF8] shadow-[0_0_16px_rgba(56,189,248,0.22)] scale-[1.02]'
                  : 'bg-[#0B0D14]/80 border-[#232A3E] hover:border-[#38BDF8]/40'
              }`}
            >
              {/* Top Frame Number + Hitbox Dot */}
              <div className="w-full flex items-center justify-between px-1 mb-0.5">
                <span
                  className={`font-mono-code text-[10px] font-bold ${
                    isSelected ? 'text-[#38BDF8]' : 'text-[#64748B]'
                  }`}
                >
                  #{String(idx + 1).padStart(2, '0')}
                </span>
                {frame.hitbox && (
                  <span
                    className="w-1.5 h-1.5 rounded-full bg-[#F43F5E]"
                    title="Active Attack/Spell Hitbox on this frame"
                  />
                )}
              </div>

              {/* Thumbnail Canvas on dark alpha checker */}
              <div className="rounded bg-alpha-checker-sm border border-[#232A3E]/80 overflow-hidden">
                <FrameThumbnail
                  animId={activeAnimId}
                  frameIndex={idx}
                  totalFrames={frames.length}
                  customization={customization}
                />
              </div>

              {/* Frame Duration Footer */}
              <span className="mt-1 font-mono-code text-[9px] text-[#94A3B8]">
                {frame.durationMs}ms
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
};

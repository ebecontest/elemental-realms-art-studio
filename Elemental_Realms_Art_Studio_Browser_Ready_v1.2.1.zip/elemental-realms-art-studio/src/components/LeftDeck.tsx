import React, { useState } from 'react';
import {
  Film,
  Palette,
  Grid,
  FlipHorizontal,
  Sparkles,
  Sliders,
  Wand2,
  RotateCcw,
} from 'lucide-react';
import {
  AnimationId,
  AtlasSettings,
  AuraStyle,
  BrowGemType,
  CharacterCustomization,
  FrameData,
  PropType,
  SheetLayoutMode,
} from '../types/sprite';
import { ANIMATION_CONFIGS, WISP_PALETTES } from '../data/presets';
import { getActivePalette } from '../engine/wispRenderer';

interface LeftDeckProps {
  activeAnimId: AnimationId;
  onSelectAnim: (id: AnimationId) => void;
  framesByAnim: Record<AnimationId, FrameData[]>;
  customization: CharacterCustomization;
  onUpdateCustomization: (partial: Partial<CharacterCustomization>) => void;
  settings: AtlasSettings;
  onUpdateSettings: (partial: Partial<AtlasSettings>) => void;
  onResetCharacter: () => void;
}

export const LeftDeck: React.FC<LeftDeckProps> = ({
  activeAnimId,
  onSelectAnim,
  framesByAnim,
  customization,
  onUpdateCustomization,
  settings,
  onUpdateSettings,
  onResetCharacter,
}) => {
  const [activeTab, setActiveTab] = useState<'clips' | 'rig' | 'packing'>('clips');
  const activePalette = getActivePalette(customization);

  const handleCustomColorChange = (key: keyof typeof activePalette, value: string) => {
    onUpdateCustomization({
      customPalette: {
        ...activePalette,
        id: 'custom',
        name: 'Custom Astral Theme',
        badge: 'Custom',
        [key]: value,
      },
    });
  };

  return (
    <aside className="left-deck w-[280px] bg-[#121622] border-r border-[#232A3E] flex flex-col shrink-0 select-none h-full overflow-hidden">
      {/* Sub-navigation Tabs */}
      <div className="grid grid-cols-3 border-b border-[#232A3E] bg-[#0B0D14]/60 p-1 gap-1">
        <button
          onClick={() => setActiveTab('clips')}
          className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
            activeTab === 'clips'
              ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30 shadow-sm'
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          <Film className="w-3.5 h-3.5" />
          <span>Clips (6)</span>
        </button>
        <button
          onClick={() => setActiveTab('rig')}
          className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
            activeTab === 'rig'
              ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30 shadow-sm'
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>Style &amp; Rig</span>
        </button>
        <button
          onClick={() => setActiveTab('packing')}
          className={`flex items-center justify-center gap-1.5 py-1.5 rounded text-xs font-medium transition-colors cursor-pointer ${
            activeTab === 'packing'
              ? 'bg-[#1A2030] text-[#38BDF8] border border-[#38BDF8]/30 shadow-sm'
              : 'text-[#94A3B8] hover:text-[#F1F5F9]'
          }`}
        >
          <Grid className="w-3.5 h-3.5" />
          <span>Packing</span>
        </button>
      </div>

      {/* Tab Content Area */}
      <div className="flex-1 overflow-y-auto p-3 space-y-4">
        {activeTab === 'clips' && (
          <>
            {/* Atlas Export Scope Switch */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                  Sprite Sheet Scope
                </span>
                <span className="text-[10px] font-mono-code text-[#38BDF8]">
                  {settings.scope === 'all-animations' ? '50 Frames' : 'Single Strip'}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-1 bg-[#121622] p-1 rounded border border-[#232A3E]">
                <button
                  onClick={() => onUpdateSettings({ scope: 'all-animations' })}
                  className={`py-1 px-2 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    settings.scope === 'all-animations'
                      ? 'bg-[#38BDF8] text-[#0B0D14] font-semibold'
                      : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                  }`}
                >
                  All 6 Clips
                </button>
                <button
                  onClick={() => onUpdateSettings({ scope: 'current-animation' })}
                  className={`py-1 px-2 rounded text-[11px] font-medium transition-all cursor-pointer ${
                    settings.scope === 'current-animation'
                      ? 'bg-[#38BDF8] text-[#0B0D14] font-semibold'
                      : 'text-[#94A3B8] hover:text-[#F1F5F9]'
                  }`}
                >
                  Active Clip Only
                </button>
              </div>
            </div>

            {/* Animation State Cards */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between px-0.5">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                  Animation States
                </span>
                <span className="text-[10px] font-mono-code text-[#64748B]">
                  Click to preview
                </span>
              </div>

              {ANIMATION_CONFIGS.map((anim) => {
                const isSelected = anim.id === activeAnimId;
                const frames = framesByAnim[anim.id] || [];
                return (
                  <button
                    key={anim.id}
                    onClick={() => onSelectAnim(anim.id)}
                    className={`w-full text-left p-2.5 rounded-lg border transition-all cursor-pointer group ${
                      isSelected
                        ? 'bg-[#1A2030] border-[#38BDF8] shadow-[0_0_15px_rgba(56,189,248,0.12)]'
                        : 'bg-[#0B0D14]/70 border-[#232A3E] hover:border-[#38BDF8]/40 hover:bg-[#1A2030]/50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-2 h-2 rounded-full ${
                            isSelected
                              ? 'bg-[#38BDF8] shadow-[0_0_8px_#38BDF8]'
                              : 'bg-[#64748B]'
                          }`}
                        />
                        <span className="font-mono-code text-xs font-semibold text-[#F1F5F9]">
                          {anim.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5">
                        {anim.hasActiveHitbox && (
                          <span className="text-[9px] font-mono-code px-1.5 py-0.5 rounded bg-[#F43F5E]/15 text-[#F43F5E] border border-[#F43F5E]/30">
                            HITBOX
                          </span>
                        )}
                        <span className="text-[10px] font-mono-code px-1.5 py-0.5 rounded bg-[#121622] text-[#94A3B8] border border-[#232A3E]">
                          {frames.length}f • {anim.fps}fps
                        </span>
                      </div>
                    </div>
                    <p className="text-[11px] text-[#94A3B8] mt-1 line-clamp-1 pl-4">
                      {anim.description}
                    </p>
                  </button>
                );
              })}
            </div>

            {/* Direction & Quick Orientation */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] block">
                Character Orientation
              </span>
              <button
                onClick={() =>
                  onUpdateCustomization({ flipX: !customization.flipX })
                }
                className="w-full flex items-center justify-between px-3 py-1.5 rounded bg-[#1A2030] hover:bg-[#232A3E] border border-[#232A3E] text-xs text-[#F1F5F9] transition-colors cursor-pointer"
              >
                <span className="flex items-center gap-2">
                  <FlipHorizontal className="w-3.5 h-3.5 text-[#38BDF8]" />
                  <span>Facing Direction</span>
                </span>
                <span className="font-mono-code text-[11px] text-[#38BDF8]">
                  {customization.flipX ? 'Left (Mirrored)' : 'Right (Standard)'}
                </span>
              </button>
            </div>
          </>
        )}

        {activeTab === 'rig' && (
          <>
            {/* Palette / ELEMENTAL REALMS • ELEMENT PRESETSs */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8]">
                  ELEMENTAL REALMS • ELEMENT PRESETS
                </span>
                <button
                  onClick={onResetCharacter}
                  className="text-[10px] text-[#94A3B8] hover:text-[#38BDF8] flex items-center gap-1 cursor-pointer"
                  title="Reset to Light Element"
                >
                  <RotateCcw className="w-3 h-3" />
                  <span>Reset</span>
                </button>
              </div>

              <div className="space-y-1.5">
                {WISP_PALETTES.map((pal) => {
                  const isSelected =
                    !customization.customPalette && customization.paletteId === pal.id;
                  return (
                    <button
                      key={pal.id}
                      onClick={() =>
                        onUpdateCustomization({
                          paletteId: pal.id,
                          customPalette: undefined,
                        })
                      }
                      className={`w-full p-2 rounded-lg border text-left transition-all cursor-pointer flex items-center justify-between ${
                        isSelected
                          ? 'bg-[#1A2030] border-[#38BDF8]'
                          : 'bg-[#0B0D14]/70 border-[#232A3E] hover:border-[#38BDF8]/40'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-semibold text-[#F1F5F9] flex items-center gap-1.5">
                          <span>{pal.name}</span>
                          {pal.id === 'astral-sanctum' && (
                            <span className="text-[9px] font-mono-code px-1 py-0.2 bg-[#F59E0B]/20 text-[#F59E0B] border border-[#F59E0B]/40 rounded">
                              LIGHT
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-[#64748B]">{pal.badge}</span>
                      </div>
                      {/* Swatch preview pills */}
                      <div className="flex items-center -space-x-1">
                        {[
                          pal.robeLight,
                          pal.robeShadow,
                          pal.trimBase,
                          pal.gemMid,
                          pal.wispMid,
                        ].map((hex, i) => (
                          <span
                            key={i}
                            className="w-4 h-4 rounded-full border border-[#0B0D14] shadow-sm"
                            style={{ backgroundColor: hex }}
                          />
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Fine-Tune Custom Color Swatches */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] block">
                Fine-Tune Shader Colors
              </span>
              <div className="grid grid-cols-2 gap-2">
                {[
                  { label: 'Hood Mid', key: 'robeMid' as const },
                  { label: 'Gold Trim', key: 'trimBase' as const },
                  { label: 'Sapphire Gem', key: 'gemMid' as const },
                  { label: 'Eye Bloom', key: 'eyeGlow' as const },
                  { label: 'Spirit Wisp', key: 'wispMid' as const },
                  { label: 'Top Plume Core', key: 'wispDarkPlume' as const },
                ].map((item) => (
                  <label
                    key={item.key}
                    className="flex items-center justify-between bg-[#121622] border border-[#232A3E] rounded px-2 py-1 text-[11px] text-[#94A3B8] cursor-pointer hover:border-[#38BDF8]/40"
                  >
                    <span className="truncate">{item.label}</span>
                    <input
                      type="color"
                      value={activePalette[item.key]}
                      onChange={(e) => handleCustomColorChange(item.key, e.target.value)}
                      className="w-4 h-4 rounded border-0 bg-transparent cursor-pointer"
                    />
                  </label>
                ))}
              </div>
            </div>

            {/* Equipped Mage Prop / Weapon */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] flex items-center gap-1.5">
                <Wand2 className="w-3.5 h-3.5 text-[#F59E0B]" />
                <span>Equipped Relic / Prop</span>
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {(
                  [
                    { id: 'none', label: 'None (Reference)' },
                    { id: 'grimoire', label: 'Astral Grimoire' },
                    { id: 'orb-staff', label: 'Sapphire Staff' },
                    { id: 'arcane-runes', label: 'Tri-Runes' },
                    { id: 'soul-lantern', label: 'Soul Lantern' },
                  ] as { id: PropType; label: string }[]
                ).map((prop) => (
                  <button
                    key={prop.id}
                    onClick={() => onUpdateCustomization({ propType: prop.id })}
                    className={`px-2 py-1.5 rounded text-[11px] font-medium border text-left transition-colors cursor-pointer ${
                      customization.propType === prop.id
                        ? 'bg-[#1A2030] border-[#38BDF8] text-[#38BDF8]'
                        : 'bg-[#0B0D14] border-[#232A3E] text-[#94A3B8] hover:text-[#F1F5F9]'
                    }`}
                  >
                    {prop.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Forehead Crest & Aura FX */}
            <div className="space-y-2 bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Hood Crest &amp; Spirit Aura</span>
              </span>

              <div className="space-y-1">
                <label className="text-[11px] text-[#94A3B8] block">Forehead Gem</label>
                <select
                  value={customization.browGemType}
                  onChange={(e) =>
                    onUpdateCustomization({
                      browGemType: e.target.value as BrowGemType,
                    })
                  }
                  className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#38BDF8]"
                >
                  <option value="sapphire-diamond">Diamond Sapphire (Reference)</option>
                  <option value="astral-halo">Sapphire + Floating Halo</option>
                  <option value="trinity-crest">Trinity Gem Diadem</option>
                  <option value="minimal-gold">Gold Bezel Only</option>
                </select>
              </div>

              <div className="space-y-1 pt-1">
                <label className="text-[11px] text-[#94A3B8] block">Ambient Particles</label>
                <select
                  value={customization.auraStyle}
                  onChange={(e) =>
                    onUpdateCustomization({
                      auraStyle: e.target.value as AuraStyle,
                    })
                  }
                  className="w-full bg-[#121622] border border-[#232A3E] rounded px-2 py-1.5 text-xs text-[#F1F5F9] focus:outline-none focus:border-[#38BDF8]"
                >
                  <option value="mana-motes">Floating Mana Motes</option>
                  <option value="orbiting-runes">Orbiting Astral Crystals</option>
                  <option value="spirit-flames">Soft Bioluminescent Halo</option>
                  <option value="none">Clean Silhouette (No Particles)</option>
                </select>
              </div>
            </div>

            {/* Wisp Proportions & Shader Sliders */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2.5">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] flex items-center gap-1.5">
                <Sliders className="w-3.5 h-3.5 text-[#38BDF8]" />
                <span>Spirit Wisp Proportions</span>
              </span>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Top Dark-Cyan Plume</span>
                  <span className="font-mono-code text-[#F1F5F9]">
                    {Math.round(customization.topPlumeScale * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.4"
                  step="0.05"
                  value={customization.topPlumeScale}
                  onChange={(e) =>
                    onUpdateCustomization({ topPlumeScale: parseFloat(e.target.value) })
                  }
                  className="w-full accent-[#38BDF8] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Back Swallowtail Ribbon</span>
                  <span className="font-mono-code text-[#F1F5F9]">
                    {Math.round(customization.backRibbonScale * 100)}%
                  </span>
                </div>
                <input
                  type="range"
                  min="0.5"
                  max="1.4"
                  step="0.05"
                  value={customization.backRibbonScale}
                  onChange={(e) =>
                    onUpdateCustomization({
                      backRibbonScale: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-[#38BDF8] cursor-pointer"
                />
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Ink Outline Weight</span>
                  <span className="font-mono-code text-[#F1F5F9]">
                    {customization.outlineThickness.toFixed(1)}x
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="2"
                  step="0.2"
                  value={customization.outlineThickness}
                  onChange={(e) =>
                    onUpdateCustomization({
                      outlineThickness: parseFloat(e.target.value),
                    })
                  }
                  className="w-full accent-[#38BDF8] cursor-pointer"
                />
              </div>
            </div>
          </>
        )}

        {activeTab === 'packing' && (
          <>
            {/* Cell Frame Resolution */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] block">
                Frame Cell Resolution
              </span>
              <div className="grid grid-cols-4 gap-1">
                {([64, 128, 256, 512] as const).map((size) => (
                  <button
                    key={size}
                    onClick={() => onUpdateSettings({ frameSize: size })}
                    className={`py-1.5 rounded font-mono-code text-xs border transition-colors cursor-pointer ${
                      settings.frameSize === size
                        ? 'bg-[#38BDF8]/15 border-[#38BDF8] text-[#38BDF8] font-bold'
                        : 'bg-[#121622] border-[#232A3E] text-[#94A3B8] hover:text-[#F1F5F9]'
                    }`}
                  >
                    {size}px
                  </button>
                ))}
              </div>
            </div>

            {/* Atlas Packing Layout Mode */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-2">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-[#94A3B8] block">
                Sheet Packing Algorithm
              </span>
              <div className="space-y-1.5">
                {(
                  [
                    {
                      id: 'rows-by-animation',
                      label: 'Rows by Animation State',
                      desc: '1 row per clip (Ideal for readability)',
                    },
                    {
                      id: 'compact-grid',
                      label: 'Compact N-Column Grid',
                      desc: 'Tight rectangular atlas packing',
                    },
                    {
                      id: 'horizontal-strip',
                      label: 'Single Horizontal Strip',
                      desc: '1D linear strip for simple shaders',
                    },
                  ] as { id: SheetLayoutMode; label: string; desc: string }[]
                ).map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => onUpdateSettings({ layoutMode: mode.id })}
                    className={`w-full p-2 rounded border text-left transition-colors cursor-pointer ${
                      settings.layoutMode === mode.id
                        ? 'bg-[#1A2030] border-[#38BDF8] text-[#F1F5F9]'
                        : 'bg-[#121622] border-[#232A3E] text-[#94A3B8] hover:text-[#F1F5F9]'
                    }`}
                  >
                    <div className="text-xs font-medium">{mode.label}</div>
                    <div className="text-[10px] text-[#64748B]">{mode.desc}</div>
                  </button>
                ))}
              </div>

              {settings.layoutMode === 'compact-grid' && (
                <div className="pt-2">
                  <div className="flex justify-between text-[11px] mb-1">
                    <span className="text-[#94A3B8]">Grid Columns</span>
                    <span className="font-mono-code text-[#38BDF8]">
                      {settings.maxColumns} cols
                    </span>
                  </div>
                  <input
                    type="range"
                    min="2"
                    max="16"
                    value={settings.maxColumns}
                    onChange={(e) =>
                      onUpdateSettings({ maxColumns: parseInt(e.target.value, 10) })
                    }
                    className="w-full accent-[#38BDF8] cursor-pointer"
                  />
                </div>
              )}
            </div>

            {/* Padding & Power-Of-Two */}
            <div className="bg-[#0B0D14] border border-[#232A3E] rounded-lg p-2.5 space-y-3">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span className="text-[#94A3B8]">Frame Inner Padding</span>
                  <span className="font-mono-code text-[#F1F5F9]">
                    {settings.padding}px
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="16"
                  step="2"
                  value={settings.padding}
                  onChange={(e) =>
                    onUpdateSettings({ padding: parseInt(e.target.value, 10) })
                  }
                  className="w-full accent-[#38BDF8] cursor-pointer"
                />
              </div>

              <label className="flex items-center justify-between text-xs text-[#F1F5F9] cursor-pointer pt-1 border-t border-[#232A3E]">
                <div>
                  <span className="block font-medium">Power-of-Two (POT) Size</span>
                  <span className="text-[10px] text-[#64748B]">
                    Pad sheet to 512/1024/2048px for GPU mipmaps
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.powerOfTwo}
                  onChange={(e) =>
                    onUpdateSettings({ powerOfTwo: e.target.checked })
                  }
                  className="accent-[#38BDF8] w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between text-xs text-[#F1F5F9] cursor-pointer pt-2 border-t border-[#232A3E]">
                <div>
                  <span className="block font-medium">Transparent Alpha (.PNG)</span>
                  <span className="text-[10px] text-[#64748B]">
                    Uncheck for solid dark background like reference
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={settings.transparentBackground}
                  onChange={(e) =>
                    onUpdateSettings({ transparentBackground: e.target.checked })
                  }
                  className="accent-[#38BDF8] w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </>
        )}
      </div>
    </aside>
  );
};

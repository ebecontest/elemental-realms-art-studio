import { AnimationConfig, AnimationId, FrameData, WispPalette } from '../types/sprite';

export const WISP_PALETTES: WispPalette[] = [
  {
    id: 'astral-sanctum',
    name: 'Astral Sanctum',
    badge: 'Reference Original',
    robeLight: '#FFFFFF',
    robeMid: '#CBD2F6',
    robeShadow: '#7A82C4',
    robeDeepShadow: '#353A70',
    trimHighlight: '#FFF3A8',
    trimBase: '#F59E0B',
    trimShadow: '#B45309',
    trimDark: '#6B2F06',
    gemHighlight: '#E0F2FE',
    gemMid: '#22B8CF',
    gemDeep: '#0369A1',
    faceVoidTop: '#060814',
    faceVoidBottom: '#131C3E',
    eyeCore: '#FFFFFF',
    eyeGlow: '#38BDF8',
    wispCore: '#E0F7FF',
    wispMid: '#5CE1E6',
    wispOuter: '#1D63B8',
    wispDarkPlume: '#0C1838',
    outlineColor: '#0A0D1C',
  },
  {
    id: 'solaris-archon',
    name: 'Solaris Archon',
    badge: 'Sunfire Variant',
    robeLight: '#FFFDF9',
    robeMid: '#FDE2C4',
    robeShadow: '#C26D53',
    robeDeepShadow: '#5E2429',
    trimHighlight: '#FFF9C2',
    trimBase: '#FBBF24',
    trimShadow: '#B45309',
    trimDark: '#5C2804',
    gemHighlight: '#FFE4E6',
    gemMid: '#F43F5E',
    gemDeep: '#9F1239',
    faceVoidTop: '#16070B',
    faceVoidBottom: '#3B1219',
    eyeCore: '#FFFBEB',
    eyeGlow: '#FB923C',
    wispCore: '#FEF9C3',
    wispMid: '#FB923C',
    wispOuter: '#DC2626',
    wispDarkPlume: '#380D14',
    outlineColor: '#18070B',
  },
  {
    id: 'voidweaver-echo',
    name: 'Voidweaver Echo',
    badge: 'Abyssal Variant',
    robeLight: '#E9D5FF',
    robeMid: '#A882DD',
    robeShadow: '#583A8A',
    robeDeepShadow: '#231342',
    trimHighlight: '#F5D0FE',
    trimBase: '#C084FC',
    trimShadow: '#6B21A8',
    trimDark: '#3B0764',
    gemHighlight: '#FAE8FF',
    gemMid: '#E879F9',
    gemDeep: '#86198F',
    faceVoidTop: '#05020A',
    faceVoidBottom: '#1B0B2E',
    eyeCore: '#FDF4FF',
    eyeGlow: '#D946EF',
    wispCore: '#F5D0FE',
    wispMid: '#C084FC',
    wispOuter: '#6D28D9',
    wispDarkPlume: '#140826',
    outlineColor: '#090312',
  },
  {
    id: 'sylvan-oracle',
    name: 'Sylvan Elderwisp',
    badge: 'Emerald Variant',
    robeLight: '#F0FDF4',
    robeMid: '#A7F3D0',
    robeShadow: '#34856C',
    robeDeepShadow: '#153F37',
    trimHighlight: '#FEF08A',
    trimBase: '#D97706',
    trimShadow: '#78350F',
    trimDark: '#451A03',
    gemHighlight: '#DCFCE7',
    gemMid: '#10B981',
    gemDeep: '#065F46',
    faceVoidTop: '#04120E',
    faceVoidBottom: '#0F2E26',
    eyeCore: '#ECFDF5',
    eyeGlow: '#34D399',
    wispCore: '#D1FAE5',
    wispMid: '#34D399',
    wispOuter: '#059669',
    wispDarkPlume: '#06241D',
    outlineColor: '#04120E',
  },
  {
    id: 'frostborne-seer',
    name: 'Frostborne Seer',
    badge: 'Cryo Variant',
    robeLight: '#F8FAFC',
    robeMid: '#BAE6FD',
    robeShadow: '#5A89B8',
    robeDeepShadow: '#1E3A5F',
    trimHighlight: '#F1F5F9',
    trimBase: '#94A3B8',
    trimShadow: '#475569',
    trimDark: '#1E293B',
    gemHighlight: '#FFFFFF',
    gemMid: '#38BDF8',
    gemDeep: '#0284C7',
    faceVoidTop: '#060D1A',
    faceVoidBottom: '#0F2542',
    eyeCore: '#FFFFFF',
    eyeGlow: '#7DD3FC',
    wispCore: '#F0F9FF',
    wispMid: '#7DD3FC',
    wispOuter: '#0284C7',
    wispDarkPlume: '#0B1D36',
    outlineColor: '#071020',
  },
  {
    id: 'stormcaller-volt', name: 'Stormcaller', badge: 'Lightning Element',
    robeLight: '#F0F9FF', robeMid: '#BAE6FD', robeShadow: '#3979B8', robeDeepShadow: '#142D59',
    trimHighlight: '#FEF9C3', trimBase: '#EAB308', trimShadow: '#A16207', trimDark: '#713F12',
    gemHighlight: '#FFFFFF', gemMid: '#FDE047', gemDeep: '#CA8A04',
    faceVoidTop: '#050B1B', faceVoidBottom: '#10264B', eyeCore: '#FFFFFF', eyeGlow: '#FDE047',
    wispCore: '#FEF9C3', wispMid: '#FACC15', wispOuter: '#2563EB', wispDarkPlume: '#081A3A', outlineColor: '#071329'
  },
  {
    id: 'terracore-warden', name: 'Terracore', badge: 'Earth Element',
    robeLight: '#FEF3C7', robeMid: '#D6B887', robeShadow: '#96734B', robeDeepShadow: '#49351F',
    trimHighlight: '#FDE68A', trimBase: '#B77932', trimShadow: '#854D0E', trimDark: '#422006',
    gemHighlight: '#ECFCCB', gemMid: '#84CC16', gemDeep: '#3F6212',
    faceVoidTop: '#100B05', faceVoidBottom: '#302010', eyeCore: '#F7FEE7', eyeGlow: '#A3E635',
    wispCore: '#ECFCCB', wispMid: '#A3E635', wispOuter: '#78716C', wispDarkPlume: '#21180D', outlineColor: '#1C140B'
  },
];

export const ANIMATION_CONFIGS: AnimationConfig[] = [
  {
    id: 'idle',
    label: 'idle',
    description: 'Ethereal hovering breath & undulating spirit wisps',
    frameCount: 8,
    fps: 10,
    loopMode: 'loop',
    baseDurationMs: 100,
    hasActiveHitbox: false,
  },
  {
    id: 'move',
    label: 'float_move',
    description: 'Forward gliding drift with streaming cape & wisp trail',
    frameCount: 8,
    fps: 12,
    loopMode: 'loop',
    baseDurationMs: 83,
    hasActiveHitbox: false,
  },
  {
    id: 'cast',
    label: 'cast_spell',
    description: 'Sapphire gems ignite, cloak flares & arcane rune circle blooms',
    frameCount: 10,
    fps: 12,
    loopMode: 'loop',
    baseDurationMs: 83,
    hasActiveHitbox: true,
  },
  {
    id: 'attack',
    label: 'spirit_slash',
    description: 'Wind-up anticipation followed by astral crescent burst',
    frameCount: 8,
    fps: 14,
    loopMode: 'loop',
    baseDurationMs: 71,
    hasActiveHitbox: true,
  },
  {
    id: 'hit',
    label: 'hit_recoil',
    description: 'Damage stagger, squinted eyes & disrupted mana particles',
    frameCount: 6,
    fps: 12,
    loopMode: 'once',
    baseDurationMs: 83,
    hasActiveHitbox: false,
  },
  {
    id: 'defeat',
    label: 'defeat_dissolve',
    description: 'Spirit essence ascends into starlight as cloak gently settles',
    frameCount: 10,
    fps: 10,
    loopMode: 'once',
    baseDurationMs: 100,
    hasActiveHitbox: false,
  },
];

export function buildDefaultFrames(): Record<AnimationId, FrameData[]> {
  const result = {} as Record<AnimationId, FrameData[]>;

  for (const anim of ANIMATION_CONFIGS) {
    const frames: FrameData[] = [];
    for (let i = 0; i < anim.frameCount; i++) {
      const t = i / anim.frameCount;
      const rad = t * Math.PI * 2;
      const bobY = Math.round(Math.sin(rad) * 5);

      let hitbox = null;
      if (anim.id === 'cast' && i >= 3 && i <= 7) {
        hitbox = { x: 148, y: 78, w: 92, h: 96 };
      } else if (anim.id === 'attack' && i >= 2 && i <= 5) {
        hitbox = { x: 138, y: 68, w: 106, h: 112 };
      }

      frames.push({
        index: i,
        animationId: anim.id,
        frameNumber: i + 1,
        name: `wisp_mage_${anim.label}_${String(i).padStart(2, '0')}`,
        durationMs: anim.baseDurationMs,
        pivot: { x: 0.5, y: 0.78 },
        hurtbox: {
          x: 78,
          y: 54 + bobY,
          w: 104,
          h: 152,
        },
        hitbox,
        castSocket: {
          x: 192,
          y: 126 + bobY,
        },
      });
    }
    result[anim.id] = frames;
  }

  return result;
}

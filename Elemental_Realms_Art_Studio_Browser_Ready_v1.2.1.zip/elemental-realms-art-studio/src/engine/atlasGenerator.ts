import {
  AnimationId,
  AtlasSettings,
  CharacterCustomization,
  FrameData,
  GeneratedAtlasResult,
  PackedFrameRect,
} from '../types/sprite';
import { ANIMATION_CONFIGS } from '../data/presets';
import { renderWispFrame } from './wispRenderer';

function nextPowerOfTwo(n: number): number {
  let p = 1;
  while (p < n) {
    p <<= 1;
  }
  return p;
}

export function generateSpriteSheetAndJson(
  framesByAnim: Record<AnimationId, FrameData[]>,
  activeAnimId: AnimationId,
  customization: CharacterCustomization,
  settings: AtlasSettings
): GeneratedAtlasResult {
  const cellSize = settings.frameSize;
  const pad = settings.padding;
  const scaleFactor = cellSize / 256;

  const animList =
    settings.scope === 'all-animations'
      ? ANIMATION_CONFIGS
      : ANIMATION_CONFIGS.filter((a) => a.id === activeAnimId);

  const packedFrames: PackedFrameRect[] = [];
  let sheetWidth = 0;
  let sheetHeight = 0;

  if (settings.layoutMode === 'rows-by-animation') {
    // Each animation gets its own cleanly organized row
    const maxFramesInRow = Math.max(...animList.map((a) => framesByAnim[a.id].length));
    sheetWidth = maxFramesInRow * (cellSize + pad) + pad;
    sheetHeight = animList.length * (cellSize + pad) + pad;

    animList.forEach((anim, rowIdx) => {
      const animFrames = framesByAnim[anim.id];
      animFrames.forEach((f, colIdx) => {
        const x = pad + colIdx * (cellSize + pad);
        const y = pad + rowIdx * (cellSize + pad);
        packedFrames.push(createPackedRect(f, x, y, cellSize, scaleFactor));
      });
    });
  } else if (settings.layoutMode === 'horizontal-strip') {
    const allFrames = animList.flatMap((a) => framesByAnim[a.id]);
    sheetWidth = allFrames.length * (cellSize + pad) + pad;
    sheetHeight = cellSize + pad * 2;

    allFrames.forEach((f, idx) => {
      const x = pad + idx * (cellSize + pad);
      const y = pad;
      packedFrames.push(createPackedRect(f, x, y, cellSize, scaleFactor));
    });
  } else {
    // Compact grid using maxColumns
    const allFrames = animList.flatMap((a) => framesByAnim[a.id]);
    const cols = Math.max(1, Math.min(settings.maxColumns, allFrames.length));
    const rows = Math.ceil(allFrames.length / cols);
    sheetWidth = cols * (cellSize + pad) + pad;
    sheetHeight = rows * (cellSize + pad) + pad;

    allFrames.forEach((f, idx) => {
      const col = idx % cols;
      const row = Math.floor(idx / cols);
      const x = pad + col * (cellSize + pad);
      const y = pad + row * (cellSize + pad);
      packedFrames.push(createPackedRect(f, x, y, cellSize, scaleFactor));
    });
  }

  if (settings.powerOfTwo) {
    sheetWidth = nextPowerOfTwo(sheetWidth);
    sheetHeight = nextPowerOfTwo(sheetHeight);
  }

  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, sheetWidth);
  canvas.height = Math.max(1, sheetHeight);
  const ctx = canvas.getContext('2d');

  if (ctx) {
    if (!settings.transparentBackground) {
      ctx.fillStyle = settings.bgColor || '#000000';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
    }

    // Draw every packed frame onto the master sprite sheet
    for (const pf of packedFrames) {
      const animFrames = framesByAnim[pf.animationId];
      const frameCanvas = document.createElement('canvas');
      frameCanvas.width = cellSize;
      frameCanvas.height = cellSize;
      const fCtx = frameCanvas.getContext('2d');
      if (fCtx) {
        renderWispFrame(
          fCtx,
          pf.animationId,
          pf.frameIndex,
          animFrames.length,
          customization,
          cellSize
        );
        ctx.drawImage(frameCanvas, pf.x, pf.y);
      }
    }
  }

  const jsonObject = buildAtlasJsonObject(
    packedFrames,
    animList.map((a) => a.id),
    canvas.width,
    canvas.height,
    settings,
    customization
  );

  const jsonString = JSON.stringify(jsonObject, null, 2);

  return {
    canvas,
    width: canvas.width,
    height: canvas.height,
    packedFrames,
    jsonString,
    jsonObject,
  };
}

function createPackedRect(
  f: FrameData,
  x: number,
  y: number,
  cellSize: number,
  scaleFactor: number
): PackedFrameRect {
  return {
    frameKey: `${f.name}.png`,
    animationId: f.animationId,
    frameIndex: f.index,
    x,
    y,
    w: cellSize,
    h: cellSize,
    durationMs: f.durationMs,
    pivot: { x: Number(f.pivot.x.toFixed(3)), y: Number(f.pivot.y.toFixed(3)) },
    hurtbox: {
      x: Math.round(f.hurtbox.x * scaleFactor),
      y: Math.round(f.hurtbox.y * scaleFactor),
      w: Math.round(f.hurtbox.w * scaleFactor),
      h: Math.round(f.hurtbox.h * scaleFactor),
    },
    hitbox: f.hitbox
      ? {
          x: Math.round(f.hitbox.x * scaleFactor),
          y: Math.round(f.hitbox.y * scaleFactor),
          w: Math.round(f.hitbox.w * scaleFactor),
          h: Math.round(f.hitbox.h * scaleFactor),
        }
      : null,
    castSocket: {
      x: Math.round(f.castSocket.x * scaleFactor),
      y: Math.round(f.castSocket.y * scaleFactor),
    },
  };
}

function buildAtlasJsonObject(
  packedFrames: PackedFrameRect[],
  includedAnimIds: AnimationId[],
  sheetWidth: number,
  sheetHeight: number,
  settings: AtlasSettings,
  customization: CharacterCustomization
): Record<string, unknown> {
  const imageFileName = `${settings.projectName}.png`;

  // Build frameTags for animations
  const frameTags: Array<{
    name: string;
    from: number;
    to: number;
    direction: string;
    fps: number;
  }> = [];

  for (const animId of includedAnimIds) {
    const indices = packedFrames
      .map((pf, idx) => (pf.animationId === animId ? idx : -1))
      .filter((i) => i !== -1);
    if (indices.length > 0) {
      const cfg = ANIMATION_CONFIGS.find((a) => a.id === animId)!;
      frameTags.push({
        name: cfg.label,
        from: indices[0],
        to: indices[indices.length - 1],
        direction: cfg.loopMode === 'ping-pong' ? 'pingpong' : 'forward',
        fps: cfg.fps,
      });
    }
  }

  if (settings.format === 'phaser-hash') {
    const framesHash: Record<string, unknown> = {};
    const animationsMap: Record<string, string[]> = {};

    for (const pf of packedFrames) {
      framesHash[pf.frameKey] = {
        frame: { x: pf.x, y: pf.y, w: pf.w, h: pf.h },
        rotated: false,
        trimmed: false,
        spriteSourceSize: { x: 0, y: 0, w: pf.w, h: pf.h },
        sourceSize: { w: pf.w, h: pf.h },
        pivot: pf.pivot,
        duration: pf.durationMs,
        hurtbox: pf.hurtbox,
        hitbox: pf.hitbox,
        castSocket: pf.castSocket,
      };
      const cfg = ANIMATION_CONFIGS.find((a) => a.id === pf.animationId)!;
      if (!animationsMap[cfg.label]) {
        animationsMap[cfg.label] = [];
      }
      animationsMap[cfg.label].push(pf.frameKey);
    }

    return {
      frames: framesHash,
      animations: animationsMap,
      meta: {
        app: 'ELEMENTAL REALMS Art & Sprite Studio',
        version: '2.4.0',
        image: imageFileName,
        format: 'RGBA8888',
        size: { w: sheetWidth, h: sheetHeight },
        scale: '1',
        characterPreset: customization.paletteId,
        renderStyle: customization.renderStyle,
        frameTags,
      },
    };
  }

  if (settings.format === 'texturepacker-array') {
    return {
      frames: packedFrames.map((pf) => ({
        filename: pf.frameKey,
        frame: { x: pf.x, y: pf.y, w: pf.w, h: pf.h },
        rotated: false,
        trimmed: false,
        spriteSourceSize: { x: 0, y: 0, w: pf.w, h: pf.h },
        sourceSize: { w: pf.w, h: pf.h },
        pivot: pf.pivot,
        duration: pf.durationMs,
      })),
      meta: {
        app: 'https://www.codeandweb.com/texturepacker',
        version: '1.0',
        image: imageFileName,
        format: 'RGBA8888',
        size: { w: sheetWidth, h: sheetHeight },
        scale: '1',
        smartupdate: `$ElementalRealms:${Date.now()}$`,
        frameTags,
      },
    };
  }

  if (settings.format === 'aseprite') {
    const framesObj: Record<string, unknown> = {};
    packedFrames.forEach((pf) => {
      framesObj[pf.frameKey] = {
        frame: { x: pf.x, y: pf.y, w: pf.w, h: pf.h },
        rotated: false,
        trimmed: false,
        spriteSourceSize: { x: 0, y: 0, w: pf.w, h: pf.h },
        sourceSize: { w: pf.w, h: pf.h },
        duration: pf.durationMs,
      };
    });

    return {
      frames: framesObj,
      meta: {
        app: 'http://www.aseprite.org/',
        version: '1.3-rc6',
        image: imageFileName,
        format: 'RGBA8888',
        size: { w: sheetWidth, h: sheetHeight },
        scale: '1',
        frameTags,
        slices: [
          {
            name: 'hurtbox',
            color: '#10b981ff',
            keys: packedFrames.map((pf, idx) => ({
              frame: idx,
              bounds: pf.hurtbox,
              pivot: {
                x: Math.round(pf.pivot.x * pf.w),
                y: Math.round(pf.pivot.y * pf.h),
              },
            })),
          },
          {
            name: 'cast_socket',
            color: '#38bdf8ff',
            keys: packedFrames.map((pf, idx) => ({
              frame: idx,
              bounds: { x: pf.castSocket.x, y: pf.castSocket.y, w: 4, h: 4 },
            })),
          },
        ],
      },
    };
  }

  // Unity / Godot / Custom Game Engine JSON
  return {
    texture: imageFileName,
    dimensions: { width: sheetWidth, height: sheetHeight },
    cellSize: { width: settings.frameSize, height: settings.frameSize },
    character: {
      id: settings.projectName,
      skin: customization.paletteId,
      prop: customization.propType,
      style: customization.renderStyle,
    },
    clips: includedAnimIds.map((animId) => {
      const cfg = ANIMATION_CONFIGS.find((a) => a.id === animId)!;
      const clipFrames = packedFrames.filter((pf) => pf.animationId === animId);
      return {
        name: cfg.label,
        fps: cfg.fps,
        loop: cfg.loopMode !== 'once',
        loopMode: cfg.loopMode,
        frames: clipFrames.map((pf) => ({
          name: pf.frameKey,
          rect: { x: pf.x, y: pf.y, width: pf.w, height: pf.h },
          pivot: pf.pivot,
          durationMs: pf.durationMs,
          hurtbox: pf.hurtbox,
          hitbox: pf.hitbox,
          castSocket: pf.castSocket,
        })),
      };
    }),
  };
}


/** Convert an imported image into a clean, game-ready single-frame asset.
 * Pixel modes use nearest-neighbour scaling plus palette quantisation; this is a
 * deterministic local image-processing workflow, not a remote generative-AI call.
 */
export function generateImportedImageAsset(
  image: HTMLImageElement,
  settings: AtlasSettings,
  customization: CharacterCustomization
): { canvas: HTMLCanvasElement; jsonString: string } {
  const size = settings.frameSize;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (!ctx) throw new Error('Unable to create artwork canvas.');

  const transparent = settings.transparentBackground;
  const bg = settings.bgColor || '#000000';
  const pixelMode = customization.renderStyle === 'pixel-art-64' || customization.renderStyle === 'pixel-art-32';
  const workingSize = customization.renderStyle === 'pixel-art-32' ? 32 : customization.renderStyle === 'pixel-art-64' ? 64 : size;
  const working = document.createElement('canvas');
  working.width = workingSize;
  working.height = workingSize;
  const wctx = working.getContext('2d', { willReadFrequently: true });
  if (!wctx) throw new Error('Unable to create image processing canvas.');

  const aspect = image.naturalWidth / Math.max(1, image.naturalHeight);
  const maxSide = workingSize * 0.88;
  const drawW = aspect >= 1 ? maxSide : maxSide * aspect;
  const drawH = aspect >= 1 ? maxSide / aspect : maxSide;
  if (!transparent) {
    wctx.fillStyle = bg;
    wctx.fillRect(0, 0, workingSize, workingSize);
  }
  // Keep the complete source image visible and preserve its aspect ratio.
  wctx.imageSmoothingEnabled = !pixelMode;
  wctx.imageSmoothingQuality = 'high';
  wctx.drawImage(image, (workingSize - drawW) / 2, (workingSize - drawH) / 2, drawW, drawH);

  // Reduce the colour count to create a more deliberate pixel-art palette.
  // Alpha is preserved so transparent character edges remain clean.
  if (pixelMode || customization.renderStyle === 'cel-shaded') {
    const frame = wctx.getImageData(0, 0, workingSize, workingSize);
    const data = frame.data;
    const levels = customization.renderStyle === 'cel-shaded' ? 5 : 6;
    const step = 255 / (levels - 1);
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] === 0) continue;
      data[i] = Math.round(Math.round(data[i] / step) * step);
      data[i + 1] = Math.round(Math.round(data[i + 1] / step) * step);
      data[i + 2] = Math.round(Math.round(data[i + 2] / step) * step);
    }
    wctx.putImageData(frame, 0, 0);
  }

  ctx.clearRect(0, 0, size, size);
  if (!transparent) {
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, size, size);
  }
  ctx.imageSmoothingEnabled = !pixelMode;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(working, 0, 0, size, size);

  const elementByPalette: Record<string, string> = {
    'solaris-archon': 'fire',
    'frostborne-seer': 'water',
    'sylvan-oracle': 'leaf',
    'stormcaller-volt': 'lightning',
    'voidweaver-echo': 'chaos',
    'astral-sanctum': 'light',
    'terracore-warden': 'earth',
  };
  const json = {
    schema: 'elemental-realms.asset.v1',
    game: 'ELEMENTAL REALMS',
    assetName: settings.projectName,
    assetType: 'image',
    element: elementByPalette[customization.paletteId] || 'custom',
    image: `${settings.projectName}.png`,
    imageFormat: 'PNG',
    width: size,
    height: size,
    transparentBackground: transparent,
    backgroundColor: transparent ? null : bg,
    renderStyle: customization.renderStyle,
    processing: {
      method: pixelMode ? 'nearest-neighbour-pixelation-with-colour-quantisation' : customization.renderStyle === 'cel-shaded' ? 'cel-shading-colour-quantisation' : 'high-quality-resize',
      workingResolution: workingSize,
      outputResolution: size,
      sourceAspectRatioPreserved: true,
    },
    sourceImage: { width: image.naturalWidth || image.width, height: image.naturalHeight || image.height },
    origin: { x: 0.5, y: 0.78 },
    animation: { type: 'static-frame', frame: 0, fps: 0, loop: false },
    notes: 'Single-frame artwork export. This sidecar describes the PNG; it does not invent animation frames.',
  };
  return { canvas, jsonString: JSON.stringify(json, null, 2) };
}

export function downloadCanvasAsPng(canvas: HTMLCanvasElement, filename: string): void {
  const dataUrl = canvas.toDataURL('image/png');
  const link = document.createElement('a');
  link.download = filename.endsWith('.png') ? filename : `${filename}.png`;
  link.href = dataUrl;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function downloadJsonString(jsonString: string, filename: string): void {
  const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.download = filename.endsWith('.json') ? filename : `${filename}.json`;
  link.href = url;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

import {
  AnimationId,
  CharacterCustomization,
  FrameData,
  WispPalette,
} from '../types/sprite';
import { WISP_PALETTES } from '../data/presets';

export interface RenderOptions {
  showHurtbox?: boolean;
  showHitbox?: boolean;
  showPivot?: boolean;
  showCastSocket?: boolean;
  alphaOverride?: number;
  tintColor?: string | null;
}

export function getActivePalette(customization: CharacterCustomization): WispPalette {
  if (customization.customPalette) {
    return customization.customPalette;
  }
  return (
    WISP_PALETTES.find((p) => p.id === customization.paletteId) || WISP_PALETTES[0]
  );
}

/**
 * Renders a single frame of the Astral Wisp Mage onto the target 2D canvas context.
 * Native internal coordinate space is 256x256, cleanly scaled to targetSize.
 */
export function renderWispFrame(
  ctx: CanvasRenderingContext2D,
  animationId: AnimationId,
  frameIndex: number,
  totalFrames: number,
  customization: CharacterCustomization,
  targetSize: number = 256,
  frameMeta?: FrameData,
  options: RenderOptions = {}
): void {
  const palette = getActivePalette(customization);

  // If pixel-art mode is active, render to a low-res offscreen canvas first, then nearest-neighbor upscale
  if (
    customization.renderStyle === 'pixel-art-64' ||
    customization.renderStyle === 'pixel-art-32'
  ) {
    const pixelRes = customization.renderStyle === 'pixel-art-64' ? 64 : 32;
    const offCanvas = document.createElement('canvas');
    offCanvas.width = pixelRes;
    offCanvas.height = pixelRes;
    const offCtx = offCanvas.getContext('2d');
    if (offCtx) {
      renderInternal256(
        offCtx,
        animationId,
        frameIndex,
        totalFrames,
        customization,
        palette,
        pixelRes / 256
      );
      ctx.save();
      if (options.alphaOverride !== undefined) {
        ctx.globalAlpha = options.alphaOverride;
      }
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(offCanvas, 0, 0, pixelRes, pixelRes, 0, 0, targetSize, targetSize);
      ctx.restore();
    }
  } else {
    ctx.save();
    if (options.alphaOverride !== undefined) {
      ctx.globalAlpha = options.alphaOverride;
    }
    renderInternal256(
      ctx,
      animationId,
      frameIndex,
      totalFrames,
      customization,
      palette,
      targetSize / 256
    );
    ctx.restore();
  }

  // Optional debug overlays (hurtbox, hitbox, pivot, cast socket) rendered crisp at targetSize
  if (
    frameMeta &&
    (options.showHurtbox || options.showHitbox || options.showPivot || options.showCastSocket)
  ) {
    renderDebugOverlays(ctx, frameMeta, targetSize, options);
  }
}

function renderInternal256(
  ctx: CanvasRenderingContext2D,
  animationId: AnimationId,
  frameIndex: number,
  totalFrames: number,
  customization: CharacterCustomization,
  palette: WispPalette,
  scale: number
): void {
  ctx.save();
  ctx.scale(scale, scale);

  if (customization.flipX) {
    ctx.translate(256, 0);
    ctx.scale(-1, 1);
  }

  const t = totalFrames > 0 ? frameIndex / totalFrames : 0;
  const phase = t * Math.PI * 2;

  // If user uploaded a custom PNG and toggled "Animate Uploaded Image", deform & animate it
  if (customization.useUploadedImageAsBase && customization.customUploadedImage) {
    renderAnimatedCustomImage(
      ctx,
      customization.customUploadedImage,
      animationId,
      frameIndex,
      totalFrames,
      customization,
      palette
    );
    ctx.restore();
    return;
  }

  // Compute animation pose kinematics
  let offsetX = 0;
  let offsetY = 0;
  let bodyTilt = 0; // radians
  let hoodTilt = 0;
  let scaleX = 1;
  let scaleY = 1;
  let cloakFlare = 0;
  let eyeState: 'normal' | 'blink' | 'fierce' | 'cast' | 'hurt' | 'faded' = 'normal';
  let spellPower = 0;
  let slashPower = 0;
  let hitFlash = 0;
  let dissolveProgress = 0;

  if (animationId === 'idle') {
    offsetY = Math.sin(phase) * 6.5;
    offsetX = Math.cos(phase) * 1.5;
    bodyTilt = Math.sin(phase - 0.4) * 0.035;
    hoodTilt = Math.sin(phase - 0.8) * 0.025;
    cloakFlare = Math.sin(phase) * 0.12;
    if (frameIndex === totalFrames - 1) {
      eyeState = 'blink';
    }
  } else if (animationId === 'move') {
    offsetY = Math.sin(phase * 2) * 4.5 - 3;
    offsetX = 6 + Math.sin(phase) * 3;
    bodyTilt = 0.14 + Math.sin(phase) * 0.04;
    hoodTilt = 0.06 + Math.cos(phase) * 0.03;
    cloakFlare = 0.25 + Math.sin(phase) * 0.15;
    eyeState = 'fierce';
  } else if (animationId === 'cast') {
    const liftCurve = Math.sin(t * Math.PI);
    offsetY = -liftCurve * 14 + Math.sin(phase * 2) * 2;
    bodyTilt = -liftCurve * 0.06;
    cloakFlare = liftCurve * 0.65;
    spellPower = liftCurve;
    eyeState = 'cast';
    scaleX = 1 + liftCurve * 0.04;
    scaleY = 1 + liftCurve * 0.04;
  } else if (animationId === 'attack') {
    // Frames 0-1: anticipation pull back; Frames 2-4: forward lunge & slash; Frames 5-7: recovery
    if (t < 0.28) {
      const p = t / 0.28;
      offsetX = -p * 14;
      offsetY = p * 4;
      bodyTilt = -p * 0.18;
      cloakFlare = -0.1;
      eyeState = 'fierce';
    } else if (t < 0.68) {
      const p = (t - 0.28) / 0.4;
      offsetX = 18 * Math.sin(p * Math.PI * 0.8);
      offsetY = -6 * Math.sin(p * Math.PI);
      bodyTilt = 0.22 * (1 - p * 0.3);
      cloakFlare = 0.55 * (1 - p * 0.4);
      slashPower = Math.sin(p * Math.PI);
      eyeState = 'fierce';
    } else {
      const p = (t - 0.68) / 0.32;
      offsetX = 8 * (1 - p);
      bodyTilt = 0.08 * (1 - p);
      cloakFlare = 0.2 * (1 - p);
    }
  } else if (animationId === 'hit') {
    const decay = 1 - t;
    offsetX = -16 * decay + Math.sin(t * Math.PI * 6) * 4 * decay;
    offsetY = -5 * Math.sin(t * Math.PI);
    bodyTilt = -0.24 * decay;
    cloakFlare = 0.35 * decay;
    eyeState = 'hurt';
    hitFlash = t < 0.35 ? 0.75 : 0;
  } else if (animationId === 'defeat') {
    dissolveProgress = Math.min(1, t * 1.15);
    offsetY = dissolveProgress * 22;
    bodyTilt = -dissolveProgress * 0.16;
    scaleY = 1 - dissolveProgress * 0.32;
    scaleX = 1 + dissolveProgress * 0.08;
    eyeState = dissolveProgress > 0.4 ? 'faded' : 'hurt';
  }

  // Ground / hover ambient glow shadow
  drawHoverShadow(ctx, 134 + offsetX * 0.5, 236, 1 - offsetY / 45, palette, dissolveProgress);

  ctx.save();
  ctx.translate(132 + offsetX, 140 + offsetY);
  ctx.rotate(bodyTilt);
  ctx.scale(scaleX, scaleY);
  ctx.translate(-132, -140);

  if (dissolveProgress > 0) {
    ctx.globalAlpha *= Math.max(0.08, 1 - dissolveProgress * 0.88);
  }

  // 1. Background Aura FX
  if (customization.auraStyle !== 'none') {
    drawBackgroundAura(
      ctx,
      phase,
      palette,
      customization.auraStyle,
      customization.glowIntensity,
      spellPower
    );
  }

  // 2. Top Dark-to-Cyan Spectral Plume (Signature Reference Feature #1)
  drawTopSpectralPlume(
    ctx,
    phase,
    palette,
    customization.topPlumeScale,
    customization.outlineThickness,
    cloakFlare
  );

  // 3. Back-Left Bifurcated Spectral Streamer / Wisp Ribbon (Signature Reference Feature #2)
  drawBackLeftSpiritRibbon(
    ctx,
    phase,
    palette,
    customization.backRibbonScale,
    customization.outlineThickness,
    cloakFlare
  );

  // 4. Right-side (far) Cloak Sleeve Wing
  drawFarRightCloakWing(ctx, phase, palette, cloakFlare, customization.outlineThickness);

  // 5. Lower Ethereal Swirling Spirit Vortex Body (Signature Reference Feature #3)
  drawLowerSpiritBody(ctx, phase, palette, cloakFlare, customization.outlineThickness);

  // 6. Left-side (near) Draped White/Lavender Cloak & Gold Trim (Signature Reference Feature #4)
  drawNearLeftCloakWing(ctx, phase, palette, cloakFlare, customization.outlineThickness);

  // 7. Gold Shoulder Collar & Central Sapphire Diamond Brooch (Signature Reference Feature #5)
  drawGoldCollarAndBrooch(ctx, phase, palette, spellPower, customization.outlineThickness);

  // 8. Pointed White/Lavender Chibi Mage Hood + Beveled Gold Trim + Forehead Sapphire + Void Face & Glowing Cyan Eyes
  ctx.save();
  ctx.translate(148, 118);
  ctx.rotate(hoodTilt);
  ctx.translate(-148, -118);
  drawMageHoodAndFace(
    ctx,
    phase,
    palette,
    eyeState,
    spellPower,
    customization.browGemType,
    customization.outlineThickness,
    customization.glowIntensity
  );
  ctx.restore();

  // 9. Optional Equipped Mage Prop (Grimoire, Orb Staff, Arcane Runes, Soul Lantern)
  if (customization.propType !== 'none') {
    drawEquippedProp(ctx, phase, palette, customization.propType, spellPower, slashPower);
  }

  // 10. Active Spellcast or Spirit Slash Foreground FX
  if (spellPower > 0.05) {
    drawSpellcastCircleFX(ctx, phase, palette, spellPower);
  }
  if (slashPower > 0.05) {
    drawSpiritSlashFX(ctx, t, palette, slashPower);
  }

  // Hit recoil flash overlay
  if (hitFlash > 0) {
    drawHitSparkFX(ctx, phase, palette);
  }

  ctx.restore();

  // Defeat ascending spirit motes (drawn in world space so they rise even as cloak sinks)
  if (dissolveProgress > 0.05) {
    drawDissolveSoulMotes(ctx, dissolveProgress, palette);
  }

  ctx.restore();
}

function drawHoverShadow(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scaleFactor: number,
  palette: WispPalette,
  dissolve: number
): void {
  ctx.save();
  const rx = Math.max(18, 42 * scaleFactor * (1 - dissolve * 0.5));
  const ry = Math.max(5, 10 * scaleFactor * (1 - dissolve * 0.5));
  const grad = ctx.createRadialGradient(cx, cy, 2, cx, cy, rx);
  grad.addColorStop(0, hexWithAlpha(palette.wispMid, 0.35 * (1 - dissolve)));
  grad.addColorStop(0.5, hexWithAlpha(palette.wispOuter, 0.16 * (1 - dissolve)));
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

/**
 * 1. Top Dark-Navy to Cyan-Blue Curling Smoke/Spirit Plume emerging from top-back of the hood
 */
function drawTopSpectralPlume(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  plumeScale: number,
  outlineThickness: number,
  cloakFlare: number
): void {
  ctx.save();
  ctx.translate(132, 62);
  ctx.scale(plumeScale, plumeScale);
  ctx.rotate(-cloakFlare * 0.15);
  ctx.translate(-132, -62);

  const w1 = Math.sin(phase) * 6;
  const w2 = Math.cos(phase + 1.1) * 7;
  const w3 = Math.sin(phase + 2.3) * 5;

  // Outer glowing cyan-blue aura plume
  const outerGrad = ctx.createLinearGradient(64, 24, 148, 86);
  outerGrad.addColorStop(0, hexWithAlpha(palette.wispMid, 0.95));
  outerGrad.addColorStop(0.45, palette.wispOuter);
  outerGrad.addColorStop(0.85, palette.wispDarkPlume);
  outerGrad.addColorStop(1, palette.wispDarkPlume);

  ctx.fillStyle = outerGrad;
  ctx.beginPath();
  // Start at top-back of hood
  ctx.moveTo(148, 54);
  // Arch high over the top into a sweeping billow
  ctx.bezierCurveTo(136, 18 + w1 * 0.4, 96, 14 - w1 * 0.5, 76 + w1, 34 + w2 * 0.4);
  // Curl Tip #1 (top curl)
  ctx.bezierCurveTo(68 + w1, 42, 76 + w2, 48, 86, 45);
  // Dip into secondary left tendril (#2)
  ctx.bezierCurveTo(66 + w2, 50, 50 + w3, 66 + w1, 60 + w3, 82 + w2 * 0.5);
  // Curl of secondary tendril
  ctx.bezierCurveTo(68 + w3, 92, 84, 86, 90, 79);
  // Third lower curl (#3) near back of hood
  ctx.bezierCurveTo(72 + w1, 88, 66 + w2, 106, 84 + w1 * 0.5, 110);
  ctx.bezierCurveTo(96, 112, 112, 102, 126, 92);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.4 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // Inner dark abyssal smoke core (matches the deep black-navy core inside the top wisp in reference)
  const coreGrad = ctx.createLinearGradient(82, 34, 142, 88);
  coreGrad.addColorStop(0, hexWithAlpha(palette.wispOuter, 0.7));
  coreGrad.addColorStop(0.35, palette.wispDarkPlume);
  coreGrad.addColorStop(1, '#050814');

  ctx.fillStyle = coreGrad;
  ctx.beginPath();
  ctx.moveTo(140, 58);
  ctx.bezierCurveTo(128, 30 + w1 * 0.3, 98, 28 - w1 * 0.3, 86 + w1 * 0.6, 40);
  ctx.bezierCurveTo(96, 48, 80 + w2 * 0.5, 62, 74 + w3 * 0.5, 76);
  ctx.bezierCurveTo(88, 80, 92, 94, 118, 88);
  ctx.closePath();
  ctx.fill();

  // Bright cyan-white rim highlight along the top-right curve of the plume
  ctx.strokeStyle = hexWithAlpha(palette.wispCore, 0.85);
  ctx.lineWidth = 2.6;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(144, 52);
  ctx.bezierCurveTo(132, 22 + w1 * 0.4, 98, 18 - w1 * 0.4, 79 + w1, 33 + w2 * 0.3);
  ctx.stroke();

  ctx.restore();
}

/**
 * 2. Back-Left Bifurcated Spectral Streamer / Wisp Ribbon (flowing left from behind shoulder)
 */
function drawBackLeftSpiritRibbon(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  ribbonScale: number,
  outlineThickness: number,
  cloakFlare: number
): void {
  ctx.save();
  ctx.translate(108, 146);
  ctx.scale(ribbonScale, ribbonScale);
  ctx.rotate(cloakFlare * 0.18);
  ctx.translate(-108, -146);

  const waveA = Math.sin(phase - 0.5) * 8;
  const waveB = Math.cos(phase - 1.2) * 9;

  const ribbonGrad = ctx.createLinearGradient(22, 112, 114, 158);
  ribbonGrad.addColorStop(0, hexWithAlpha(palette.wispCore, 0.95));
  ribbonGrad.addColorStop(0.45, palette.wispMid);
  ribbonGrad.addColorStop(0.85, palette.wispOuter);
  ribbonGrad.addColorStop(1, palette.wispDarkPlume);

  ctx.fillStyle = ribbonGrad;
  ctx.beginPath();
  // Anchor behind left cloak shoulder
  ctx.moveTo(112, 138);
  // Upper edge sweeping left and upward into swallowtail fork #1
  ctx.bezierCurveTo(
    82,
    142 + waveA * 0.4,
    58,
    120 + waveA,
    38 + waveB * 0.4,
    104 + waveA * 0.7
  );
  // Upper fork tip curving back in
  ctx.bezierCurveTo(
    22 + waveB * 0.4,
    98 + waveA * 0.7,
    18 + waveB * 0.5,
    114 + waveA * 0.5,
    36 + waveB * 0.3,
    124 + waveA * 0.5
  );
  // Lower swallowtail fork #2 dipping down-left
  ctx.bezierCurveTo(
    24 + waveA * 0.4,
    130 + waveB * 0.5,
    24 + waveB * 0.4,
    152 + waveB * 0.6,
    42 + waveA * 0.3,
    156 + waveB * 0.4
  );
  // Return along bottom edge to lower cloak waist
  ctx.bezierCurveTo(
    36 + waveA * 0.3,
    144 + waveB * 0.3,
    52,
    136 + waveA * 0.4,
    68,
    148 + waveA * 0.3
  );
  ctx.bezierCurveTo(84, 158 + waveA * 0.2, 98, 160, 114, 154);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = hexWithAlpha(palette.outlineColor, 0.85);
    ctx.lineWidth = 2 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // Luminous inner energy vein along the streamer
  ctx.strokeStyle = hexWithAlpha(palette.wispCore, 0.9);
  ctx.lineWidth = 2.5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(104, 146);
  ctx.bezierCurveTo(78, 146 + waveA * 0.3, 56, 126 + waveA * 0.8, 34 + waveB * 0.3, 112 + waveA * 0.6);
  ctx.stroke();

  ctx.restore();
}

/**
 * 3. Far-Right Cloak Sleeve Wing
 */
function drawFarRightCloakWing(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  cloakFlare: number,
  outlineThickness: number
): void {
  ctx.save();
  const sway = Math.sin(phase + 0.6) * 3 + cloakFlare * 10;

  // Dark inner lining
  ctx.fillStyle = palette.robeDeepShadow;
  ctx.beginPath();
  ctx.moveTo(168, 134);
  ctx.quadraticCurveTo(196 + sway, 148, 204 + sway, 168);
  ctx.quadraticCurveTo(190 + sway * 0.6, 184, 168, 180);
  ctx.closePath();
  ctx.fill();

  // Outer white-lavender sleeve flap
  const flapGrad = ctx.createLinearGradient(168, 132, 206 + sway, 174);
  flapGrad.addColorStop(0, palette.robeLight);
  flapGrad.addColorStop(0.55, palette.robeMid);
  flapGrad.addColorStop(1, palette.robeShadow);

  ctx.fillStyle = flapGrad;
  ctx.beginPath();
  ctx.moveTo(170, 132);
  ctx.quadraticCurveTo(194 + sway, 144, 205 + sway, 164);
  ctx.lineTo(188 + sway * 0.7, 174);
  ctx.quadraticCurveTo(176, 160, 166, 148);
  ctx.closePath();
  ctx.fill();

  // Gold border along far-right sleeve hem
  ctx.strokeStyle = palette.trimBase;
  ctx.lineWidth = 4;
  ctx.lineJoin = 'round';
  ctx.beginPath();
  ctx.moveTo(176, 136);
  ctx.quadraticCurveTo(194 + sway, 146, 204 + sway, 164);
  ctx.lineTo(188 + sway * 0.7, 173);
  ctx.stroke();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.2 * outlineThickness;
    ctx.beginPath();
    ctx.moveTo(170, 132);
    ctx.quadraticCurveTo(196 + sway, 145, 206 + sway, 165);
    ctx.quadraticCurveTo(192 + sway * 0.7, 182, 170, 180);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * 4. Lower Ethereal Swirling Spirit Vortex Body (the glowing cyan-white torso & curled tail)
 */
function drawLowerSpiritBody(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  cloakFlare: number,
  outlineThickness: number
): void {
  ctx.save();
  const tailSwayX = Math.sin(phase - 0.9) * 8 - cloakFlare * 6;
  const tailSwayY = Math.cos(phase - 0.4) * 4;

  // Deep shadow backdrop under the cloak
  ctx.fillStyle = palette.robeDeepShadow;
  ctx.beginPath();
  ctx.moveTo(100, 152);
  ctx.quadraticCurveTo(84, 190, 96 + tailSwayX * 0.4, 214);
  ctx.quadraticCurveTo(126, 224, 156, 204);
  ctx.closePath();
  ctx.fill();

  // Main bioluminescent spirit vortex body
  const bodyGrad = ctx.createLinearGradient(152, 144, 118 + tailSwayX, 232 + tailSwayY);
  bodyGrad.addColorStop(0, '#FFFFFF');
  bodyGrad.addColorStop(0.28, palette.wispCore);
  bodyGrad.addColorStop(0.62, palette.wispMid);
  bodyGrad.addColorStop(0.88, palette.wispOuter);
  bodyGrad.addColorStop(1, palette.wispDarkPlume);

  ctx.fillStyle = bodyGrad;
  ctx.beginPath();
  // Start at upper chest under collar brooch
  ctx.moveTo(142, 144);
  ctx.lineTo(178, 146);
  // Right contour sweeping down into a round belly curve and curling left to a wisp tip
  ctx.bezierCurveTo(
    186,
    174,
    178,
    210 + tailSwayY * 0.5,
    152 + tailSwayX * 0.5,
    224 + tailSwayY
  );
  // Bottom curled spirit flame tip #1
  ctx.bezierCurveTo(
    134 + tailSwayX,
    233 + tailSwayY,
    112 + tailSwayX,
    226 + tailSwayY,
    118 + tailSwayX * 0.8,
    212 + tailSwayY * 0.5
  );
  // Inner curl notch
  ctx.bezierCurveTo(
    124 + tailSwayX * 0.6,
    218 + tailSwayY * 0.5,
    136 + tailSwayX * 0.5,
    216,
    140 + tailSwayX * 0.4,
    206
  );
  // Secondary wisp tongue on left side of tail
  ctx.bezierCurveTo(
    126 + tailSwayX * 0.5,
    214,
    110 + tailSwayX * 0.4,
    206,
    116 + tailSwayX * 0.3,
    192
  );
  ctx.bezierCurveTo(124, 180, 134, 164, 142, 144);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.2 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.stroke();
  }

  // Luminous internal white-cyan spirit swirl lines (gives that painted volumetric glow in reference)
  ctx.strokeStyle = hexWithAlpha('#FFFFFF', 0.85);
  ctx.lineWidth = 3.5;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(160, 154);
  ctx.bezierCurveTo(164, 178, 156, 202, 136 + tailSwayX * 0.6, 214 + tailSwayY * 0.6);
  ctx.stroke();

  ctx.strokeStyle = hexWithAlpha(palette.wispCore, 0.75);
  ctx.lineWidth = 2.2;
  ctx.beginPath();
  ctx.moveTo(148, 160);
  ctx.bezierCurveTo(146, 180, 138, 194, 124 + tailSwayX * 0.4, 200);
  ctx.stroke();

  ctx.restore();
}

/**
 * 5. Near-Left Draped White/Lavender Cloak Mantle & Ornate Gold Trim
 */
function drawNearLeftCloakWing(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  cloakFlare: number,
  outlineThickness: number
): void {
  ctx.save();
  const sway = -Math.sin(phase) * 4 - cloakFlare * 14;

  // Deep violet-indigo under-cloak fold
  ctx.fillStyle = palette.robeDeepShadow;
  ctx.beginPath();
  ctx.moveTo(96 + sway * 0.6, 186);
  ctx.quadraticCurveTo(82 + sway, 204, 92 + sway * 0.8, 214);
  ctx.quadraticCurveTo(112 + sway * 0.5, 210, 124, 194);
  ctx.closePath();
  ctx.fill();

  // Main left cloak body (pearlescent white top -> lavender shadow)
  const cloakGrad = ctx.createLinearGradient(96 + sway, 138, 146, 198);
  cloakGrad.addColorStop(0, palette.robeLight);
  cloakGrad.addColorStop(0.5, palette.robeMid);
  cloakGrad.addColorStop(1, palette.robeShadow);

  ctx.fillStyle = cloakGrad;
  ctx.beginPath();
  ctx.moveTo(122, 136);
  ctx.bezierCurveTo(102, 148, 86 + sway, 168, 80 + sway, 192);
  ctx.quadraticCurveTo(96 + sway * 0.8, 186, 114 + sway * 0.5, 192);
  ctx.quadraticCurveTo(132 + sway * 0.3, 186, 148, 150);
  ctx.closePath();
  ctx.fill();

  // Soft cel/painted lavender fold shadow inside the cloak
  ctx.fillStyle = hexWithAlpha(palette.robeShadow, 0.55);
  ctx.beginPath();
  ctx.moveTo(126, 144);
  ctx.quadraticCurveTo(106 + sway * 0.5, 168, 96 + sway * 0.7, 186);
  ctx.lineTo(116 + sway * 0.5, 190);
  ctx.quadraticCurveTo(130, 170, 142, 148);
  ctx.closePath();
  ctx.fill();

  // Thick Beveled Gold Trim along the front & bottom edge of the left cloak
  const goldGrad = ctx.createLinearGradient(84 + sway, 144, 148, 194);
  goldGrad.addColorStop(0, palette.trimHighlight);
  goldGrad.addColorStop(0.5, palette.trimBase);
  goldGrad.addColorStop(1, palette.trimShadow);

  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  ctx.moveTo(142, 144);
  ctx.lineTo(150, 148);
  ctx.quadraticCurveTo(136 + sway * 0.3, 188, 116 + sway * 0.5, 195);
  ctx.quadraticCurveTo(96 + sway * 0.8, 190, 80 + sway, 194);
  ctx.lineTo(83 + sway, 184);
  ctx.quadraticCurveTo(98 + sway * 0.7, 181, 114 + sway * 0.5, 185);
  ctx.quadraticCurveTo(128 + sway * 0.3, 174, 142, 144);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.3 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(122, 136);
    ctx.bezierCurveTo(102, 148, 86 + sway, 168, 80 + sway, 192);
    ctx.quadraticCurveTo(96 + sway * 0.8, 188, 116 + sway * 0.5, 195);
    ctx.quadraticCurveTo(136 + sway * 0.3, 186, 150, 148);
    ctx.stroke();
  }

  ctx.restore();
}

/**
 * 6. Segmented Gold Shoulder Collar & Central Diamond Sapphire Brooch
 */
function drawGoldCollarAndBrooch(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  spellPower: number,
  outlineThickness: number
): void {
  ctx.save();

  const goldGrad = ctx.createLinearGradient(116, 126, 190, 156);
  goldGrad.addColorStop(0, palette.trimHighlight);
  goldGrad.addColorStop(0.5, palette.trimBase);
  goldGrad.addColorStop(1, palette.trimShadow);

  // Left Gold Pauldron Plate
  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  ctx.moveTo(116, 134);
  ctx.lineTo(148, 136);
  ctx.lineTo(144, 150);
  ctx.lineTo(112, 144);
  ctx.closePath();
  ctx.fill();
  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2 * outlineThickness;
    ctx.stroke();
  }

  // Small blue gem inlay on left pauldron
  ctx.fillStyle = palette.gemMid;
  ctx.beginPath();
  ctx.moveTo(124, 138);
  ctx.lineTo(134, 139);
  ctx.lineTo(132, 145);
  ctx.lineTo(122, 143);
  ctx.closePath();
  ctx.fill();

  // Right Gold Pauldron Plate
  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  ctx.moveTo(172, 134);
  ctx.lineTo(192, 130);
  ctx.lineTo(196, 142);
  ctx.lineTo(174, 148);
  ctx.closePath();
  ctx.fill();
  if (outlineThickness > 0) {
    ctx.stroke();
  }

  // Central Diamond Gold Brooch Frame
  const bx = 162;
  const by = 146;
  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  ctx.moveTo(bx, by - 16);
  ctx.lineTo(bx + 15, by);
  ctx.lineTo(bx, by + 16);
  ctx.lineTo(bx - 15, by);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.2 * outlineThickness;
    ctx.stroke();
  }

  // Inner Faceted Sapphire Gem in Collar Brooch
  const gemGrad = ctx.createLinearGradient(bx - 8, by - 9, bx + 8, by + 9);
  gemGrad.addColorStop(0, palette.gemHighlight);
  gemGrad.addColorStop(0.45, palette.gemMid);
  gemGrad.addColorStop(1, palette.gemDeep);

  ctx.fillStyle = gemGrad;
  ctx.beginPath();
  ctx.moveTo(bx, by - 9);
  ctx.lineTo(bx + 8, by);
  ctx.lineTo(bx, by + 9);
  ctx.lineTo(bx - 8, by);
  ctx.closePath();
  ctx.fill();

  // Specular glint on collar gem
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(bx - 2, by - 3, 2.2 + spellPower * 2, 0, Math.PI * 2);
  ctx.fill();

  // Extra spell bloom on collar gem when casting
  if (spellPower > 0.05 || Math.sin(phase) > 0.7) {
    const glowR = 14 + spellPower * 16;
    const g = ctx.createRadialGradient(bx, by, 1, bx, by, glowR);
    g.addColorStop(0, hexWithAlpha(palette.eyeGlow, 0.55 + spellPower * 0.35));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(bx, by, glowR, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

/**
 * 7. Iconic Pointed Chibi Mage Hood + Ornate Beveled Gold Trim + Forehead Sapphire + Void Face & Glowing Cyan Eyes
 */
function drawMageHoodAndFace(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  eyeState: 'normal' | 'blink' | 'fierce' | 'cast' | 'hurt' | 'faded',
  spellPower: number,
  browGemType: CharacterCustomization['browGemType'],
  outlineThickness: number,
  glowIntensity: number
): void {
  ctx.save();

  // --- A. Outer Pointed Mage Hood Body (Pearlescent White -> Cool Lavender -> Indigo Underside) ---
  const hoodGrad = ctx.createLinearGradient(112, 48, 174, 138);
  hoodGrad.addColorStop(0, palette.robeLight);
  hoodGrad.addColorStop(0.52, palette.robeMid);
  hoodGrad.addColorStop(0.85, palette.robeShadow);
  hoodGrad.addColorStop(1, palette.robeDeepShadow);

  ctx.fillStyle = hoodGrad;
  ctx.beginPath();
  // Start at top peak of the hood
  ctx.moveTo(150, 46);
  // Sweep down-left along the straight-curved conical hood slope to the pointed left cheek corner
  ctx.bezierCurveTo(122, 50, 92, 80, 72, 108);
  // Sweep inward along the lower-left jaw fold of the hood
  ctx.bezierCurveTo(86, 126, 114, 138, 152, 138);
  // Sweep around the right side of the hood opening
  ctx.bezierCurveTo(188, 138, 212, 124, 220, 108);
  // Sweep up the right slope of the hood back to the apex
  ctx.bezierCurveTo(206, 82, 176, 48, 150, 46);
  ctx.closePath();
  ctx.fill();

  // Painted volumetric shading plane along lower-left hood cheek (matches reference's periwinkle-lavender shadow)
  ctx.fillStyle = hexWithAlpha(palette.robeShadow, 0.65);
  ctx.beginPath();
  ctx.moveTo(72, 108);
  ctx.quadraticCurveTo(104, 112, 124, 96);
  ctx.lineTo(138, 136);
  ctx.bezierCurveTo(110, 136, 86, 124, 72, 108);
  ctx.closePath();
  ctx.fill();

  // Crisp bright white specular highlight along upper-left hood dome
  ctx.fillStyle = hexWithAlpha('#FFFFFF', 0.85);
  ctx.beginPath();
  ctx.moveTo(146, 50);
  ctx.bezierCurveTo(124, 56, 98, 82, 82, 104);
  ctx.quadraticCurveTo(108, 88, 148, 58);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2.5 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(150, 46);
    ctx.bezierCurveTo(122, 50, 92, 80, 72, 108);
    ctx.bezierCurveTo(86, 126, 114, 138, 152, 138);
    ctx.bezierCurveTo(188, 138, 212, 124, 220, 108);
    ctx.bezierCurveTo(206, 82, 176, 48, 150, 46);
    ctx.stroke();
  }

  // --- B. Abyssal Void Face Cavity Inside the Hood ---
  const voidGrad = ctx.createLinearGradient(166, 78, 166, 134);
  voidGrad.addColorStop(0, palette.faceVoidTop);
  voidGrad.addColorStop(0.75, palette.faceVoidBottom);
  voidGrad.addColorStop(1, hexWithAlpha(palette.wispMid, 0.35));

  ctx.fillStyle = voidGrad;
  ctx.beginPath();
  ctx.moveTo(164, 76);
  ctx.bezierCurveTo(140, 86, 122, 102, 118, 112);
  ctx.bezierCurveTo(124, 128, 148, 134, 172, 134);
  ctx.bezierCurveTo(194, 134, 208, 122, 212, 110);
  ctx.bezierCurveTo(204, 96, 186, 84, 164, 76);
  ctx.closePath();
  ctx.fill();

  // Crisp glowing white-cyan chin rim reflection at bottom of void face (distinctive detail in reference!)
  ctx.strokeStyle = hexWithAlpha('#FFFFFF', 0.9);
  ctx.lineWidth = 2.8;
  ctx.lineCap = 'round';
  ctx.beginPath();
  ctx.moveTo(138, 129);
  ctx.quadraticCurveTo(168, 136, 196, 126);
  ctx.stroke();

  // --- C. Ornate Beveled Gold Hood Trim (with signature cheek notches!) ---
  const goldGrad = ctx.createLinearGradient(112, 56, 214, 134);
  goldGrad.addColorStop(0, palette.trimHighlight);
  goldGrad.addColorStop(0.45, palette.trimBase);
  goldGrad.addColorStop(0.85, palette.trimShadow);
  goldGrad.addColorStop(1, palette.trimDark);

  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  // Outer edge of gold hood trim starting from forehead apex
  ctx.moveTo(162, 54);
  // Left brow slope with angular fantasy step/notch (exactly like reference)
  ctx.lineTo(134, 82);
  ctx.lineTo(124, 79); // outer notch step
  ctx.lineTo(106, 98);
  ctx.lineTo(116, 116);
  // Bottom gold chin band
  ctx.quadraticCurveTo(148, 138, 186, 133);
  // Right cheek corner
  ctx.lineTo(220, 110);
  ctx.lineTo(204, 88);
  ctx.lineTo(196, 90);
  ctx.lineTo(162, 54);
  ctx.closePath();

  // Cut out inner face opening so the void face shows inside
  ctx.moveTo(164, 78);
  ctx.lineTo(198, 104);
  ctx.lineTo(208, 110);
  ctx.quadraticCurveTo(196, 128, 170, 131);
  ctx.quadraticCurveTo(142, 131, 124, 114);
  ctx.lineTo(118, 102);
  ctx.lineTo(134, 92);
  ctx.lineTo(164, 78);
  ctx.closePath();
  ctx.fill('evenodd');

  // Crisp gold bevel highlight lines
  ctx.strokeStyle = palette.trimHighlight;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(158, 60);
  ctx.lineTo(134, 84);
  ctx.lineTo(125, 82);
  ctx.lineTo(110, 98);
  ctx.stroke();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2 * outlineThickness;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    ctx.moveTo(162, 54);
    ctx.lineTo(134, 82);
    ctx.lineTo(124, 79);
    ctx.lineTo(106, 98);
    ctx.lineTo(116, 116);
    ctx.quadraticCurveTo(148, 138, 186, 133);
    ctx.lineTo(220, 110);
    ctx.lineTo(204, 88);
    ctx.lineTo(162, 54);
    ctx.stroke();
  }

  // --- D. Forehead Diamond Sapphire Crest (Signature Reference Feature #6) ---
  drawForeheadCrest(ctx, 162, 68, palette, browGemType, spellPower, outlineThickness);

  // --- E. Glowing Cyan Oval Eyes Inside Void Face ---
  drawGlowingEyes(ctx, phase, palette, eyeState, spellPower, glowIntensity);

  ctx.restore();
}

function drawForeheadCrest(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  palette: WispPalette,
  browGemType: CharacterCustomization['browGemType'],
  spellPower: number,
  outlineThickness: number
): void {
  if (browGemType === 'minimal-gold') {
    return;
  }

  ctx.save();

  // Outer gold bezel diamond
  const goldGrad = ctx.createLinearGradient(cx - 18, cy - 18, cx + 18, cy + 18);
  goldGrad.addColorStop(0, palette.trimHighlight);
  goldGrad.addColorStop(0.5, palette.trimBase);
  goldGrad.addColorStop(1, palette.trimShadow);

  ctx.fillStyle = goldGrad;
  ctx.beginPath();
  ctx.moveTo(cx - 2, cy - 20);
  ctx.lineTo(cx + 20, cy + 2);
  ctx.lineTo(cx + 2, cy + 20);
  ctx.lineTo(cx - 20, cy - 2);
  ctx.closePath();
  ctx.fill();

  if (outlineThickness > 0) {
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2 * outlineThickness;
    ctx.stroke();
  }

  // Faceted Sapphire Gem inside bezel
  const gemGrad = ctx.createLinearGradient(cx - 12, cy - 12, cx + 12, cy + 12);
  gemGrad.addColorStop(0, palette.gemHighlight);
  gemGrad.addColorStop(0.45, palette.gemMid);
  gemGrad.addColorStop(1, palette.gemDeep);

  ctx.fillStyle = gemGrad;
  ctx.beginPath();
  ctx.moveTo(cx - 1, cy - 12);
  ctx.lineTo(cx + 12, cy + 1);
  ctx.lineTo(cx + 1, cy + 12);
  ctx.lineTo(cx - 12, cy - 1);
  ctx.closePath();
  ctx.fill();

  // Inner bright crystal facet
  ctx.fillStyle = hexWithAlpha(palette.gemHighlight, 0.85);
  ctx.beginPath();
  ctx.moveTo(cx - 1, cy - 10);
  ctx.lineTo(cx + 5, cy - 1);
  ctx.lineTo(cx - 1, cy + 2);
  ctx.lineTo(cx - 8, cy - 1);
  ctx.closePath();
  ctx.fill();

  // Pure white star glint
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  ctx.arc(cx - 3, cy - 4, 2.5 + spellPower * 2, 0, Math.PI * 2);
  ctx.fill();

  // Optional Astral Halo or Trinity Crest upgrade
  if (browGemType === 'astral-halo') {
    ctx.strokeStyle = hexWithAlpha(palette.wispCore, 0.9);
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.ellipse(cx - 4, cy - 28, 28, 8, -0.15, 0, Math.PI * 2);
    ctx.stroke();
  } else if (browGemType === 'trinity-crest') {
    for (const dx of [-18, 18]) {
      ctx.fillStyle = palette.gemMid;
      ctx.beginPath();
      ctx.arc(cx + dx, cy + 4, 4.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  ctx.restore();
}

function drawGlowingEyes(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  eyeState: 'normal' | 'blink' | 'fierce' | 'cast' | 'hurt' | 'faded',
  spellPower: number,
  glowIntensity: number
): void {
  ctx.save();

  const leftEye = { x: 155, y: 108, rx: 7.5, ry: 11.5 };
  const rightEye = { x: 185, y: 107, rx: 6.8, ry: 11.0 };
  const pulse = 1 + Math.sin(phase * 2) * 0.06 + spellPower * 0.25;

  for (const [idx, eye] of [leftEye, rightEye].entries()) {
    ctx.save();
    ctx.translate(eye.x, eye.y);

    // Outer cyan bloom
    if (glowIntensity > 0 && eyeState !== 'faded') {
      const bloomRadius = 18 * pulse * glowIntensity;
      const bloom = ctx.createRadialGradient(0, 0, 2, 0, 0, bloomRadius);
      bloom.addColorStop(0, hexWithAlpha(palette.eyeGlow, 0.85));
      bloom.addColorStop(0.5, hexWithAlpha(palette.eyeGlow, 0.35));
      bloom.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = bloom;
      ctx.beginPath();
      ctx.arc(0, 0, bloomRadius, 0, Math.PI * 2);
      ctx.fill();
    }

    if (eyeState === 'blink') {
      ctx.strokeStyle = palette.eyeCore;
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(-eye.rx, 1);
      ctx.quadraticCurveTo(0, 4, eye.rx, 1);
      ctx.stroke();
    } else if (eyeState === 'hurt') {
      // Wincing > < eyes
      ctx.strokeStyle = palette.eyeCore;
      ctx.lineWidth = 3.2;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.beginPath();
      if (idx === 0) {
        ctx.moveTo(-6, -5);
        ctx.lineTo(5, 0);
        ctx.lineTo(-6, 5);
      } else {
        ctx.moveTo(6, -5);
        ctx.lineTo(-5, 0);
        ctx.lineTo(6, 5);
      }
      ctx.stroke();
    } else if (eyeState === 'faded') {
      ctx.fillStyle = hexWithAlpha(palette.eyeGlow, 0.35);
      ctx.beginPath();
      ctx.ellipse(0, 2, eye.rx * 0.7, eye.ry * 0.3, 0, 0, Math.PI * 2);
      ctx.fill();
    } else {
      // Normal, Fierce, or Cast glowing oval eyes (matching reference!)
      ctx.fillStyle = palette.eyeGlow;
      ctx.beginPath();
      ctx.ellipse(0, 0, (eye.rx + 1.8) * pulse, (eye.ry + 1.8) * pulse, 0.08, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = palette.eyeCore;
      ctx.beginPath();
      ctx.ellipse(0, 0, eye.rx * pulse, eye.ry * pulse, 0.08, 0, Math.PI * 2);
      ctx.fill();

      // If fierce (move / attack), cut an angled upper brow shadow across the top of the eyes
      if (eyeState === 'fierce') {
        ctx.fillStyle = palette.faceVoidTop;
        ctx.beginPath();
        if (idx === 0) {
          ctx.moveTo(-12, -14);
          ctx.lineTo(12, -4);
          ctx.lineTo(12, -16);
        } else {
          ctx.moveTo(12, -14);
          ctx.lineTo(-12, -4);
          ctx.lineTo(-12, -16);
        }
        ctx.closePath();
        ctx.fill();
      }
    }

    ctx.restore();
  }

  ctx.restore();
}

function drawBackgroundAura(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  auraStyle: CharacterCustomization['auraStyle'],
  glowIntensity: number,
  spellPower: number
): void {
  ctx.save();

  if (auraStyle === 'mana-motes') {
    const motes = [
      { bx: 58, by: 90, r: 3.2, speed: 1, offset: 0.2 },
      { bx: 214, by: 82, r: 2.8, speed: 1.2, offset: 1.8 },
      { bx: 68, by: 196, r: 3.6, speed: 1, offset: 3.1 },
      { bx: 198, by: 188, r: 2.5, speed: 1.4, offset: 4.5 },
      { bx: 112, by: 30, r: 2.4, speed: 1, offset: 5.2 },
    ];
    for (const m of motes) {
      const mx = m.bx + Math.cos(phase + m.offset) * 6;
      const my = m.by + Math.sin(phase + m.offset) * 10;
      const alpha = (0.45 + Math.sin(phase + m.offset) * 0.35) * Math.max(0.4, glowIntensity);
      ctx.fillStyle = hexWithAlpha(palette.wispCore, alpha);
      ctx.beginPath();
      ctx.arc(mx, my, m.r + spellPower * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (auraStyle === 'orbiting-runes') {
    ctx.strokeStyle = hexWithAlpha(palette.wispMid, 0.45 * Math.max(0.4, glowIntensity));
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(142, 142, 86, 26, -0.2, 0, Math.PI * 2);
    ctx.stroke();

    for (let i = 0; i < 4; i++) {
      const a = phase + (i * Math.PI) / 2;
      const rx = 142 + Math.cos(a) * 86;
      const ry = 142 + Math.sin(a) * 26;
      ctx.fillStyle = palette.wispCore;
      ctx.beginPath();
      ctx.moveTo(rx, ry - 6);
      ctx.lineTo(rx + 5, ry);
      ctx.lineTo(rx, ry + 6);
      ctx.lineTo(rx - 5, ry);
      ctx.closePath();
      ctx.fill();
    }
  } else if (auraStyle === 'spirit-flames') {
    const g = ctx.createRadialGradient(142, 136, 16, 142, 136, 98);
    g.addColorStop(0, hexWithAlpha(palette.wispMid, 0.35 * glowIntensity));
    g.addColorStop(0.6, hexWithAlpha(palette.wispOuter, 0.18 * glowIntensity));
    g.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(142, 136, 98, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

function drawEquippedProp(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  propType: CharacterCustomization['propType'],
  spellPower: number,
  slashPower: number
): void {
  ctx.save();
  const hoverY = Math.sin(phase + 0.9) * 5 - spellPower * 8;
  const hoverX = Math.cos(phase + 0.5) * 3 + slashPower * 12;

  if (propType === 'grimoire') {
    // Floating open astral spellbook in front-right
    const gx = 212 + hoverX;
    const gy = 148 + hoverY;
    ctx.translate(gx, gy);
    ctx.rotate(-0.18 + Math.sin(phase) * 0.08);

    // Gold cover
    ctx.fillStyle = palette.trimBase;
    ctx.beginPath();
    ctx.moveTo(-22, 6);
    ctx.lineTo(0, 14);
    ctx.lineTo(22, 4);
    ctx.lineTo(18, -12);
    ctx.lineTo(0, -4);
    ctx.lineTo(-18, -10);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = palette.outlineColor;
    ctx.lineWidth = 2;
    ctx.stroke();

    // Glowing parchment pages
    ctx.fillStyle = palette.robeLight;
    ctx.beginPath();
    ctx.moveTo(-19, 2);
    ctx.lineTo(0, 10);
    ctx.lineTo(19, 0);
    ctx.lineTo(15, -10);
    ctx.lineTo(0, -2);
    ctx.lineTo(-15, -8);
    ctx.closePath();
    ctx.fill();

    // Floating cyan rune above pages
    ctx.strokeStyle = palette.wispMid;
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(0, -14, 7 + spellPower * 5, 0, Math.PI * 2);
    ctx.stroke();
  } else if (propType === 'orb-staff') {
    const sx = 208 + hoverX;
    const sy = 144 + hoverY;
    ctx.translate(sx, sy);
    ctx.rotate(0.22 + slashPower * 0.45);

    // Gold staff shaft
    ctx.strokeStyle = palette.trimBase;
    ctx.lineWidth = 5;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(0, -46);
    ctx.lineTo(0, 46);
    ctx.stroke();

    // Crescent gold finial
    ctx.strokeStyle = palette.trimHighlight;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(0, -46, 13, 0.3, Math.PI * 1.65);
    ctx.stroke();

    // Glowing sapphire orb inside crescent
    const orbGrad = ctx.createRadialGradient(-2, -48, 1, 0, -46, 9);
    orbGrad.addColorStop(0, '#FFFFFF');
    orbGrad.addColorStop(0.5, palette.gemMid);
    orbGrad.addColorStop(1, palette.gemDeep);
    ctx.fillStyle = orbGrad;
    ctx.beginPath();
    ctx.arc(0, -46, 8 + spellPower * 3, 0, Math.PI * 2);
    ctx.fill();
  } else if (propType === 'arcane-runes') {
    for (let i = 0; i < 3; i++) {
      const angle = phase + (i * Math.PI * 2) / 3;
      const rx = 206 + Math.cos(angle) * 16;
      const ry = 136 + Math.sin(angle) * 22;
      ctx.fillStyle = palette.wispCore;
      ctx.strokeStyle = palette.wispMid;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(rx, ry, 6 + spellPower * 3, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  } else if (propType === 'soul-lantern') {
    const lx = 210 + hoverX;
    const ly = 138 + hoverY;
    ctx.strokeStyle = palette.trimBase;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(lx - 10, ly - 16);
    ctx.lineTo(lx, ly - 22);
    ctx.lineTo(lx + 4, ly - 8);
    ctx.stroke();

    // Lantern cage
    ctx.fillStyle = hexWithAlpha(palette.wispMid, 0.45);
    ctx.strokeStyle = palette.trimHighlight;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(lx - 9, ly - 8);
    ctx.lineTo(lx + 9, ly - 8);
    ctx.lineTo(lx + 6, ly + 14);
    ctx.lineTo(lx - 6, ly + 14);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();

    // Inner wisp flame
    ctx.fillStyle = '#FFFFFF';
    ctx.beginPath();
    ctx.arc(lx, ly + 3, 4.5, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.restore();
}

function drawSpellcastCircleFX(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette,
  spellPower: number
): void {
  ctx.save();
  const cx = 204;
  const cy = 124;
  ctx.translate(cx, cy);

  const radius = 26 * spellPower + 6;
  const grad = ctx.createRadialGradient(0, 0, 2, 0, 0, radius * 1.4);
  grad.addColorStop(0, hexWithAlpha('#FFFFFF', 0.9 * spellPower));
  grad.addColorStop(0.4, hexWithAlpha(palette.wispMid, 0.65 * spellPower));
  grad.addColorStop(1, 'rgba(0,0,0,0)');

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(0, 0, radius * 1.4, 0, Math.PI * 2);
  ctx.fill();

  // Rotating vertical arcane glyph ring
  ctx.scale(0.52, 1);
  ctx.rotate(phase * 2);
  ctx.strokeStyle = hexWithAlpha(palette.wispCore, 0.95 * spellPower);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.stroke();

  // Inner hexagram star inside magic circle
  ctx.strokeStyle = hexWithAlpha(palette.trimHighlight, 0.85 * spellPower);
  ctx.lineWidth = 2;
  for (let t = 0; t < 2; t++) {
    ctx.beginPath();
    for (let i = 0; i < 3; i++) {
      const a = (i * Math.PI * 2) / 3 + (t * Math.PI) / 3;
      const px = Math.cos(a) * (radius * 0.85);
      const py = Math.sin(a) * (radius * 0.85);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.stroke();
  }

  ctx.restore();
}

function drawSpiritSlashFX(
  ctx: CanvasRenderingContext2D,
  t: number,
  palette: WispPalette,
  slashPower: number
): void {
  ctx.save();
  const cx = 194 + t * 24;
  const cy = 126;

  const grad = ctx.createLinearGradient(cx - 30, cy - 58, cx + 48, cy + 58);
  grad.addColorStop(0, hexWithAlpha(palette.wispCore, 0));
  grad.addColorStop(0.5, hexWithAlpha('#FFFFFF', 0.95 * slashPower));
  grad.addColorStop(0.8, hexWithAlpha(palette.wispMid, 0.85 * slashPower));
  grad.addColorStop(1, hexWithAlpha(palette.wispOuter, 0));

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.moveTo(cx - 12, cy - 58);
  ctx.bezierCurveTo(cx + 46, cy - 28, cx + 52, cy + 28, cx - 8, cy + 60);
  ctx.bezierCurveTo(cx + 22, cy + 20, cx + 18, cy - 20, cx - 12, cy - 58);
  ctx.closePath();
  ctx.fill();

  ctx.restore();
}

function drawHitSparkFX(
  ctx: CanvasRenderingContext2D,
  phase: number,
  palette: WispPalette
): void {
  ctx.save();
  ctx.strokeStyle = '#FFFFFF';
  ctx.lineWidth = 3;
  for (let i = 0; i < 6; i++) {
    const a = (i * Math.PI) / 3 + phase * 0.3;
    const r1 = 36;
    const r2 = 58;
    ctx.beginPath();
    ctx.moveTo(156 + Math.cos(a) * r1, 120 + Math.sin(a) * r1);
    ctx.lineTo(156 + Math.cos(a) * r2, 120 + Math.sin(a) * r2);
    ctx.stroke();
  }
  ctx.strokeStyle = palette.wispCore;
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(156, 120, 44, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
}

function drawDissolveSoulMotes(
  ctx: CanvasRenderingContext2D,
  progress: number,
  palette: WispPalette
): void {
  ctx.save();
  const seeds = [
    { x: 105, y: 170, r: 5 },
    { x: 135, y: 150, r: 6.5 },
    { x: 165, y: 165, r: 4.5 },
    { x: 120, y: 130, r: 5.5 },
    { x: 152, y: 115, r: 7 },
    { x: 180, y: 140, r: 4 },
    { x: 140, y: 185, r: 5 },
  ];
  for (const [idx, s] of seeds.entries()) {
    const py = s.y - progress * (55 + idx * 12);
    const px = s.x + Math.sin(progress * 5 + idx) * 14;
    const alpha = Math.sin(progress * Math.PI);
    const r = s.r * (1 - progress * 0.5);
    ctx.fillStyle = hexWithAlpha(palette.wispCore, alpha);
    ctx.beginPath();
    ctx.arc(px, py, Math.max(1, r), 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function renderAnimatedCustomImage(
  ctx: CanvasRenderingContext2D,
  img: HTMLImageElement,
  animationId: AnimationId,
  frameIndex: number,
  totalFrames: number,
  customization: CharacterCustomization,
  palette: WispPalette
): void {
  const t = totalFrames > 0 ? frameIndex / totalFrames : 0;
  const phase = t * Math.PI * 2;

  let dx = 0;
  let dy = 0;
  let rot = 0;
  let sx = 1;
  let sy = 1;

  if (animationId === 'idle') {
    dy = Math.sin(phase) * 7;
    sx = 1 + Math.sin(phase) * 0.025;
    sy = 1 - Math.sin(phase) * 0.025;
    rot = Math.sin(phase - 0.5) * 0.03;
  } else if (animationId === 'move') {
    dx = 6 + Math.sin(phase) * 4;
    dy = Math.sin(phase * 2) * 5;
    rot = 0.12 + Math.sin(phase) * 0.04;
  } else if (animationId === 'cast') {
    const lift = Math.sin(t * Math.PI);
    dy = -lift * 14;
    sx = 1 + lift * 0.06;
    sy = 1 + lift * 0.06;
    drawSpellcastCircleFX(ctx, phase, palette, lift);
  } else if (animationId === 'attack') {
    const lunge = Math.sin(t * Math.PI);
    dx = lunge * 18;
    rot = lunge * 0.18;
    drawSpiritSlashFX(ctx, t, palette, lunge);
  } else if (animationId === 'hit') {
    dx = -14 * (1 - t);
    rot = -0.2 * (1 - t);
  } else if (animationId === 'defeat') {
    dy = t * 24;
    sy = 1 - t * 0.4;
    ctx.globalAlpha = Math.max(0.1, 1 - t * 0.9);
  }

  ctx.save();
  ctx.translate(128 + dx, 128 + dy);
  ctx.rotate(rot);
  ctx.scale(sx, sy);

  const aspect = img.width / Math.max(1, img.height);
  let drawW = 216;
  let drawH = 216;
  if (aspect > 1) {
    drawH = drawW / aspect;
  } else {
    drawW = drawH * aspect;
  }
  ctx.drawImage(img, -drawW / 2, -drawH / 2, drawW, drawH);
  ctx.restore();

  if (customization.auraStyle !== 'none') {
    drawBackgroundAura(
      ctx,
      phase,
      palette,
      customization.auraStyle,
      customization.glowIntensity,
      animationId === 'cast' ? Math.sin(t * Math.PI) : 0
    );
  }
}

function renderDebugOverlays(
  ctx: CanvasRenderingContext2D,
  frameMeta: FrameData,
  targetSize: number,
  options: RenderOptions
): void {
  const s = targetSize / 256;
  ctx.save();

  // Hurtbox (Green)
  if (options.showHurtbox && frameMeta.hurtbox) {
    const { x, y, w, h } = frameMeta.hurtbox;
    ctx.strokeStyle = '#10B981';
    ctx.fillStyle = 'rgba(16, 185, 129, 0.12)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([4, 3]);
    ctx.fillRect(x * s, y * s, w * s, h * s);
    ctx.strokeRect(x * s, y * s, w * s, h * s);
    ctx.setLineDash([]);
  }

  // Active Attack / Spell Hitbox (Coral Red)
  if (options.showHitbox && frameMeta.hitbox) {
    const { x, y, w, h } = frameMeta.hitbox;
    ctx.strokeStyle = '#F43F5E';
    ctx.fillStyle = 'rgba(244, 63, 94, 0.18)';
    ctx.lineWidth = 1.75;
    ctx.fillRect(x * s, y * s, w * s, h * s);
    ctx.strokeRect(x * s, y * s, w * s, h * s);
  }

  // Cast Socket (Cyan Diamond)
  if (options.showCastSocket && frameMeta.castSocket) {
    const cx = frameMeta.castSocket.x * s;
    const cy = frameMeta.castSocket.y * s;
    ctx.strokeStyle = '#38BDF8';
    ctx.fillStyle = '#0B0D14';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(cx, cy - 6);
    ctx.lineTo(cx + 6, cy);
    ctx.lineTo(cx, cy + 6);
    ctx.lineTo(cx - 6, cy);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Origin Pivot Crosshair (Gold)
  if (options.showPivot && frameMeta.pivot) {
    const px = frameMeta.pivot.x * targetSize;
    const py = frameMeta.pivot.y * targetSize;
    ctx.strokeStyle = '#F59E0B';
    ctx.lineWidth = 1.75;
    ctx.beginPath();
    ctx.moveTo(px - 9, py);
    ctx.lineTo(px + 9, py);
    ctx.moveTo(px, py - 9);
    ctx.lineTo(px, py + 9);
    ctx.stroke();
    ctx.beginPath();
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  ctx.restore();
}

function hexWithAlpha(hex: string, alpha: number): string {
  const clean = hex.replace('#', '');
  const r = parseInt(clean.substring(0, 2), 16) || 0;
  const g = parseInt(clean.substring(2, 4), 16) || 0;
  const b = parseInt(clean.substring(4, 6), 16) || 0;
  return `rgba(${r}, ${g}, ${b}, ${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
}

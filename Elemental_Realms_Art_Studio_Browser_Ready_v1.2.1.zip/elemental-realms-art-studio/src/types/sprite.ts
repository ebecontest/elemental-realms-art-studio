export type AnimationId = 'idle' | 'move' | 'cast' | 'attack' | 'hit' | 'defeat';

export type AtlasFormat = 'phaser-hash' | 'texturepacker-array' | 'aseprite' | 'unity-engine';

export type SheetScope = 'all-animations' | 'current-animation';

export type SheetLayoutMode = 'rows-by-animation' | 'compact-grid' | 'horizontal-strip';

export type PropType = 'none' | 'grimoire' | 'orb-staff' | 'arcane-runes' | 'soul-lantern';

export type BrowGemType = 'sapphire-diamond' | 'astral-halo' | 'trinity-crest' | 'minimal-gold';

export type AuraStyle = 'mana-motes' | 'orbiting-runes' | 'spirit-flames' | 'none';

export type RenderStyle = 'hand-painted-hd' | 'pixel-art-64' | 'pixel-art-32' | 'cel-shaded';

export interface BoxRect {
  x: number;
  y: number;
  w: number;
  h: number;
}

export interface Point2D {
  x: number;
  y: number;
}

export interface FrameData {
  index: number;
  animationId: AnimationId;
  frameNumber: number;
  name: string;
  durationMs: number;
  pivot: Point2D; // normalized 0..1
  hurtbox: BoxRect; // relative to frame size (0..256 base)
  hitbox: BoxRect | null; // active attack/spell hitbox if applicable
  castSocket: Point2D; // where projectiles spawn (0..256 base)
}

export interface AnimationConfig {
  id: AnimationId;
  label: string;
  description: string;
  frameCount: number;
  fps: number;
  loopMode: 'loop' | 'ping-pong' | 'once';
  baseDurationMs: number;
  hasActiveHitbox: boolean;
}

export interface WispPalette {
  id: string;
  name: string;
  badge: string;
  // Hood & Cloak
  robeLight: string;
  robeMid: string;
  robeShadow: string;
  robeDeepShadow: string;
  // Gold / Metallic Trim
  trimHighlight: string;
  trimBase: string;
  trimShadow: string;
  trimDark: string;
  // Gems (Forehead & Collar)
  gemHighlight: string;
  gemMid: string;
  gemDeep: string;
  // Void Face & Eyes
  faceVoidTop: string;
  faceVoidBottom: string;
  eyeCore: string;
  eyeGlow: string;
  // Spectral Wisps (Top plume, side streamer, lower body tail)
  wispCore: string;
  wispMid: string;
  wispOuter: string;
  wispDarkPlume: string;
  // Outline
  outlineColor: string;
}

export interface CharacterCustomization {
  paletteId: string;
  customPalette?: WispPalette;
  propType: PropType;
  browGemType: BrowGemType;
  auraStyle: AuraStyle;
  renderStyle: RenderStyle;
  flipX: boolean;
  outlineThickness: number; // 0 to 2
  glowIntensity: number; // 0 to 1.5
  topPlumeScale: number; // 0.5 to 1.5
  backRibbonScale: number; // 0.5 to 1.5
  customUploadedImage: HTMLImageElement | null;
  useUploadedImageAsBase: boolean;
}

export interface AtlasSettings {
  projectName: string;
  format: AtlasFormat;
  scope: SheetScope;
  layoutMode: SheetLayoutMode;
  frameSize: 64 | 128 | 256 | 512;
  padding: number;
  extrude: boolean;
  powerOfTwo: boolean;
  maxColumns: number;
  transparentBackground: boolean;
  bgColor: string;
}

export interface PackedFrameRect {
  frameKey: string;
  animationId: AnimationId;
  frameIndex: number;
  x: number;
  y: number;
  w: number;
  h: number;
  durationMs: number;
  pivot: Point2D;
  hurtbox: BoxRect;
  hitbox: BoxRect | null;
  castSocket: Point2D;
}

export interface GeneratedAtlasResult {
  canvas: HTMLCanvasElement;
  width: number;
  height: number;
  packedFrames: PackedFrameRect[];
  jsonString: string;
  jsonObject: Record<string, unknown>;
}

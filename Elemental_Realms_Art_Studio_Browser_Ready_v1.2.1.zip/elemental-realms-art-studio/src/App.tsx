import { useEffect, useMemo, useState } from 'react';
import {
  AnimationId,
  AtlasSettings,
  CharacterCustomization,
  FrameData,
} from './types/sprite';
import { ANIMATION_CONFIGS, buildDefaultFrames } from './data/presets';
import {
  downloadCanvasAsPng,
  downloadJsonString,
  generateSpriteSheetAndJson,
  generateImportedImageAsset,
} from './engine/atlasGenerator';
import { TopToolbar } from './components/TopToolbar';
import { LeftDeck } from './components/LeftDeck';
import { CenterViewport } from './components/CenterViewport';
import { BottomTimeline } from './components/BottomTimeline';
import { RightInspector } from './components/RightInspector';

const DEFAULT_CUSTOMIZATION: CharacterCustomization = {
  paletteId: 'solaris-archon',
  propType: 'none',
  browGemType: 'sapphire-diamond',
  auraStyle: 'mana-motes',
  renderStyle: 'pixel-art-64',
  flipX: false,
  outlineThickness: 1.0,
  glowIntensity: 1.0,
  topPlumeScale: 1.0,
  backRibbonScale: 1.0,
  customUploadedImage: null,
  useUploadedImageAsBase: false,
};

const DEFAULT_ATLAS_SETTINGS: AtlasSettings = {
  projectName: 'er_fire_character',
  format: 'phaser-hash',
  scope: 'all-animations',
  layoutMode: 'rows-by-animation',
  frameSize: 256,
  padding: 4,
  extrude: false,
  powerOfTwo: false,
  maxColumns: 8,
  transparentBackground: true,
  bgColor: '#000000',
};

export function App() {
  const [framesByAnim, setFramesByAnim] = useState<Record<AnimationId, FrameData[]>>(() =>
    buildDefaultFrames()
  );
  const [activeAnimId, setActiveAnimId] = useState<AnimationId>('idle');
  const [activeFrameIndex, setActiveFrameIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [fpsByAnim, setFpsByAnim] = useState<Record<AnimationId, number>>({
    idle: 10,
    move: 12,
    cast: 12,
    attack: 14,
    hit: 12,
    defeat: 10,
  });
  const [loopModeByAnim, setLoopModeByAnim] = useState<
    Record<AnimationId, 'loop' | 'ping-pong' | 'once'>
  >({
    idle: 'loop',
    move: 'loop',
    cast: 'loop',
    attack: 'loop',
    hit: 'loop',
    defeat: 'loop',
  });
  const [pingPongDir, setPingPongDir] = useState<1 | -1>(1);
  const [onionSkin, setOnionSkin] = useState<boolean>(false);

  const [customization, setCustomization] = useState<CharacterCustomization>(
    DEFAULT_CUSTOMIZATION
  );
  const [settings, setSettings] = useState<AtlasSettings>(DEFAULT_ATLAS_SETTINGS);
  const [exportSuccessMessage, setExportSuccessMessage] = useState<string | null>(null);

  const activeFrames = framesByAnim[activeAnimId] || [];
  const safeFrameIndex = Math.min(activeFrameIndex, Math.max(0, activeFrames.length - 1));
  const currentFrame = activeFrames[safeFrameIndex];
  const currentFps = fpsByAnim[activeAnimId] || 10;
  const currentLoopMode = loopModeByAnim[activeAnimId] || 'loop';

  // Playback timer
  useEffect(() => {
    if (!isPlaying || activeFrames.length <= 1) return;

    const intervalMs = Math.max(24, Math.round(1000 / currentFps));
    const timer = setInterval(() => {
      setActiveFrameIndex((prev) => {
        const len = activeFrames.length;
        if (currentLoopMode === 'loop') {
          return (prev + 1) % len;
        }
        if (currentLoopMode === 'ping-pong') {
          const next = prev + pingPongDir;
          if (next >= len - 1) {
            setPingPongDir(-1);
            return len - 1;
          }
          if (next <= 0) {
            setPingPongDir(1);
            return 0;
          }
          return next;
        }
        // 'once'
        if (prev + 1 >= len) {
          return 0;
        }
        return prev + 1;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isPlaying, activeFrames.length, currentFps, currentLoopMode, pingPongDir]);

  // Generate packed .PNG sprite sheet & .JSON texture atlas in real time
  const atlasResult = useMemo(() => {
    return generateSpriteSheetAndJson(
      framesByAnim,
      activeAnimId,
      customization,
      settings
    );
  }, [framesByAnim, activeAnimId, customization, settings]);

  const importedAsset = useMemo(() => {
    if (!customization.useUploadedImageAsBase || !customization.customUploadedImage) return null;
    return generateImportedImageAsset(customization.customUploadedImage, settings, customization);
  }, [customization, settings]);

  const handleSelectAnim = (id: AnimationId) => {
    setActiveAnimId(id);
    setActiveFrameIndex(0);
    setPingPongDir(1);
  };

  const handleUpdateCustomization = (partial: Partial<CharacterCustomization>) => {
    setCustomization((prev) => ({ ...prev, ...partial }));
  };

  const handleUpdateSettings = (partial: Partial<AtlasSettings>) => {
    setSettings((prev) => ({ ...prev, ...partial }));
  };

  const handleUpdateCurrentFrame = (partial: Partial<FrameData>) => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (!list[safeFrameIndex]) return prev;
      list[safeFrameIndex] = { ...list[safeFrameIndex], ...partial };
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleApplyPivotToAllFrames = (pivot: { x: number; y: number }) => {
    setFramesByAnim((prev) => {
      const list = (prev[activeAnimId] || []).map((f) => ({
        ...f,
        pivot: { ...pivot },
      }));
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleAddFrame = () => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (list.length >= 16) return prev;
      const animCfg = ANIMATION_CONFIGS.find((a) => a.id === activeAnimId)!;
      const newIdx = list.length;
      const template = list[list.length - 1] || list[0];
      list.push({
        ...template,
        index: newIdx,
        frameNumber: newIdx + 1,
        name: `wisp_mage_${animCfg.label}_${String(newIdx).padStart(2, '0')}`,
      });
      return { ...prev, [activeAnimId]: list };
    });
  };

  const handleRemoveFrame = () => {
    setFramesByAnim((prev) => {
      const list = [...(prev[activeAnimId] || [])];
      if (list.length <= 2) return prev;
      list.pop();
      return { ...prev, [activeAnimId]: list };
    });
    setActiveFrameIndex((prev) => Math.max(0, prev - 1));
  };

  const showToast = (msg: string) => {
    setExportSuccessMessage(msg);
    setTimeout(() => setExportSuccessMessage(null), 2200);
  };

  const handleDownloadPng = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadCanvasAsPng(imageAsset?.canvas || atlasResult.canvas, `${settings.projectName}.png`);
    showToast('Saved .PNG!');
  };

  const handleDownloadJson = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadJsonString(imageAsset?.jsonString || atlasResult.jsonString, `${settings.projectName}.json`);
    showToast('Saved .JSON!');
  };

  const handleDownloadBundle = () => {
    if (!atlasResult) return;
    const imageAsset = importedAsset;
    downloadCanvasAsPng(imageAsset?.canvas || atlasResult.canvas, `${settings.projectName}.png`);
    setTimeout(() => {
      downloadJsonString(imageAsset?.jsonString || atlasResult.jsonString, `${settings.projectName}.json`);
    }, 180);
    showToast('Exported .PNG + .JSON!');
  };

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-[#0B0D14] text-[#F1F5F9]">
      {/* Top Studio Header Toolbar (56px) */}
      <TopToolbar
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        customization={customization}
        onUpdateCustomization={handleUpdateCustomization}
        onDownloadPng={handleDownloadPng}
        onDownloadJson={handleDownloadJson}
        onDownloadBundle={handleDownloadBundle}
        sheetDimensions={{
          width: atlasResult?.width || 0,
          height: atlasResult?.height || 0,
        }}
        totalPackedFrames={atlasResult?.packedFrames.length || 0}
        exportSuccessMessage={exportSuccessMessage}
      />

      {/* Main 3-Column Studio Workspace */}
      <div className="workspace flex-1 flex overflow-hidden min-h-0">
        {/* Left Deck: Animation Clips, Style & Rig, Packing Settings (280px) */}
        <LeftDeck
          activeAnimId={activeAnimId}
          onSelectAnim={handleSelectAnim}
          framesByAnim={framesByAnim}
          customization={customization}
          onUpdateCustomization={handleUpdateCustomization}
          settings={settings}
          onUpdateSettings={handleUpdateSettings}
          onResetCharacter={() => setCustomization(DEFAULT_CUSTOMIZATION)}
        />

        {/* Center Interactive Viewport + Bottom Scrubber Timeline */}
        <div className="center-workspace flex-1 flex flex-col min-w-0 overflow-hidden">
          <CenterViewport
            activeAnimId={activeAnimId}
            activeFrameIndex={safeFrameIndex}
            onSelectFrame={(animId, fIdx) => {
              setActiveAnimId(animId);
              setActiveFrameIndex(fIdx);
            }}
            framesByAnim={framesByAnim}
            onUpdateCurrentFrame={handleUpdateCurrentFrame}
            customization={customization}
            settings={settings}
            atlasResult={atlasResult}
            importedAsset={importedAsset}
            onionSkin={onionSkin}
            onToggleOnionSkin={() => setOnionSkin((o) => !o)}
          />

          <BottomTimeline
            activeAnimId={activeAnimId}
            frames={activeFrames}
            activeFrameIndex={safeFrameIndex}
            onSelectFrameIndex={(idx) => {
              setIsPlaying(false);
              setActiveFrameIndex(idx);
            }}
            isPlaying={isPlaying}
            onTogglePlay={() => setIsPlaying((p) => !p)}
            fps={currentFps}
            onChangeFps={(fps) =>
              setFpsByAnim((prev) => ({ ...prev, [activeAnimId]: fps }))
            }
            loopMode={currentLoopMode}
            onChangeLoopMode={(mode) =>
              setLoopModeByAnim((prev) => ({ ...prev, [activeAnimId]: mode }))
            }
            customization={customization}
            onAddFrame={handleAddFrame}
            onRemoveFrame={handleRemoveFrame}
            onUpdateFrameDuration={(durationMs) =>
              handleUpdateCurrentFrame({ durationMs })
            }
          />
        </div>

        {/* Right Inspector & Live .JSON Atlas Code Drawer (340px) */}
        <RightInspector
          activeAnimId={activeAnimId}
          activeFrameIndex={safeFrameIndex}
          currentFrame={currentFrame}
          onUpdateCurrentFrame={handleUpdateCurrentFrame}
          onApplyPivotToAllFrames={handleApplyPivotToAllFrames}
          settings={settings}
          atlasResult={atlasResult}
          jsonString={importedAsset?.jsonString || atlasResult?.jsonString || ''}
          isImportedAsset={Boolean(importedAsset)}
          onDownloadJson={handleDownloadJson}
        />
      </div>
    </div>
  );
}

export default App;

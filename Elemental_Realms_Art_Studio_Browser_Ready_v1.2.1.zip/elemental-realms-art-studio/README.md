# ELEMENTAL REALMS Art Studio

A local-first artwork preparation tool for creating game-ready visual assets for ELEMENTAL REALMS. It is designed around an image-to-artwork workflow: import a reference image, preview a clean HD or pixel-art conversion, select an elemental identity, and export a PNG together with matching JSON metadata.

## Artwork workflow

1. Open **Import Artwork** and select a character, monster, creature, item, weapon, effect, or other reference image (PNG, JPG, or WebP).
2. Choose the desired Elemental Realms elemental palette in **Style & Rig**: Fire, Water, Leaf, Lightning, Chaos, Light, or Earth. The selected element is recorded in the exported metadata.
3. Choose **HD**, **Pixel 64px**, **Retro 32px**, or **Cel Shaded**. Pixel modes use nearest-neighbour upscaling and colour quantisation to create a crisp pixel-art treatment; HD preserves smooth image detail.
4. Set a clear asset filename, such as `er_fire_slime`, `er_water_guardian`, or `er_leaf_staff`.
5. Preview the processed artwork in the centre stage. The artwork preview, PNG export, and JSON sidecar use the same processing result.
6. Export **PNG + JSON**. The PNG is the visual asset; the JSON describes its filename, dimensions, selected element, render style, source dimensions, transparency, origin and static-frame status.

## Sprite animation workflow

When no image is imported, the built-in procedural Wisp character rig can be customized and exported as an animation atlas. The atlas exporter supports Phaser/Pixi hash JSON, TexturePacker array JSON, Aseprite-style JSON, and a custom Unity/Godot-oriented JSON format. Animation frames, timing, pivots, hitboxes, hurtboxes and cast sockets are described in the atlas metadata.

A single imported image is a **static artwork asset**, not a real animation. The app does not invent walk, attack, or idle frames from one image. For real animation, create or import individual frames and pack them into a sprite sheet.

## Important capability note

This project performs local image processing in the browser; it does not currently include a hosted generative-AI model or a PixelLab API connection. It can prepare and convert uploaded artwork, but prompt-to-image generation and automatic AI reconstruction require a separately configured image-generation service/API.

## Run locally

```bash
npm install
npm run dev -- --host 0.0.0.0
```

Open `http://127.0.0.1:5173` in the same device browser. For a production build, run `npm run build`.


## Open it in a browser (no Termux after deployment)

This project is a static browser app. It can be hosted on GitHub Pages and then opened from Chrome on Android, iPhone, tablet, or desktop.

### One-time deployment
1. Create a new **public** repository on GitHub named `elemental-realms-art-studio`.
2. Upload the contents of this project folder to the repository's `main` branch (the `.github/workflows/deploy.yml` file must be included).
3. In the repository, open **Settings → Pages** and set the build/deployment source to **GitHub Actions**.
4. Open the **Actions** tab and wait for **Deploy Art Studio to GitHub Pages** to finish successfully.
5. Open the Pages URL shown in the deployment summary. Save it to your phone's home screen for app-like access.

After deployment, normal use only requires the browser and internet connection. Termux is not needed to open or use the hosted app. Updating the app later requires uploading changed project files to GitHub so the workflow can redeploy it.

### Current limitations
The app currently performs local image processing and exports PNG/JSON in the browser. It does not yet generate new artwork from text prompts with AI; that requires connecting an image-generation API or hosted model.
